#!/usr/bin/perl
print "Content-type: text/html\n\n"; 
#!/usr/bin/perl
my @EWlocked;
use IO::Socket;
my @fltype;
my $EWB_tabpath="./";
my $EWB_template="<html><body bgcolor=lightyellow><div align=center><></body></html>";
my $EWB_format="12:5:h";
my $EWB_sqldbase="";
my $EWB_sqlserver="";
srand(time());
my $PROGRAM_NAME;
{ my @a=split('/', $0);
  $PROGRAM_NAME=$a[$#a];
}
my $rlist="";

#gestione di forms multipart encoded
sub read_form_buffer()
{ my $b=$ENV{"CONTENT_LENGTH"};
  my $all=""; my $i;
  for ($i=0; $i<$b;)
  { $all=$all.<>;
    $i=length($all);
  };
  #pesco il boundary e ricostruisco, per quanto possibile, la query string.
  my $boundary=((split("\n", $all))[0]);
  my @all=split($boundary, $all);
  #se la prima riga termina con "name=", lo metto in query string
  $i=0;
  foreach $p(@all)
  {
    my ($a, $first)=(split("\n", $p));
    ($a, $b)=split(" name=\"", $first);
    if ($b ne "")
    { my $name;
      ($name, $b)=split("\"", $b);
      $parname[$i]=$name;
      #il value e' nella quarta riga.
      if (index($first, " filename=\"")<0)
      { my $rest;
          $rest="";
          for($k=4; $k<=(split("\n", $p)); $k++)
          { $rest=$rest.( (split("\n", $p))[$k]);
          };
        if ( ($rest) eq "")
        {
          $parvalue[$i]=((split("\n", $p))[3]);
	  $parvalue[$i]=substr($parvalue[$i], 0, length($parvalue[$i])-1);
	  $fltype[$i]="text";
          if (substr($parvalue[$i],0, length("HidDenFieldDaTa")) eq
                  ("HidDenFieldDaTa"))
          { $parvalue[$i]=fromasc(substr($parvalue[$i],length("HidDenFieldDaTa")));
          };
        }
        else
        { my $k;
          $parvalue[$i]="";
          for($k=3; $k<=(split("\n", $p)); $k++)
          { $parvalue[$i]=$parvalue[$i].( (split("\n", $p))[$k])."\n";
          };
	  $parvalue[$i]=substr($parvalue[$i], 0, length($parvalue[$i])-2);
        };
        $i++;

      } else
      { #cerco il content_type
        $fltype[$i]="file";
        my $ctype=((split("\n", $p))[2]);
	$ctype=substr($ctype, 0, length($ctype)-1);
	#print "Ctype: [$ctype]\n";
        $parvalue[$i] = "";
	if (substr(uc($ctype), 0, length("Content-type: "))  eq "CONTENT-TYPE: ")
	{ #trasferimento file di testo.
	  my @p=split("\n", $p);
	  $p[0]=""; $p[1]=""; $p[2]=""; $p[3]="";
	  $partype[$i]=substr($ctype, length("Content-type: "));
	  #printf("partype: $partype[$i]\n");
	  $parvalue[$i]=join("\n", @p);
	  $parvalue[$i]=substr($parvalue[$i], 4);
          $parvalue[$i]=substr($parvalue[$i], 0, (length($parvalue[$i])-1));
	}
        $i++;
      }
    }
  }

  #se ci sono parametri con nome  replicato, diventano un'unico parametro con
  #valori separati da ;
  my  $p, $r, $fn; my $cnp=0;
  my @pnm; my  @pvl;
  foreach $p(@parname)
  { $fn=0;
    my $cni=0;
    foreach $r(@pnm)
    { if  ($p eq $r)
       { $pvl[$cni]=$pvl[$cni].";".$parvalue[$cnp];
	 $fn=1;
       };
       $cni++;
    };
    if ( $fn==0 )
    { $pnm[$#pnm+1]=$p;
      $pvl[$#pvl+1]=$parvalue[$cnp];
    };
    $cnp++;
  };
  @parname=@pnm;
  @parvalue=@pvl;

  #qui mostro tutti i parametri. Rielaboro quelli corrispondenti a multicheck
  # e piu'avanti anche a multilist.
  my $p; my $cnt=0;
  my  @pv; my @tohide; my  @hideval;
  foreach $p(@parname)
  { if (substr($p, 0, length("EWcHECK_")) eq  "EWcHECK_")
    { $p=substr($p, length("EWcHECK_"));
      my $n=int($p);
      $p=substr($p, length($n));
#      print "Par ".$p." vale ".$parvalue[$cnt]."<br>";

      my $fnd=0;
      for ($n=0; $n<=$#tohide; $n++)
      { if ($p eq $tohide[$n])
        { $fnd=1;
          $hideval[$n]=$hideval[$n].";".$parvalue[$cnt];
        };
      };
      if ($fnd!=1)
      { $n=$#tohide+1;
        $tohide[$n]=$p;
        $hideval[$n]=$parvalue[$cnt];
      };
    };
    $cnt++;
  };
  $cnt=0;
  foreach $p(@tohide)
  { my $a;
    my $ctb=0;
    foreach $a(@parname)
    { if ($a eq $p) { $parvalue[$ctb]=$hideval[$cnt]; }
      $ctb++;
    }
    $cnt++;
  };
}

sub checkpath()
{ my $a=$EWB_tabpath;
  if (substr($a,length($a)-1,1) ne "/")
  { $a=$a."/";
  }; return $a;
};

sub get_par($)
{ my ($name)=@_;
  my $res="";
  my $n; my $i=0;
  foreach $n(@parname)
  { if ($name eq EWconv($n))
    { if ($fltype[$i] ne "file") { $res=EWconv($parvalue[$i]); }
      else { $res=$parvalue[$i]; };
    };
    $i++;
  };
  return $res;
};

#funzioni predefinite
sub EWsave($$)
{ my ($a, $b)=@_;
  my $r;
  $r = open oof, "> $a";
  if (!$r) { print "File di save non scrivibile. Controllare i permessi"; exit(0); };
  print oof $b;
  close oof;
  return $r;
}
#2.10 Inizio

sub tab_wlock($)
{ my $name=$_[0];
  $name=((split(":", $name))[0]);
  my $i; my $d=0;
  if (!tab_islock($name))
  { while (($i<10)&&($d==0))
    { if (!(open (III, "< ".checkpath()."TB".$name.".lck")))
      { if (!(open (OOO, "> ".checkpath()."TB".$name.".lck")))
        { print  "Attenzione: non posso creare files.\n";
          exit(0);
        };
        close OOO;$d=1;
      }
      else
      { close III; sleep (1); $i++;
      }
    }
  }
  push @EWlocked, $name;
}

sub tab_unlock($)
{ my $name=$_[0];
  $name=((split(":", $name))[0]);
  my @a; my $l;
  my $count=0;
  foreach $l(@EWlocked)
  { if (($l ne $name) || ($count>0)) { push @a,$l; }
    if ($l eq $name) {++$count; };
  }
  @EWlocked=@a;
  if ($count=1) { unlink(checkpath()."TB".$name.".lck"); };
}

sub tab_sort($$)
{ my ($name,$s)=@_; my $r=""; my $l;
  my $n=((split(":",$name))[0]);
  $name=substr($name,length($n)+1);
  my $p; my $c=0;
  foreach $p(split(":",$name))
  { if ($p eq $s) { $k=$c; };
    $c++;
  }
  my @b; $c=0;
  tab_wlock($n);
  open III,"<".checkpath().".TB$n.tab";
  my @a=(<III>); close III;
  foreach $p(@a)
  { my $t;
    my @p=split("#",$p);
    $t=$p[0];
    $p[0]=$p[$k];
    $p[$k]=$t;
    $b[$c]=join("#",@p);
    $c=$c+1;
  }
  @b=sort(@b);
  $c=0;
  foreach $p(@b)
  { my $t;
    my @p=split("#",$p);
    $t=$p[0];
    $p[0]=$p[$k];
    $p[$k]=$t;
    $a[$c]=join("#",@p);
    $c=$c+1;
  }
  open oof,"> ".checkpath().".TB$n.tab";
  foreach $l(@a)
  { print oof $l;
  }
  close oof; tab_unlock($n); return $r;
}
sub tab_read($)
{ #esegue la lettura di una tabella gia bloccata.
  my @t=split(":", $_[0]);
  open III,"< ".checkpath().".TB$t[0].tab";
    my $k=join("",<III>);
    my @r=split("\n",$k);
  close III;
  return @r;
};
sub addchar($)
{ my $a=join("#",split "<EWB_ASTErISCO>", $_[0]);
  $a=join(chr(0x0D),split("<EWB_LineFEEd>", $a));
  return join("\n", split("<EWB_CARRIaGErETURN>", $a));
}

sub CreateForm
{ #nomecampo, valore, tipo campo, nome a video
  my ($n,$v,$t,$vidname)=@_;
  if ($t eq "hidden")
  { #conversione di un campo hidden, analoga a push
    $v="HidDenFieldDaTa".toasc($v);
  }
  else
  { if (($t ne "textarea")&&($t ne "info"))
    { $v=join("%22", (split "\"", $v));
      $v=join("%09", (split "\t", $v));
      $v=join("%0A", (split "\n", $v));
      $v=join("%3C", (split "<", $v));
    };
  };
  my @f=split(":", $EWB_format);
  if ($f[0]<1) {$f[0]=12; };
  if ($f[1]<1) {$f[1]=5; };

  my $res;
  my $vn=$vidname;
  if (length($vidname) <2) { $vidname=$n; };
  $res="<table border=0><tr><td>$vidname</td><td>";

  if (($t eq "submit") && (length($vn)<2)) { $res="<table border=0><tr><td></td><td>"; };
  if ($t eq "file")
  { $res=$res."<input name=\"$n\" value=\"\" type=file>"; }
  if ($t eq "text")
  { $res=$res."<input name=\"$n\" value=\"$v\" size=".$f[0].">"; }
  if ($t eq "password")
  { $res=$res."<input name=\"$n\" type=password value=\"$v\" size=".$f[0].">"; }
  if ($t eq "hidden")
  { $res="<input name=\"$n\" type=hidden value=\"$v\">"; }
  if ($t eq "checkbox")
  { $res=$res."<input name=\"$n\" type=checkbox value=\"1\">"; }
  if ($t eq "info")
  { $res="<table border=0><tr><td><b> $v </b>"; }
  if ($t eq "textarea")
  { $res=$res."<textarea name=\"$n\" cols=".$f[0]." rows=".$f[1].">$v</textarea>"; }
  #tipi composti
  if ($t eq "option") { $res=$res."\n<select name=\"$n\">"; }
  if ($t eq "options") { $res=$res."\n<select name=\"$n\" multiple>"; }
  my @v=split(/;/,$v); my $p;

  if ($t eq "checks")
  { $res=$res."<input name=\"$n\" type=hidden value=\"\">\n";
  }

  my $sep; if ($f[2] eq "v") { $sep="<br>"; } else{ $sep=" &nbsp; "; };
  my $counter=0;
  foreach $p(@v)
  {
    if ($t eq "checks")
    { my $CV="";
      if (substr($p, 0, 1) eq  "*")
      { $p=substr($p, 1);
        $CV="checked";
      };
      $res=$res."<input name=\"EWcHECK_".$counter.$n."\" type=checkbox $CV value=\"$p\">$p $sep\n";
      $counter++;
    }
    if ($t eq "links")
    {  my ($vid,$dest)=split("->", $p);
       if ($dest eq "") { $dest=$vid; };
       $res=$res."<a href=\"$dest\">$vid</a>$sep"; }
    if ($t eq "radio")
    { if ( substr($p,0,1) eq "*")
      { $p=substr($p,1);
        $res=$res."<input type=radio name=\"$n\" value=\"$p\" checked>$p$sep";
      }
      else
      { $res=$res."<input type=radio name=\"$n\" value=\"$p\">$p$sep";
      };
    }
    if (($t eq "option") || ($t eq "options"))
    { if ( substr($p,0,1) eq "*")
      { $p=substr($p,1);
        $res=$res."<option value=\"$p\" selected>$p";
      }
      else
      { $res=$res."<option value=\"$p\">$p";
      };
     }
    if ($t eq "submit")
    { $res=$res."<input name=\"$n\" type=submit value=\"$p\">$sep"; }
  }
  if (($t eq "option")||($t eq "options")) { $res=$res."</select>"; }
  if ($t ne "hidden") { $res=$res."</td></tr></table>"; }
  return $res."\n";
}

#liste - conversione da e a ascii

my @parname;
my @parvalue;
srand(time());
read_form_buffer();
#jumper area
if (get_par("EWjump")>0)
{ jumper(get_par("EWjump"));
};
my $ax,$bx,$cx,$dx,@as;
	my $TB_cats="cats:categoria:lingua:descrizione:aree:areeinfo:note";
	my $EWB_categoria=""; 
	my $EWB_lingua=""; 
	my $EWB_descrizione=""; 
	my $EWB_aree=""; 
	my $EWB_areeinfo=""; 
	my $EWB_note=""; 
		my $TB_order="order:ordine:lingua:categoria:sottocategorie";
	my $EWB_ordine=""; 
	my $EWB_lingua=""; 
	my $EWB_categoria=""; 
	my $EWB_sottocategorie=""; 
		my $TB_prodotti="prodotti:codice:categoria:gruppo:lingua:foto:stringa:stringainfo:notap";
	my $EWB_codice=""; 
	my $EWB_categoria=""; 
	my $EWB_gruppo=""; 
	my $EWB_lingua=""; 
	my $EWB_foto=""; 
	my $EWB_stringa=""; 
	my $EWB_stringainfo=""; 
	my $EWB_notap=""; 
	
my $EWB_b;
	
my $EWB_lng;
	
my $EWB_inf;
	
area100:;
	$ax=1;
	if (! ($ax)) {goto area101;};
	$ax="Italiano;Inglese";
	$EWB_lng=$ax;$ax="Categorie;Prodotti;Ordine";
	$EWB_b=$ax;my $form="";
	$ax="Lingua";
	push @as,"lng";
	push @as,$EWB_lng;
	push @as,"option";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
$form=$form.CreateForm("EWjump", 0+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.873880215295689\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab1;
lab1:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
retlab1:;

area102:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Ordine";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (! ($ax)) {goto area103;};
	
my $EWB_rs;
	$ax="</b>Categorie visualizzate<br><table border=1>";
	$EWB_rs=$ax;$ax="order:ordine:lingua:categoria:sottocategorie";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area104:;
  if ($g > $#f) { goto area106; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area105;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax="<br>";
	push @as,$ax;
	$ax=";";
	push @as,$ax;
	$ax=$EWB_sottocategorie;
	$bx=pop @as;
	$cx=pop @as;
	 
  $ax=join($cx, split($bx,$ax));
	$EWB_sottocategorie=$ax;$ax=$EWB_rs;
	push @as,$ax;
	$ax="<tr><td>";
	push @as,$ax;
	$ax=$EWB_ordine;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax=$EWB_sottocategorie;
	push @as,$ax;
	$ax="</td></tr>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rs=$ax;
area105:;
  $g=$g+1;
  goto area104;
area106:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax=$EWB_rs;
	push @as,$ax;
	$ax="</table>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rs=$ax;$ax="Aggiungi;Cancella;Esci";
	$EWB_b=$ax;my $form="";
	push @as,"rs";
	push @as,$EWB_rs;
	push @as,"info";
	push @as,"rs";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"rs\"") <0)
     { $form=$form.CreateForm("rs", $EWB_rs, "hidden");
     } 
$form=$form.CreateForm("EWjump", 1+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.648061805029528\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab2;
lab2:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_rs=get_par("rs"); 
retlab2:;
$ax=$EWB_b;
	push @as,$ax;
	$ax="Cancella";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area107; };
	$ax="";
	$EWB_rs=$ax;$ax="order:ordine:lingua:categoria:sottocategorie";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area108:;
  if ($g > $#f) { goto area110; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area109;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_rs;
	push @as,$ax;
	$ax=$EWB_ordine;
	push @as,$ax;
	$ax=";";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rs=$ax;
area109:;
  $g=$g+1;
  goto area108;
area110:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
my $form="";
	push @as,"rs";
	push @as,$EWB_rs;
	push @as,"option";
	push @as,"rs";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"rs\"") <0)
     { $form=$form.CreateForm("rs", $EWB_rs, "hidden");
     } 
$form=$form.CreateForm("EWjump", 2+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.0971284141215953\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab3;
lab3:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_rs=get_par("rs"); 
retlab3:;
$ax="order:ordine:lingua:categoria:sottocategorie";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  open rof,"> ".checkpath().".TB$n.bkp";
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area111:;
  if ($g > $#f) { goto area113; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_rs;
	push @as,$ax;
	$ax=$EWB_ordine;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if ($ax) { goto area112;};
	print rof $l."\n";

area112:;
  $g=$g+1;
  goto area111;
area113: ;
	
  close rof;  
  #copia di un file sull altro
  open rif,checkpath().".TB$n.bkp";
  open rof, ">".checkpath().".TB$n.tab";
  my @fl=<rif>;
  my $rw;
  foreach $rw(@fl)
  { print rof $rw; };  
  close rif;
  close rof;
  tab_unlock($n);
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax="Informazione di ordine cancellata";
	print $ax;
	goto areaend107;
	
area107:;
	;

areaend107:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Aggiungi";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area114; };
	
my $EWB_ct;
	$ax="";
	$EWB_rs=$ax;$ax="cats:categoria:lingua:descrizione:aree:areeinfo:note";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area115:;
  if ($g > $#f) { goto area117; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area116;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_rs;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=";";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rs=$ax;
area116:;
  $g=$g+1;
  goto area115;
area117:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax=$EWB_rs;
	$EWB_ct=$ax;$ax=0;
	$EWB_ordine=$ax;my $form="";
	$ax="numero d'ordine";
	push @as,"ordine";
	push @as,$EWB_ordine;
	push @as,"text";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="categoria";
	push @as,"rs";
	push @as,$EWB_rs;
	push @as,"option";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="sottocategorie - sel. multipla";
	push @as,"ct";
	push @as,$EWB_ct;
	push @as,"options";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"rs\"") <0)
     { $form=$form.CreateForm("rs", $EWB_rs, "hidden");
     } 
    if (index($form, "name=\"ct\"") <0)
     { $form=$form.CreateForm("ct", $EWB_ct, "hidden");
     } 
$form=$form.CreateForm("EWjump", 3+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.686612482039841\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab4;
lab4:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_rs=get_par("rs"); 
$EWB_ct=get_par("ct"); 
retlab4:;
$ax=$EWB_ordine;
	push @as,$ax;
	$ax=0;
	$bx=pop @as;
	$ax=($bx >= $ax);
	if (!($ax)) { goto area118; };
	$ax=$EWB_rs;
	$EWB_categoria=$ax;$ax=$EWB_ct;
	$EWB_sottocategorie=$ax;$ax="order:ordine:lingua:categoria:sottocategorie";
$ax=ewb_add($ax);
	$ax="Dato d'ordine ";
	push @as,$ax;
	$ax=$EWB_ordine;
	push @as,$ax;
	$ax=" inserito\n";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	print $ax;
	goto areaend118;
	
area118:;
	;

areaend118:;
	goto areaend114;
	
area114:;
	;

areaend114:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Esci";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area119; };
	$ax="Ordine";
	$EWB_b=$ax;goto areaend119;
	
area119:;
	;

areaend119:;
	goto area102;
	
area103:;
	
area120:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Prodotti";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (! ($ax)) {goto area121;};
	$ax="Aggiungi;Modifica;Cancella;Esci";
	$EWB_b=$ax;$ax="Gestione singoli prodotti - ";
	push @as,$ax;
	$ax=$EWB_lng;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_inf=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
$form=$form.CreateForm("EWjump", 4+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.847482872789517\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab5;
lab5:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
retlab5:;

my $EWB_ct;
	$ax="cats:categoria:lingua:descrizione:aree:areeinfo:note";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area122:;
  if ($g > $#f) { goto area124; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area123;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_lingua;
	push @as,$ax;
	$ax=$EWB_lng;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area123;};
	$ax=$EWB_ct;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=";";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_ct=$ax;
area123:;
  $g=$g+1;
  goto area122;
area124:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax=$EWB_b;
	push @as,$ax;
	$ax="Cancella";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area125; };
	
my $EWB_a;
	$ax="Seleziona la categoria da cui cancellare";
	$EWB_inf=$ax;$ax="Ok";
	$EWB_a=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="  ";
	push @as,"ct";
	push @as,$EWB_ct;
	push @as,"option";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"a";
	push @as,$EWB_a;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"ct\"") <0)
     { $form=$form.CreateForm("ct", $EWB_ct, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
$form=$form.CreateForm("EWjump", 5+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.690792461609803\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab6;
lab6:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_ct=get_par("ct"); 
$EWB_a=get_par("a"); 
retlab6:;

my $EWB_prd;
	$ax="";
	$EWB_prd=$ax;$ax="prodotti:codice:categoria:gruppo:lingua:foto:stringa:stringainfo:notap";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area126:;
  if ($g > $#f) { goto area128; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area127;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=$EWB_ct;
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_lingua;
	push @as,$ax;
	$ax=$EWB_lng;
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area127;};
	$ax=$EWB_prd;
	push @as,$ax;
	$ax=$EWB_codice;
	push @as,$ax;
	$ax=";";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_prd=$ax;
area127:;
  $g=$g+1;
  goto area126;
area128:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax="Seleziona il prodotto da cancellare";
	$EWB_inf=$ax;$ax="ok";
	$EWB_a=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="  ";
	push @as,"prd";
	push @as,$EWB_prd;
	push @as,"option";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"a";
	push @as,$EWB_a;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"ct\"") <0)
     { $form=$form.CreateForm("ct", $EWB_ct, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
    if (index($form, "name=\"prd\"") <0)
     { $form=$form.CreateForm("prd", $EWB_prd, "hidden");
     } 
$form=$form.CreateForm("EWjump", 6+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.0790912473078969\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab7;
lab7:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_ct=get_par("ct"); 
$EWB_a=get_par("a"); 
$EWB_prd=get_par("prd"); 
retlab7:;
$ax=$EWB_prd;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area129; };
	$ax="prodotti:codice:categoria:gruppo:lingua:foto:stringa:stringainfo:notap";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  open rof,"> ".checkpath().".TB$n.bkp";
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area130:;
  if ($g > $#f) { goto area132; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_codice;
	push @as,$ax;
	$ax=$EWB_prd;
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_lingua;
	push @as,$ax;
	$ax=$EWB_lng;
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if ($ax) { goto area131;};
	print rof $l."\n";

area131:;
  $g=$g+1;
  goto area130;
area132: ;
	
  close rof;  
  #copia di un file sull altro
  open rif,checkpath().".TB$n.bkp";
  open rof, ">".checkpath().".TB$n.tab";
  my @fl=<rif>;
  my $rw;
  foreach $rw(@fl)
  { print rof $rw; };  
  close rif;
  close rof;
  tab_unlock($n);
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax="Prodotto ";
	push @as,$ax;
	$ax=$EWB_prd;
	push @as,$ax;
	$ax=" cancellato";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_inf=$ax;$ax="ok";
	$EWB_a=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"a";
	push @as,$EWB_a;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"ct\"") <0)
     { $form=$form.CreateForm("ct", $EWB_ct, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
    if (index($form, "name=\"prd\"") <0)
     { $form=$form.CreateForm("prd", $EWB_prd, "hidden");
     } 
$form=$form.CreateForm("EWjump", 7+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.544303996063796\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab8;
lab8:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_ct=get_par("ct"); 
$EWB_a=get_par("a"); 
$EWB_prd=get_par("prd"); 
retlab8:;
goto areaend129;
	
area129:;
	;

areaend129:;
	goto areaend125;
	
area125:;
	;

areaend125:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Aggiungi";
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Modifica";
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx || $ax;
	if (!($ax)) { goto area133; };
	
my $EWB_a;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Aggiungi";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area134; };
	$ax="Seleziona la categoria  su cui aggiungere il prodotto";
	$EWB_inf=$ax;goto areaend134;
	
area134:;
	$ax="Seleziona la categoria del prodotto da modificare";
	$EWB_inf=$ax;
areaend134:;
	my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="  ";
	push @as,"ct";
	push @as,$EWB_ct;
	push @as,"option";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"ct\"") <0)
     { $form=$form.CreateForm("ct", $EWB_ct, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
$form=$form.CreateForm("EWjump", 8+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.38776465388074\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab9;
lab9:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_ct=get_par("ct"); 
$EWB_a=get_par("a"); 
retlab9:;
$ax=$EWB_ct;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area135; };
	$ax="Categoria non valida";
	$EWB_inf=$ax;$ax="Ok";
	$EWB_a=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"a";
	push @as,$EWB_a;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"ct\"") <0)
     { $form=$form.CreateForm("ct", $EWB_ct, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
$form=$form.CreateForm("EWjump", 9+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.0116313642945443\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab10;
lab10:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_ct=get_par("ct"); 
$EWB_a=get_par("a"); 
retlab10:;
goto areaend135;
	
area135:;
	
my $EWB_prd;
	$ax="";
	$EWB_prd=$ax;
my $EWB_va;
	
my $EWB_vb;
	
my $EWB_vc;
	
my $EWB_vd;
	$ax="";
	$EWB_va=$ax;$ax="";
	$EWB_vb=$ax;$ax="";
	$EWB_vc=$ax;$ax="";
	$EWB_vd=$ax;$ax=$EWB_b;
	push @as,$ax;
	$ax="Modifica";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area136; };
	$ax="prodotti:codice:categoria:gruppo:lingua:foto:stringa:stringainfo:notap";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area137:;
  if ($g > $#f) { goto area139; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area138;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=$EWB_ct;
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_lingua;
	push @as,$ax;
	$ax=$EWB_lng;
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area138;};
	$ax=$EWB_prd;
	push @as,$ax;
	$ax=$EWB_codice;
	push @as,$ax;
	$ax=";";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_prd=$ax;
area138:;
  $g=$g+1;
  goto area137;
area139:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax="Ok";
	$EWB_a=$ax;$ax="Seleziona il prodotto da modificare";
	$EWB_inf=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="  ";
	push @as,"prd";
	push @as,$EWB_prd;
	push @as,"option";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"a";
	push @as,$EWB_a;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"ct\"") <0)
     { $form=$form.CreateForm("ct", $EWB_ct, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
    if (index($form, "name=\"prd\"") <0)
     { $form=$form.CreateForm("prd", $EWB_prd, "hidden");
     } 
    if (index($form, "name=\"va\"") <0)
     { $form=$form.CreateForm("va", $EWB_va, "hidden");
     } 
    if (index($form, "name=\"vb\"") <0)
     { $form=$form.CreateForm("vb", $EWB_vb, "hidden");
     } 
    if (index($form, "name=\"vc\"") <0)
     { $form=$form.CreateForm("vc", $EWB_vc, "hidden");
     } 
    if (index($form, "name=\"vd\"") <0)
     { $form=$form.CreateForm("vd", $EWB_vd, "hidden");
     } 
$form=$form.CreateForm("EWjump", 10+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.110557883295581\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab11;
lab11:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_ct=get_par("ct"); 
$EWB_a=get_par("a"); 
$EWB_prd=get_par("prd"); 
$EWB_va=get_par("va"); 
$EWB_vb=get_par("vb"); 
$EWB_vc=get_par("vc"); 
$EWB_vd=get_par("vd"); 
retlab11:;
$ax="prodotti:codice:categoria:gruppo:lingua:foto:stringa:stringainfo:notap";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area140:;
  if ($g > $#f) { goto area142; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area141;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=$EWB_ct;
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_codice;
	push @as,$ax;
	$ax=$EWB_prd;
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_lingua;
	push @as,$ax;
	$ax=$EWB_lng;
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area141;};
	$ax=$EWB_foto;
	$EWB_va=$ax;$ax=$EWB_stringa;
	$EWB_vb=$ax;$ax=$EWB_stringainfo;
	$EWB_vc=$ax;$ax=$EWB_notap;
	$EWB_vd=$ax;
area141:;
  $g=$g+1;
  goto area140;
area142:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
goto areaend136;
	
area136:;
	;

areaend136:;
	$ax=$EWB_prd;
	$EWB_codice=$ax;$ax=$EWB_ct;
	$EWB_categoria=$ax;$ax=$EWB_lng;
	$EWB_lingua=$ax;$ax=$EWB_va;
	$EWB_foto=$ax;$ax=$EWB_vb;
	$EWB_stringa=$ax;$ax=$EWB_vc;
	$EWB_stringainfo=$ax;$ax=$EWB_vd;
	$EWB_notap=$ax;
my $EWB_fr;
	
my $EWB_fpr;
	$ax="si;*no";
	$EWB_fpr=$ax;$ax=$EWB_foto;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area143; };
	$ax="*si;no";
	$EWB_fpr=$ax;goto areaend143;
	
area143:;
	;

areaend143:;
	
my $EWB_grp;
	
my $EWB_ar;
	
my $EWB_aif;
	$ax="";
	$EWB_ar=$ax;$ax="";
	$EWB_aif=$ax;$ax="cats:categoria:lingua:descrizione:aree:areeinfo:note";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area144:;
  if ($g > $#f) { goto area146; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area145;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=$EWB_ct;
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_lingua;
	push @as,$ax;
	$ax=$EWB_lng;
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area145;};
	$ax=$EWB_aree;
	$EWB_ar=$ax;$ax=$EWB_areeinfo;
	$EWB_aif=$ax;
area145:;
  $g=$g+1;
  goto area144;
area146:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax=$EWB_aif;
	$EWB_areeinfo=$ax;$ax=$EWB_ar;
	$EWB_aree=$ax;$ax=$EWB_ct;
	$EWB_categoria=$ax;$ax="Modifica i dati del prodotto";
	$EWB_inf=$ax;$ax="32:10:h";
	$EWB_format=$ax;push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$EWB_fr=$ax;$ax=$EWB_fr;
	push @as,$ax;
	push @as,"codice";
	push @as,$EWB_codice;
	push @as,"text";
	push @as,"codice";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;$ax=$EWB_fr;
	push @as,$ax;
	push @as,"ct";
	push @as,$EWB_ct;
	push @as,"info";
	push @as,"ct";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;$ax=$EWB_fr;
	push @as,$ax;
	push @as,"lingua";
	push @as,$EWB_lingua;
	push @as,"info";
	push @as,"lingua";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;$ax=$EWB_fr;
	push @as,$ax;
	$ax="foto .jpg <img src=img_";
	push @as,$ax;
	$ax=$EWB_codice;
	push @as,$ax;
	$ax=".jpg width=50>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	push @as,"foto";
	push @as,$EWB_foto;
	push @as,"file";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;$ax=$EWB_fr;
	push @as,$ax;
	$ax="foto presente";
	push @as,"fpr";
	push @as,$EWB_fpr;
	push @as,"option";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;$ax=$EWB_fr;
	push @as,$ax;
	$ax="<table border=0><tr><td>";
	push @as,$ax;
	$ax="  ";
	push @as,"aree";
	push @as,$EWB_aree;
	push @as,"textarea";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;$ax=$EWB_fr;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax="  ";
	push @as,"stringa";
	push @as,$EWB_stringa;
	push @as,"textarea";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;$ax=$EWB_fr;
	push @as,$ax;
	$ax="</td></tr></table>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;$ax=$EWB_fr;
	push @as,$ax;
	$ax="<table border=0><tr><td>";
	push @as,$ax;
	$ax="  ";
	push @as,"areeinfo";
	push @as,$EWB_areeinfo;
	push @as,"textarea";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;$ax=$EWB_fr;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax="  ";
	push @as,"stringainfo";
	push @as,$EWB_stringainfo;
	push @as,"textarea";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;$ax=$EWB_fr;
	push @as,$ax;
	$ax="</td></tr></table>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;$ax="Inserisci";
	$EWB_a=$ax;$ax=$EWB_fr;
	push @as,$ax;
	push @as,"notap";
	push @as,$EWB_notap;
	push @as,"textarea";
	push @as,"notap";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;$ax=$EWB_fr;
	push @as,$ax;
	push @as,"a";
	push @as,$EWB_a;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;{ my $form=$EWB_fr."";
$EWB_fr=""; 
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     };
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     };
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     };
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     };
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     };
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     };
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     };
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     };
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     };
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     };
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     };
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     };
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     };
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     };
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     };
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     };
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     };
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     };
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     };
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     };
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     };
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     };
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     };
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     };
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     };
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     };
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     };
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     };
    if (index($form, "name=\"ct\"") <0)
     { $form=$form.CreateForm("ct", $EWB_ct, "hidden");
     };
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     };
    if (index($form, "name=\"prd\"") <0)
     { $form=$form.CreateForm("prd", $EWB_prd, "hidden");
     };
    if (index($form, "name=\"va\"") <0)
     { $form=$form.CreateForm("va", $EWB_va, "hidden");
     };
    if (index($form, "name=\"vb\"") <0)
     { $form=$form.CreateForm("vb", $EWB_vb, "hidden");
     };
    if (index($form, "name=\"vc\"") <0)
     { $form=$form.CreateForm("vc", $EWB_vc, "hidden");
     };
    if (index($form, "name=\"vd\"") <0)
     { $form=$form.CreateForm("vd", $EWB_vd, "hidden");
     };
    if (index($form, "name=\"fr\"") <0)
     { $form=$form.CreateForm("fr", $EWB_fr, "hidden");
     };
    if (index($form, "name=\"fpr\"") <0)
     { $form=$form.CreateForm("fpr", $EWB_fpr, "hidden");
     };
    if (index($form, "name=\"grp\"") <0)
     { $form=$form.CreateForm("grp", $EWB_grp, "hidden");
     };
    if (index($form, "name=\"ar\"") <0)
     { $form=$form.CreateForm("ar", $EWB_ar, "hidden");
     };
    if (index($form, "name=\"aif\"") <0)
     { $form=$form.CreateForm("aif", $EWB_aif, "hidden");
     };
$form=$form.CreateForm("EWjump", 11+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.564966522380452\">\
";
$form="<form name=\"ewb\" action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template))."\
\
"; exit(0); 
}

goto retlab12;
lab12:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_ct=get_par("ct"); 
$EWB_a=get_par("a"); 
$EWB_prd=get_par("prd"); 
$EWB_va=get_par("va"); 
$EWB_vb=get_par("vb"); 
$EWB_vc=get_par("vc"); 
$EWB_vd=get_par("vd"); 
$EWB_fr=get_par("fr"); 
$EWB_fpr=get_par("fpr"); 
$EWB_grp=get_par("grp"); 
$EWB_ar=get_par("ar"); 
$EWB_aif=get_par("aif"); 
retlab12:;
$ax=$EWB_fpr;
	push @as,$ax;
	$ax="no";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area147; };
	$ax="";
	$EWB_foto=$ax;goto areaend147;
	
area147:;
	;

areaend147:;
	$ax=$EWB_foto;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area148; };
	$ax="img_";
	push @as,$ax;
	$ax=$EWB_codice;
	push @as,$ax;
	$ax=".jpg";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	push @as,$ax;
	$ax=$EWB_foto;
	$bx=pop @as;
	$ax=EWsave($bx,$ax);
	$ax="1";
	$EWB_foto=$ax;goto areaend148;
	
area148:;
	$ax="";
	$EWB_foto=$ax;$ax=$EWB_va;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area149; };
	$ax="img_";
	push @as,$ax;
	$ax=$EWB_codice;
	push @as,$ax;
	$ax=".jpg";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=EWsave($bx,$ax);
	goto areaend149;
	
area149:;
	;

areaend149:;
	
areaend148:;
	$ax="prodotti:codice:categoria:gruppo:lingua:foto:stringa:stringainfo:notap";
$ax=ewb_add($ax);
	$ax="Ok";
	$EWB_a=$ax;$ax="Prodotto ";
	push @as,$ax;
	$ax=$EWB_codice;
	push @as,$ax;
	$ax=" inserito";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_inf=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"a";
	push @as,$EWB_a;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"ct\"") <0)
     { $form=$form.CreateForm("ct", $EWB_ct, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
    if (index($form, "name=\"prd\"") <0)
     { $form=$form.CreateForm("prd", $EWB_prd, "hidden");
     } 
    if (index($form, "name=\"va\"") <0)
     { $form=$form.CreateForm("va", $EWB_va, "hidden");
     } 
    if (index($form, "name=\"vb\"") <0)
     { $form=$form.CreateForm("vb", $EWB_vb, "hidden");
     } 
    if (index($form, "name=\"vc\"") <0)
     { $form=$form.CreateForm("vc", $EWB_vc, "hidden");
     } 
    if (index($form, "name=\"vd\"") <0)
     { $form=$form.CreateForm("vd", $EWB_vd, "hidden");
     } 
    if (index($form, "name=\"fr\"") <0)
     { $form=$form.CreateForm("fr", $EWB_fr, "hidden");
     } 
    if (index($form, "name=\"fpr\"") <0)
     { $form=$form.CreateForm("fpr", $EWB_fpr, "hidden");
     } 
    if (index($form, "name=\"grp\"") <0)
     { $form=$form.CreateForm("grp", $EWB_grp, "hidden");
     } 
    if (index($form, "name=\"ar\"") <0)
     { $form=$form.CreateForm("ar", $EWB_ar, "hidden");
     } 
    if (index($form, "name=\"aif\"") <0)
     { $form=$form.CreateForm("aif", $EWB_aif, "hidden");
     } 
$form=$form.CreateForm("EWjump", 12+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.144723850332401\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab13;
lab13:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_ct=get_par("ct"); 
$EWB_a=get_par("a"); 
$EWB_prd=get_par("prd"); 
$EWB_va=get_par("va"); 
$EWB_vb=get_par("vb"); 
$EWB_vc=get_par("vc"); 
$EWB_vd=get_par("vd"); 
$EWB_fr=get_par("fr"); 
$EWB_fpr=get_par("fpr"); 
$EWB_grp=get_par("grp"); 
$EWB_ar=get_par("ar"); 
$EWB_aif=get_par("aif"); 
retlab13:;

areaend135:;
	goto areaend133;
	
area133:;
	;

areaend133:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Esci";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area150; };
	$ax="Prodotti";
	$EWB_b=$ax;goto areaend150;
	
area150:;
	;

areaend150:;
	goto area120;
	
area121:;
	
area151:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Categorie";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (! ($ax)) {goto area152;};
	
my $EWB_ct;
	$ax="";
	$EWB_ct=$ax;$ax="Gestione categorie prodotti - ";
	push @as,$ax;
	$ax=$EWB_lng;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_inf=$ax;$ax="cats:categoria:lingua:descrizione:aree:areeinfo:note";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area153:;
  if ($g > $#f) { goto area155; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area154;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_lingua;
	push @as,$ax;
	$ax=$EWB_lng;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area154;};
	$ax=$EWB_ct;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=";";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_ct=$ax;
area154:;
  $g=$g+1;
  goto area153;
area155:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax="Aggiungi;Modifica;Cancella;Esci";
	$EWB_b=$ax;
my $EWB_fr;
	$ax=$EWB_fr;
	push @as,$ax;
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;$ax="12:5:v";
	$EWB_format=$ax;$ax=$EWB_fr;
	push @as,$ax;
	$ax="  ";
	push @as,"ct";
	push @as,$EWB_ct;
	push @as,"radio";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;$ax="12:5:h";
	$EWB_format=$ax;$ax=$EWB_fr;
	push @as,$ax;
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$ax=CreateForm($ax,$bx,$cx,$dx);$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_fr=$ax;{ my $form=$EWB_fr."";
$EWB_fr=""; 
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     };
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     };
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     };
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     };
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     };
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     };
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     };
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     };
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     };
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     };
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     };
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     };
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     };
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     };
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     };
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     };
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     };
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     };
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     };
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     };
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     };
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     };
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     };
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     };
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     };
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     };
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     };
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     };
    if (index($form, "name=\"ct\"") <0)
     { $form=$form.CreateForm("ct", $EWB_ct, "hidden");
     };
    if (index($form, "name=\"fr\"") <0)
     { $form=$form.CreateForm("fr", $EWB_fr, "hidden");
     };
$form=$form.CreateForm("EWjump", 13+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.629776494891999\">\
";
$form="<form name=\"ewb\" action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template))."\
\
"; exit(0); 
}

goto retlab14;
lab14:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_ct=get_par("ct"); 
$EWB_fr=get_par("fr"); 
retlab14:;
$ax=$EWB_ct;
	$EWB_categoria=$ax;$ax="Categoria: ";
	push @as,$ax;
	$ax=$EWB_ct;
	push @as,$ax;
	$ax="<br>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	print $ax;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Cancella";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area156; };
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area157; };
	
my $EWB_a;
	$ax=$EWB_categoria;
	$EWB_a=$ax;$ax="cats:categoria:lingua:descrizione:aree:areeinfo:note";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  open rof,"> ".checkpath().".TB$n.bkp";
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area158:;
  if ($g > $#f) { goto area160; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_lingua;
	push @as,$ax;
	$ax=$EWB_lng;
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=$EWB_a;
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if ($ax) { goto area159;};
	print rof $l."\n";

area159:;
  $g=$g+1;
  goto area158;
area160: ;
	
  close rof;  
  #copia di un file sull altro
  open rif,checkpath().".TB$n.bkp";
  open rof, ">".checkpath().".TB$n.tab";
  my @fl=<rif>;
  my $rw;
  foreach $rw(@fl)
  { print rof $rw; };  
  close rif;
  close rof;
  tab_unlock($n);
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax="ok";
	$EWB_b=$ax;$ax="Categoria ";
	push @as,$ax;
	$ax=$EWB_a;
	push @as,$ax;
	$ax=" cancellata";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_inf=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"ct\"") <0)
     { $form=$form.CreateForm("ct", $EWB_ct, "hidden");
     } 
    if (index($form, "name=\"fr\"") <0)
     { $form=$form.CreateForm("fr", $EWB_fr, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
$form=$form.CreateForm("EWjump", 14+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.886797342755468\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab15;
lab15:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_ct=get_par("ct"); 
$EWB_fr=get_par("fr"); 
$EWB_a=get_par("a"); 
retlab15:;
goto areaend157;
	
area157:;
	;

areaend157:;
	goto areaend156;
	
area156:;
	;

areaend156:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Aggiungi";
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Modifica";
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx || $ax;
	if (!($ax)) { goto area161; };
	$ax="30:8:h";
	$EWB_format=$ax;$ax=$EWB_b;
	push @as,$ax;
	$ax="Aggiungi";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area162; };
	$ax="";
	$EWB_categoria=$ax;$ax="";
	$EWB_descrizione=$ax;$ax="";
	$EWB_aree=$ax;$ax="";
	$EWB_areeinfo=$ax;$ax="";
	$EWB_note=$ax;goto areaend162;
	
area162:;
	
my $EWB_a;
	
my $EWB_c;
	
my $EWB_d;
	
my $EWB_e;
	$ax=$EWB_categoria;
	$EWB_a=$ax;$ax="cats:categoria:lingua:descrizione:aree:areeinfo:note";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area163:;
  if ($g > $#f) { goto area165; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area164;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_lingua;
	push @as,$ax;
	$ax=$EWB_lng;
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=$EWB_a;
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area164;};
	$ax=$EWB_aree;
	$EWB_c=$ax;$ax=$EWB_areeinfo;
	$EWB_d=$ax;$ax=$EWB_note;
	$EWB_e=$ax;
area164:;
  $g=$g+1;
  goto area163;
area165:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax=$EWB_a;
	$EWB_categoria=$ax;$ax=$EWB_c;
	$EWB_aree=$ax;$ax=$EWB_d;
	$EWB_areeinfo=$ax;$ax=$EWB_e;
	$EWB_note=$ax;
areaend162:;
	$ax="</b><i>Inserire i vari campi della tabella di 
      categoria ciascuno in una linea.</i>";
	$EWB_inf=$ax;$ax="Inserisci";
	$EWB_b=$ax;
my $EWB_descrizione;
	my $form="";
	push @as,"categoria";
	push @as,$EWB_categoria;
	push @as,"text";
	push @as,"categoria";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"descrizione";
	push @as,$EWB_descrizione;
	push @as,"text";
	push @as,"descrizione";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="dati";
	push @as,"aree";
	push @as,$EWB_aree;
	push @as,"textarea";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="info";
	push @as,"areeinfo";
	push @as,$EWB_areeinfo;
	push @as,"textarea";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"note";
	push @as,$EWB_note;
	push @as,"textarea";
	push @as,"note";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"ct\"") <0)
     { $form=$form.CreateForm("ct", $EWB_ct, "hidden");
     } 
    if (index($form, "name=\"fr\"") <0)
     { $form=$form.CreateForm("fr", $EWB_fr, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
$form=$form.CreateForm("EWjump", 15+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.430043296277397\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab16;
lab16:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_ct=get_par("ct"); 
$EWB_fr=get_par("fr"); 
$EWB_descrizione=get_par("descrizione"); 
retlab16:;
$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	push @as,$ax;
	$ax=$EWB_descrizione;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_categoria=$ax;$ax=$EWB_categoria;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	push @as,$ax;
	$ax=$EWB_aree;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area166; };
	$ax=$EWB_lng;
	$EWB_lingua=$ax;$ax="cats:categoria:lingua:descrizione:aree:areeinfo:note";
$ax=ewb_add($ax);
	$ax="cats:categoria:lingua:descrizione:aree:areeinfo:note";
push @as,$ax;
	$ax="categoria";
	$bx=pop @as;
	$ax=tab_sort($bx,$ax);$ax="Categoria inserita";
	$EWB_inf=$ax;$ax="Ok";
	$EWB_b=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"ct\"") <0)
     { $form=$form.CreateForm("ct", $EWB_ct, "hidden");
     } 
    if (index($form, "name=\"fr\"") <0)
     { $form=$form.CreateForm("fr", $EWB_fr, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
$form=$form.CreateForm("EWjump", 16+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.784523877519693\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab17;
lab17:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_ct=get_par("ct"); 
$EWB_fr=get_par("fr"); 
$EWB_descrizione=get_par("descrizione"); 
retlab17:;
goto areaend166;
	
area166:;
	$ax="Alcuni campi indispensabili sono vuoti";
	$EWB_inf=$ax;$ax="Ok";
	$EWB_b=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"aree\"") <0)
     { $form=$form.CreateForm("aree", $EWB_aree, "hidden");
     } 
    if (index($form, "name=\"areeinfo\"") <0)
     { $form=$form.CreateForm("areeinfo", $EWB_areeinfo, "hidden");
     } 
    if (index($form, "name=\"note\"") <0)
     { $form=$form.CreateForm("note", $EWB_note, "hidden");
     } 
    if (index($form, "name=\"ordine\"") <0)
     { $form=$form.CreateForm("ordine", $EWB_ordine, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"sottocategorie\"") <0)
     { $form=$form.CreateForm("sottocategorie", $EWB_sottocategorie, "hidden");
     } 
    if (index($form, "name=\"codice\"") <0)
     { $form=$form.CreateForm("codice", $EWB_codice, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"gruppo\"") <0)
     { $form=$form.CreateForm("gruppo", $EWB_gruppo, "hidden");
     } 
    if (index($form, "name=\"lingua\"") <0)
     { $form=$form.CreateForm("lingua", $EWB_lingua, "hidden");
     } 
    if (index($form, "name=\"foto\"") <0)
     { $form=$form.CreateForm("foto", $EWB_foto, "hidden");
     } 
    if (index($form, "name=\"stringa\"") <0)
     { $form=$form.CreateForm("stringa", $EWB_stringa, "hidden");
     } 
    if (index($form, "name=\"stringainfo\"") <0)
     { $form=$form.CreateForm("stringainfo", $EWB_stringainfo, "hidden");
     } 
    if (index($form, "name=\"notap\"") <0)
     { $form=$form.CreateForm("notap", $EWB_notap, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lng\"") <0)
     { $form=$form.CreateForm("lng", $EWB_lng, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"ct\"") <0)
     { $form=$form.CreateForm("ct", $EWB_ct, "hidden");
     } 
    if (index($form, "name=\"fr\"") <0)
     { $form=$form.CreateForm("fr", $EWB_fr, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
$form=$form.CreateForm("EWjump", 17+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.251323857227391\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab18;
lab18:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_categoria=get_par("categoria"); 
$EWB_lingua=get_par("lingua"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_aree=get_par("aree"); 
$EWB_areeinfo=get_par("areeinfo"); 
$EWB_note=get_par("note"); 
$EWB_ordine=get_par("ordine"); 
$EWB_lingua=get_par("lingua"); 
$EWB_categoria=get_par("categoria"); 
$EWB_sottocategorie=get_par("sottocategorie"); 
$EWB_codice=get_par("codice"); 
$EWB_categoria=get_par("categoria"); 
$EWB_gruppo=get_par("gruppo"); 
$EWB_lingua=get_par("lingua"); 
$EWB_foto=get_par("foto"); 
$EWB_stringa=get_par("stringa"); 
$EWB_stringainfo=get_par("stringainfo"); 
$EWB_notap=get_par("notap"); 
$EWB_b=get_par("b"); 
$EWB_lng=get_par("lng"); 
$EWB_inf=get_par("inf"); 
$EWB_ct=get_par("ct"); 
$EWB_fr=get_par("fr"); 
$EWB_descrizione=get_par("descrizione"); 
retlab18:;

areaend166:;
	$ax="Categorie";
	$EWB_b=$ax;goto areaend161;
	
area161:;
	;

areaend161:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Esci";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area167; };
	$ax="Categorie";
	$EWB_b=$ax;goto areaend167;
	
area167:;
	;

areaend167:;
	goto area151;
	
area152:;
	goto area100;
	
area101:;
	exit(0); 

sub jumper($)
{ my $lab=$_[0];
if ($lab==1) { goto lab1; }
if ($lab==2) { goto lab2; }
if ($lab==3) { goto lab3; }
if ($lab==4) { goto lab4; }
if ($lab==5) { goto lab5; }
if ($lab==6) { goto lab6; }
if ($lab==7) { goto lab7; }
if ($lab==8) { goto lab8; }
if ($lab==9) { goto lab9; }
if ($lab==10) { goto lab10; }
if ($lab==11) { goto lab11; }
if ($lab==12) { goto lab12; }
if ($lab==13) { goto lab13; }
if ($lab==14) { goto lab14; }
if ($lab==15) { goto lab15; }
if ($lab==16) { goto lab16; }
if ($lab==17) { goto lab17; }
if ($lab==18) { goto lab18; }
};

#Amethist easyweb v. 5.20 - easy 
#Enrico Betti e Paride Dominici



sub ewb_add($)
{  my $cond="my \$line=";
   my $tab=$_[0];
   my $count=0;
   my @tot=split(":",$tab);
   tab_wlock($tab);
   foreach $field(@tot)
   { if ($count>0)
     { $cond=$cond."delchar(\$EWB_".$field.")";
       if ($count<$#tot) {$cond=$cond.".\"#\"."; };
     }
     $count++;
  }
  $cond.=";
if (!(open oof,\">> ".checkpath().".TB$tot[0].tab\"))
{ print \"\\nAttenzione: non posso creare files\\n\";
  exit(0);
};
print oof \$line.\"\\n\";
close oof;
";
  eval($cond);
  tab_unlock($tab);
  return ($res ne "");
};

sub EWconv($)
{ my $a=$_[0];
  $a=join("%3C", split("%253C", $a));
  $a=~ tr/+/ /;
  $a=~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C",hex($1))/eg;
  $a=join("
", split("%0A", $a));
  $a=join("	", split("%09", $a));
  $a=join("\"", split("%22", $a));
  $a=join("<", split("%3C", $a));
  return $a;
}

sub tab_islock($)
{ my $name=$_[0];
  my $l; my $r=0;
  foreach $l(@EWlocked)
  { if ($l eq $name) {$r=1;}
  } return $r;
}

sub delchar($)
{ my $a=join("<EWB_ASTErISCO>",split "#", $_[0]);
  $a=join("<EWB_LineFEEd>", split(chr(0x0D), $a));
  return join("<EWB_CARRIaGErETURN>", split("\n", $a));
}

sub toasc($)
{ my $a=$_[0];
  my $r; my $i;
  for($i=0; $i<length($a); $i++)
  { my $k=ord(substr($a,$i,1));
    if ($k<16) {$r=$r."0";};
    $r=$r.sprintf("%x",$k);
  } return $r;
}

sub fromasc($)
{ my $a=$_[0];
  my $r; my $i;
  for($i=0; $i<length($a); $i=$i+2)
  { $r=$r.chr(hex(substr($a,$i,2)));
  } return $r;
}
