#!/usr/bin/perl
print "Content-type: text/html\n\n"; 
#!/usr/bin/perl
my @EWlocked;
use IO::Socket;
my @fltype;
my $EWB_tabpath="./";
my $EWB_template="<html><body bgcolor=lightyellow><div align=center><></body></html>";
my $EWB_format="12:5:h";
my $EWB_sqldbase="";
my $EWB_sqlserver="";
srand(time());
my $PROGRAM_NAME;
{ my @a=split('/', $0);
  $PROGRAM_NAME=$a[$#a];
}
my $rlist="";

#gestione di forms multipart encoded
sub read_form_buffer()
{ my $b=$ENV{"CONTENT_LENGTH"};
  my $all=""; my $i;
  for ($i=0; $i<$b;)
  { $all=$all.<>;
    $i=length($all);
  };
  #pesco il boundary e ricostruisco, per quanto possibile, la query string.
  my $boundary=((split("\n", $all))[0]);
  my @all=split($boundary, $all);
  #se la prima riga termina con "name=", lo metto in query string
  $i=0;
  foreach $p(@all)
  {
    my ($a, $first)=(split("\n", $p));
    ($a, $b)=split(" name=\"", $first);
    if ($b ne "")
    { my $name;
      ($name, $b)=split("\"", $b);
      $parname[$i]=$name;
      #il value e' nella quarta riga.
      if (index($first, " filename=\"")<0)
      { my $rest;
          $rest="";
          for($k=4; $k<=(split("\n", $p)); $k++)
          { $rest=$rest.( (split("\n", $p))[$k]);
          };
        if ( ($rest) eq "")
        {
          $parvalue[$i]=((split("\n", $p))[3]);
	  $parvalue[$i]=substr($parvalue[$i], 0, length($parvalue[$i])-1);
	  $fltype[$i]="text";
          if (substr($parvalue[$i],0, length("HidDenFieldDaTa")) eq
                  ("HidDenFieldDaTa"))
          { $parvalue[$i]=fromasc(substr($parvalue[$i],length("HidDenFieldDaTa")));
          };
        }
        else
        { my $k;
          $parvalue[$i]="";
          for($k=3; $k<=(split("\n", $p)); $k++)
          { $parvalue[$i]=$parvalue[$i].( (split("\n", $p))[$k])."\n";
          };
	  $parvalue[$i]=substr($parvalue[$i], 0, length($parvalue[$i])-2);
        };
        $i++;

      } else
      { #cerco il content_type
        $fltype[$i]="file";
        my $ctype=((split("\n", $p))[2]);
	$ctype=substr($ctype, 0, length($ctype)-1);
	#print "Ctype: [$ctype]\n";
        $parvalue[$i] = "";
	if (substr(uc($ctype), 0, length("Content-type: "))  eq "CONTENT-TYPE: ")
	{ #trasferimento file di testo.
	  my @p=split("\n", $p);
	  $p[0]=""; $p[1]=""; $p[2]=""; $p[3]="";
	  $partype[$i]=substr($ctype, length("Content-type: "));
	  #printf("partype: $partype[$i]\n");
	  $parvalue[$i]=join("\n", @p);
	  $parvalue[$i]=substr($parvalue[$i], 4);
          $parvalue[$i]=substr($parvalue[$i], 0, (length($parvalue[$i])-1));
	}
        $i++;
      }
    }
  }

  #se ci sono parametri con nome  replicato, diventano un'unico parametro con
  #valori separati da ;
  my  $p, $r, $fn; my $cnp=0;
  my @pnm; my  @pvl;
  foreach $p(@parname)
  { $fn=0;
    my $cni=0;
    foreach $r(@pnm)
    { if  ($p eq $r)
       { $pvl[$cni]=$pvl[$cni].";".$parvalue[$cnp];
	 $fn=1;
       };
       $cni++;
    };
    if ( $fn==0 )
    { $pnm[$#pnm+1]=$p;
      $pvl[$#pvl+1]=$parvalue[$cnp];
    };
    $cnp++;
  };
  @parname=@pnm;
  @parvalue=@pvl;

  #qui mostro tutti i parametri. Rielaboro quelli corrispondenti a multicheck
  # e piu'avanti anche a multilist.
  my $p; my $cnt=0;
  my  @pv; my @tohide; my  @hideval;
  foreach $p(@parname)
  { if (substr($p, 0, length("EWcHECK_")) eq  "EWcHECK_")
    { $p=substr($p, length("EWcHECK_"));
      my $n=int($p);
      $p=substr($p, length($n));
#      print "Par ".$p." vale ".$parvalue[$cnt]."<br>";

      my $fnd=0;
      for ($n=0; $n<=$#tohide; $n++)
      { if ($p eq $tohide[$n])
        { $fnd=1;
          $hideval[$n]=$hideval[$n].";".$parvalue[$cnt];
        };
      };
      if ($fnd!=1)
      { $n=$#tohide+1;
        $tohide[$n]=$p;
        $hideval[$n]=$parvalue[$cnt];
      };
    };
    $cnt++;
  };
  $cnt=0;
  foreach $p(@tohide)
  { my $a;
    my $ctb=0;
    foreach $a(@parname)
    { if ($a eq $p) { $parvalue[$ctb]=$hideval[$cnt]; }
      $ctb++;
    }
    $cnt++;
  };
}

sub checkpath()
{ my $a=$EWB_tabpath;
  if (substr($a,length($a)-1,1) ne "/")
  { $a=$a."/";
  }; return $a;
};

sub get_par($)
{ my ($name)=@_;
  my $res="";
  my $n; my $i=0;
  foreach $n(@parname)
  { if ($name eq EWconv($n))
    { if ($fltype[$i] ne "file") { $res=EWconv($parvalue[$i]); }
      else { $res=$parvalue[$i]; };
    };
    $i++;
  };
  return $res;
};

#funzioni predefinite
sub EWload($)
{ open iif,"<".$_[0];
  my $a=join("",<iif>);
  close iif;
  return $a;
}

sub EWsave($$)
{ my ($a, $b)=@_;
  my $r;
  $r = open oof, "> $a";
  if (!$r) { print "File di save non scrivibile. Controllare i permessi"; exit(0); };
  print oof $b;
  close oof;
  return $r;
}
#2.10 Inizio

sub EWgetenvvar($)
{
  my $r;
  $r= $ENV{$_[0]};
  return $r;
}

#2.10 fine
sub tab_wlock($)
{ my $name=$_[0];
  $name=((split(":", $name))[0]);
  my $i; my $d=0;
  if (!tab_islock($name))
  { while (($i<10)&&($d==0))
    { if (!(open (III, "< ".checkpath()."TB".$name.".lck")))
      { if (!(open (OOO, "> ".checkpath()."TB".$name.".lck")))
        { print  "Attenzione: non posso creare files.\n";
          exit(0);
        };
        close OOO;$d=1;
      }
      else
      { close III; sleep (1); $i++;
      }
    }
  }
  push @EWlocked, $name;
}

sub tab_unlock($)
{ my $name=$_[0];
  $name=((split(":", $name))[0]);
  my @a; my $l;
  my $count=0;
  foreach $l(@EWlocked)
  { if (($l ne $name) || ($count>0)) { push @a,$l; }
    if ($l eq $name) {++$count; };
  }
  @EWlocked=@a;
  if ($count=1) { unlink(checkpath()."TB".$name.".lck"); };
}

sub tab_read($)
{ #esegue la lettura di una tabella gia bloccata.
  my @t=split(":", $_[0]);
  open III,"< ".checkpath().".TB$t[0].tab";
    my $k=join("",<III>);
    my @r=split("\n",$k);
  close III;
  return @r;
};
sub addchar($)
{ my $a=join("#",split "<EWB_ASTErISCO>", $_[0]);
  $a=join(chr(0x0D),split("<EWB_LineFEEd>", $a));
  return join("\n", split("<EWB_CARRIaGErETURN>", $a));
}

sub CreateForm
{ #nomecampo, valore, tipo campo, nome a video
  my ($n,$v,$t,$vidname)=@_;
  if ($t eq "hidden")
  { #conversione di un campo hidden, analoga a push
    $v="HidDenFieldDaTa".toasc($v);
  }
  else
  { if (($t ne "textarea")&&($t ne "info"))
    { $v=join("%22", (split "\"", $v));
      $v=join("%09", (split "\t", $v));
      $v=join("%0A", (split "\n", $v));
      $v=join("%3C", (split "<", $v));
    };
  };
  my @f=split(":", $EWB_format);
  if ($f[0]<1) {$f[0]=12; };
  if ($f[1]<1) {$f[1]=5; };

  my $res;
  my $vn=$vidname;
  if (length($vidname) <2) { $vidname=$n; };
  $res="<table border=0><tr><td>$vidname</td><td>";

  if (($t eq "submit") && (length($vn)<2)) { $res="<table border=0><tr><td></td><td>"; };
  if ($t eq "file")
  { $res=$res."<input name=\"$n\" value=\"\" type=file>"; }
  if ($t eq "text")
  { $res=$res."<input name=\"$n\" value=\"$v\" size=".$f[0].">"; }
  if ($t eq "password")
  { $res=$res."<input name=\"$n\" type=password value=\"$v\" size=".$f[0].">"; }
  if ($t eq "hidden")
  { $res="<input name=\"$n\" type=hidden value=\"$v\">"; }
  if ($t eq "checkbox")
  { $res=$res."<input name=\"$n\" type=checkbox value=\"1\">"; }
  if ($t eq "info")
  { $res="<table border=0><tr><td><b> $v </b>"; }
  if ($t eq "textarea")
  { $res=$res."<textarea name=\"$n\" cols=".$f[0]." rows=".$f[1].">$v</textarea>"; }
  #tipi composti
  if ($t eq "option") { $res=$res."\n<select name=\"$n\">"; }
  if ($t eq "options") { $res=$res."\n<select name=\"$n\" multiple>"; }
  my @v=split(/;/,$v); my $p;

  if ($t eq "checks")
  { $res=$res."<input name=\"$n\" type=hidden value=\"\">\n";
  }

  my $sep; if ($f[2] eq "v") { $sep="<br>"; } else{ $sep=" &nbsp; "; };
  my $counter=0;
  foreach $p(@v)
  {
    if ($t eq "checks")
    { my $CV="";
      if (substr($p, 0, 1) eq  "*")
      { $p=substr($p, 1);
        $CV="checked";
      };
      $res=$res."<input name=\"EWcHECK_".$counter.$n."\" type=checkbox $CV value=\"$p\">$p $sep\n";
      $counter++;
    }
    if ($t eq "links")
    {  my ($vid,$dest)=split("->", $p);
       if ($dest eq "") { $dest=$vid; };
       $res=$res."<a href=\"$dest\">$vid</a>$sep"; }
    if ($t eq "radio")
    { if ( substr($p,0,1) eq "*")
      { $p=substr($p,1);
        $res=$res."<input type=radio name=\"$n\" value=\"$p\" checked>$p$sep";
      }
      else
      { $res=$res."<input type=radio name=\"$n\" value=\"$p\">$p$sep";
      };
    }
    if (($t eq "option") || ($t eq "options"))
    { if ( substr($p,0,1) eq "*")
      { $p=substr($p,1);
        $res=$res."<option value=\"$p\" selected>$p";
      }
      else
      { $res=$res."<option value=\"$p\">$p";
      };
     }
    if ($t eq "submit")
    { $res=$res."<input name=\"$n\" type=submit value=\"$p\">$sep"; }
  }
  if (($t eq "option")||($t eq "options")) { $res=$res."</select>"; }
  if ($t ne "hidden") { $res=$res."</td></tr></table>"; }
  return $res."\n";
}

#liste - conversione da e a ascii

my @parname;
my @parvalue;
srand(time());
read_form_buffer();
#jumper area
if (get_par("EWjump")>0)
{ jumper(get_par("EWjump"));
};
my $ax,$bx,$cx,$dx,@as;
	my $TB_imm_utenti="imm_utenti:user:pass";
	my $EWB_user=""; 
	my $EWB_pass=""; 
		my $TB_tipi_loc="tipi_loc:tipol";
	my $EWB_tipol=""; 
		my $TB_tipi_imm="tipi_imm:tipo";
	my $EWB_tipo=""; 
		my $TB_tipi_prezzo="tipi_prezzo:prezzoa:prezzob";
	my $EWB_prezzoa=""; 
	my $EWB_prezzob=""; 
		my $TB_imm_case="imm_case:imgcode:tipol:tipoimm:prezzo:tipocasa:descrizione";
	my $EWB_imgcode=""; 
	my $EWB_tipol=""; 
	my $EWB_tipoimm=""; 
	my $EWB_prezzo=""; 
	my $EWB_tipocasa=""; 
	my $EWB_descrizione=""; 
		my $TB_images="images:imgcode:imgfile";
	my $EWB_imgcode=""; 
	my $EWB_imgfile=""; 
	$ax="imm_edit.html";
	$ax=EWload($ax);
	$EWB_template=$ax;
my $EWB_code;
	
my $EWB_b;
	$ax=(EWgetenvvar("QUERY_STRING"));
	$EWB_code=$ax;$ax=$EWB_code;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area100; };
	$ax="chiamata errata";
	$ax=print join(($ax), split("<>",$EWB_template));
	exit (0);
	goto areaend100;
	
area100:;
	;

areaend100:;
	
my $EWB_inf;
	
area101:;
	$ax=1;
	if (! ($ax)) {goto area102;};
	$ax="";
	$EWB_inf=$ax;$ax="images:imgcode:imgfile";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  tab_unlock($n);
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area103:;
  if ($g > $#f) { goto area105; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_imgcode;
	push @as,$ax;
	$ax=$EWB_code;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area104;};
	$ax=$EWB_inf;
	push @as,$ax;
	$ax="<img src=";
	push @as,$ax;
	$ax=$EWB_imgfile;
	push @as,$ax;
	$ax=" width=100>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_inf=$ax;
area104:;
  $g=$g+1;
  goto area103;
area105: ;
	
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax=$EWB_inf;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area106; };
	$ax="nessuma immagine per l'immobile corrente";
	$EWB_inf=$ax;goto areaend106;
	
area106:;
	;

areaend106:;
	$ax="Inserisci un immagine;Cancella le immagini";
	$EWB_b=$ax;
my $EWB_home;
	$ax="<a href=imm_edit.cgi?sk345623421234235423564236787685678rtyhr5uetyjh454u6h35ycrrt23>
Torna alla home</a>";
	$EWB_home=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"home";
	push @as,$EWB_home;
	push @as,"info";
	push @as,"home";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"code\"") <0)
     { $form=$form.CreateForm("code", $EWB_code, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"home\"") <0)
     { $form=$form.CreateForm("home", $EWB_home, "hidden");
     } 
$form=$form.CreateForm("EWjump", 0+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.963082809307711\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab1;
lab1:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_code=get_par("code"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
$EWB_home=get_par("home"); 
retlab1:;
$ax=$EWB_b;
	push @as,$ax;
	$ax="Inserisci un immagine";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area107; };
	$ax="Seleziona l' immagine (.jpg) dal tuo computer e conferma";
	$EWB_inf=$ax;$ax="Conferma;Annulla";
	$EWB_b=$ax;$ax="";
	$EWB_imgcode=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="  ";
	push @as,"imgfile";
	push @as,$EWB_imgfile;
	push @as,"file";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"code\"") <0)
     { $form=$form.CreateForm("code", $EWB_code, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"home\"") <0)
     { $form=$form.CreateForm("home", $EWB_home, "hidden");
     } 
$form=$form.CreateForm("EWjump", 1+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.808356542696373\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab2;
lab2:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_code=get_par("code"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
$EWB_home=get_par("home"); 
retlab2:;
$ax=$EWB_b;
	push @as,$ax;
	$ax="Conferma";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area108; };
	
my $EWB_a;
	$ax=(rand(1));
	push @as,$ax;
	$ax=1000000;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$EWB_a=$ax;$ax="img";
	push @as,$ax;
	$ax=$EWB_a;
	push @as,$ax;
	$ax=".jpg";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	push @as,$ax;
	$ax=$EWB_imgfile;
	$bx=pop @as;
	$ax=EWsave($bx,$ax);
	$ax="img";
	push @as,$ax;
	$ax=$EWB_a;
	push @as,$ax;
	$ax=".jpg";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_imgfile=$ax;$ax=$EWB_code;
	$EWB_imgcode=$ax;$ax="images:imgcode:imgfile";
$ax=ewb_add($ax);
	goto areaend108;
	
area108:;
	;

areaend108:;
	goto areaend107;
	
area107:;
	;

areaend107:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Cancella le immagini";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area109; };
	$ax="Tutte le immagini per l' immobile verranno cancellate.";
	$EWB_inf=$ax;$ax="Conferma;Annulla";
	$EWB_b=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"code\"") <0)
     { $form=$form.CreateForm("code", $EWB_code, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"home\"") <0)
     { $form=$form.CreateForm("home", $EWB_home, "hidden");
     } 
$form=$form.CreateForm("EWjump", 2+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.767353956160274\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab3;
lab3:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_code=get_par("code"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
$EWB_home=get_par("home"); 
retlab3:;
$ax=$EWB_b;
	push @as,$ax;
	$ax="Conferma";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area110; };
	$ax="images:imgcode:imgfile";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  tab_unlock($n);
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area111:;
  if ($g > $#f) { goto area113; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_imgcode;
	push @as,$ax;
	$ax=$EWB_code;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area112;};
	$ax=$EWB_imgfile;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=EWsave($bx,$ax);
	
area112:;
  $g=$g+1;
  goto area111;
area113: ;
	
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax="images:imgcode:imgfile";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  open rof,"> ".checkpath().".TB$n.bkp";
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area114:;
  if ($g > $#f) { goto area116; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_imgcode;
	push @as,$ax;
	$ax=$EWB_code;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if ($ax) { goto area115;};
	print rof $l."\n";

area115:;
  $g=$g+1;
  goto area114;
area116: ;
	
  close rof;  
  #copia di un file sull altro
  open rif,checkpath().".TB$n.bkp";
  open rof, ">".checkpath().".TB$n.tab";
  my @fl=<rif>;
  my $rw;
  foreach $rw(@fl)
  { print rof $rw; };  
  close rif;
  close rof;
  tab_unlock($n);
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  goto areaend110;
	
area110:;
	;

areaend110:;
	goto areaend109;
	
area109:;
	;

areaend109:;
	goto area101;
	
area102:;
	exit(0); 

sub jumper($)
{ my $lab=$_[0];
if ($lab==1) { goto lab1; }
if ($lab==2) { goto lab2; }
if ($lab==3) { goto lab3; }
};

#Amethist easyweb v. 5.23 - easy 
#Enrico Betti e Paride Dominici



sub ewb_add($)
{  my $cond="my \$line=";
   my $tab=$_[0];
   my $count=0;
   my @tot=split(":",$tab);
   tab_wlock($tab);
   foreach $field(@tot)
   { if ($count>0)
     { $cond=$cond."delchar(\$EWB_".$field.")";
       if ($count<$#tot) {$cond=$cond.".\"#\"."; };
     }
     $count++;
  }
  $cond.=";
if (!(open oof,\">> ".checkpath().".TB$tot[0].tab\"))
{ print \"\\nAttenzione: non posso creare files\\n\";
  exit(0);
};
print oof \$line.\"\\n\";
close oof;
";
  eval($cond);
  tab_unlock($tab);
  return ($res ne "");
};

sub EWconv($)
{ my $a=$_[0];
  $a=join("%3C", split("%253C", $a));
#  $a=~ tr/+/ /;
  $a=~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C",hex($1))/eg;
  $a=join("
", split("%0A", $a));
  $a=join("	", split("%09", $a));
  $a=join("\"", split("%22", $a));
  $a=join("<", split("%3C", $a));
  return $a;
}

sub tab_islock($)
{ my $name=$_[0];
  my $l; my $r=0;
  foreach $l(@EWlocked)
  { if ($l eq $name) {$r=1;}
  } return $r;
}

sub delchar($)
{ my $a=join("<EWB_ASTErISCO>",split "#", $_[0]);
  $a=join("<EWB_LineFEEd>", split(chr(0x0D), $a));
  return join("<EWB_CARRIaGErETURN>", split("\n", $a));
}

sub toasc($)
{ my $a=$_[0];
  my $r; my $i;
  for($i=0; $i<length($a); $i++)
  { my $k=ord(substr($a,$i,1));
    if ($k<16) {$r=$r."0";};
    $r=$r.sprintf("%x",$k);
  } return $r;
}

sub fromasc($)
{ my $a=$_[0];
  my $r; my $i;
  for($i=0; $i<length($a); $i=$i+2)
  { $r=$r.chr(hex(substr($a,$i,2)));
  } return $r;
}
