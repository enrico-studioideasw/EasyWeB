#!/usr/bin/perl
print "Content-type: text/html\n\n"; 
#!/usr/bin/perl
my @EWlocked;
use IO::Socket;
my @fltype;
my $EWB_tabpath="./";
my $EWB_template="<html><body bgcolor=lightyellow><div align=center><></body></html>";
my $EWB_format="12:5:h";
my $EWB_sqldbase="";
my $EWB_sqlserver="";
srand(time());
my $PROGRAM_NAME;
{ my @a=split('/', $0);
  $PROGRAM_NAME=$a[$#a];
}
my $rlist="";

#gestione di forms multipart encoded
sub read_form_buffer()
{ my $b=$ENV{"CONTENT_LENGTH"};
  my $all=""; my $i;
  for ($i=0; $i<$b;)
  { $all=$all.<>;
    $i=length($all);
  };
  #pesco il boundary e ricostruisco, per quanto possibile, la query string.
  my $boundary=((split("\n", $all))[0]);
  my @all=split($boundary, $all);
  #se la prima riga termina con "name=", lo metto in query string
  $i=0;
  foreach $p(@all)
  {
    my ($a, $first)=(split("\n", $p));
    ($a, $b)=split(" name=\"", $first);
    if ($b ne "")
    { my $name;
      ($name, $b)=split("\"", $b);
      $parname[$i]=$name;
      #il value e' nella quarta riga.
      if (index($first, " filename=\"")<0)
      { my $rest;
          $rest="";
          for($k=4; $k<=(split("\n", $p)); $k++)
          { $rest=$rest.( (split("\n", $p))[$k]);
          };
        if ( ($rest) eq "")
        {
          $parvalue[$i]=((split("\n", $p))[3]);
	  $parvalue[$i]=substr($parvalue[$i], 0, length($parvalue[$i])-1);
	  $fltype[$i]="text";
          if (substr($parvalue[$i],0, length("HidDenFieldDaTa")) eq
                  ("HidDenFieldDaTa"))
          { $parvalue[$i]=fromasc(substr($parvalue[$i],length("HidDenFieldDaTa")));
          };
        }
        else
        { my $k;
          $parvalue[$i]="";
          for($k=3; $k<=(split("\n", $p)); $k++)
          { $parvalue[$i]=$parvalue[$i].( (split("\n", $p))[$k])."\n";
          };
	  $parvalue[$i]=substr($parvalue[$i], 0, length($parvalue[$i])-2);
        };
        $i++;

      } else
      { #cerco il content_type
        $fltype[$i]="file";
        my $ctype=((split("\n", $p))[2]);
	$ctype=substr($ctype, 0, length($ctype)-1);
	#print "Ctype: [$ctype]\n";
        $parvalue[$i] = "";
	if (substr(uc($ctype), 0, length("Content-type: "))  eq "CONTENT-TYPE: ")
	{ #trasferimento file di testo.
	  my @p=split("\n", $p);
	  $p[0]=""; $p[1]=""; $p[2]=""; $p[3]="";
	  $partype[$i]=substr($ctype, length("Content-type: "));
	  #printf("partype: $partype[$i]\n");
	  $parvalue[$i]=join("\n", @p);
	  $parvalue[$i]=substr($parvalue[$i], 4);
          $parvalue[$i]=substr($parvalue[$i], 0, (length($parvalue[$i])-1));
	}
        $i++;
      }
    }
  }

  #se ci sono parametri con nome  replicato, diventano un'unico parametro con
  #valori separati da ;
  my  $p, $r, $fn; my $cnp=0;
  my @pnm; my  @pvl;
  foreach $p(@parname)
  { $fn=0;
    my $cni=0;
    foreach $r(@pnm)
    { if  ($p eq $r)
       { $pvl[$cni]=$pvl[$cni].";".$parvalue[$cnp];
	 $fn=1;
       };
       $cni++;
    };
    if ( $fn==0 )
    { $pnm[$#pnm+1]=$p;
      $pvl[$#pvl+1]=$parvalue[$cnp];
    };
    $cnp++;
  };
  @parname=@pnm;
  @parvalue=@pvl;

  #qui mostro tutti i parametri. Rielaboro quelli corrispondenti a multicheck
  # e piu'avanti anche a multilist.
  my $p; my $cnt=0;
  my  @pv; my @tohide; my  @hideval;
  foreach $p(@parname)
  { if (substr($p, 0, length("EWcHECK_")) eq  "EWcHECK_")
    { $p=substr($p, length("EWcHECK_"));
      my $n=int($p);
      $p=substr($p, length($n));
#      print "Par ".$p." vale ".$parvalue[$cnt]."<br>";

      my $fnd=0;
      for ($n=0; $n<=$#tohide; $n++)
      { if ($p eq $tohide[$n])
        { $fnd=1;
          $hideval[$n]=$hideval[$n].";".$parvalue[$cnt];
        };
      };
      if ($fnd!=1)
      { $n=$#tohide+1;
        $tohide[$n]=$p;
        $hideval[$n]=$parvalue[$cnt];
      };
    };
    $cnt++;
  };
  $cnt=0;
  foreach $p(@tohide)
  { my $a;
    my $ctb=0;
    foreach $a(@parname)
    { if ($a eq $p) { $parvalue[$ctb]=$hideval[$cnt]; }
      $ctb++;
    }
    $cnt++;
  };
}

sub checkpath()
{ my $a=$EWB_tabpath;
  if (substr($a,length($a)-1,1) ne "/")
  { $a=$a."/";
  }; return $a;
};

sub get_par($)
{ my ($name)=@_;
  my $res="";
  my $n; my $i=0;
  foreach $n(@parname)
  { if ($name eq EWconv($n))
    { if ($fltype[$i] ne "file") { $res=EWconv($parvalue[$i]); }
      else { $res=$parvalue[$i]; };
    };
    $i++;
  };
  return $res;
};

#funzioni predefinite
sub EWgetenvvar($)
{
  my $r;
  $r= $ENV{$_[0]};
  return $r;
}

#2.10 fine
sub tab_wlock($)
{ my $name=$_[0];
  $name=((split(":", $name))[0]);
  my $i; my $d=0;
  if (!tab_islock($name))
  { while (($i<10)&&($d==0))
    { if (!(open (III, "< ".checkpath()."TB".$name.".lck")))
      { if (!(open (OOO, "> ".checkpath()."TB".$name.".lck")))
        { print  "Attenzione: non posso creare files.\n";
          exit(0);
        };
        close OOO;$d=1;
      }
      else
      { close III; sleep (1); $i++;
      }
    }
  }
  push @EWlocked, $name;
}

sub tab_unlock($)
{ my $name=$_[0];
  $name=((split(":", $name))[0]);
  my @a; my $l;
  my $count=0;
  foreach $l(@EWlocked)
  { if (($l ne $name) || ($count>0)) { push @a,$l; }
    if ($l eq $name) {++$count; };
  }
  @EWlocked=@a;
  if ($count=1) { unlink(checkpath()."TB".$name.".lck"); };
}

sub tab_read($)
{ #esegue la lettura di una tabella gia bloccata.
  my @t=split(":", $_[0]);
  open III,"< ".checkpath().".TB$t[0].tab";
    my $k=join("",<III>);
    my @r=split("\n",$k);
  close III;
  return @r;
};
sub addchar($)
{ my $a=join("#",split "<EWB_ASTErISCO>", $_[0]);
  $a=join(chr(0x0D),split("<EWB_LineFEEd>", $a));
  return join("\n", split("<EWB_CARRIaGErETURN>", $a));
}

sub CreateForm
{ #nomecampo, valore, tipo campo, nome a video
  my ($n,$v,$t,$vidname)=@_;
  if ($t eq "hidden")
  { #conversione di un campo hidden, analoga a push
    $v="HidDenFieldDaTa".toasc($v);
  }
  else
  { if (($t ne "textarea")&&($t ne "info"))
    { $v=join("%22", (split "\"", $v));
      $v=join("%09", (split "\t", $v));
      $v=join("%0A", (split "\n", $v));
      $v=join("%3C", (split "<", $v));
    };
  };
  my @f=split(":", $EWB_format);
  if ($f[0]<1) {$f[0]=12; };
  if ($f[1]<1) {$f[1]=5; };

  my $res;
  my $vn=$vidname;
  if (length($vidname) <2) { $vidname=$n; };
  $res="<table border=0><tr><td>$vidname</td><td>";

  if (($t eq "submit") && (length($vn)<2)) { $res="<table border=0><tr><td></td><td>"; };
  if ($t eq "file")
  { $res=$res."<input name=\"$n\" value=\"\" type=file>"; }
  if ($t eq "text")
  { $res=$res."<input name=\"$n\" value=\"$v\" size=".$f[0].">"; }
  if ($t eq "password")
  { $res=$res."<input name=\"$n\" type=password value=\"$v\" size=".$f[0].">"; }
  if ($t eq "hidden")
  { $res="<input name=\"$n\" type=hidden value=\"$v\">"; }
  if ($t eq "checkbox")
  { $res=$res."<input name=\"$n\" type=checkbox value=\"1\">"; }
  if ($t eq "info")
  { $res="<table border=0><tr><td><b> $v </b>"; }
  if ($t eq "textarea")
  { $res=$res."<textarea name=\"$n\" cols=".$f[0]." rows=".$f[1].">$v</textarea>"; }
  #tipi composti
  if ($t eq "option") { $res=$res."\n<select name=\"$n\">"; }
  if ($t eq "options") { $res=$res."\n<select name=\"$n\" multiple>"; }
  my @v=split(/;/,$v); my $p;

  if ($t eq "checks")
  { $res=$res."<input name=\"$n\" type=hidden value=\"\">\n";
  }

  my $sep; if ($f[2] eq "v") { $sep="<br>"; } else{ $sep=" &nbsp; "; };
  my $counter=0;
  foreach $p(@v)
  {
    if ($t eq "checks")
    { my $CV="";
      if (substr($p, 0, 1) eq  "*")
      { $p=substr($p, 1);
        $CV="checked";
      };
      $res=$res."<input name=\"EWcHECK_".$counter.$n."\" type=checkbox $CV value=\"$p\">$p $sep\n";
      $counter++;
    }
    if ($t eq "links")
    {  my ($vid,$dest)=split("->", $p);
       if ($dest eq "") { $dest=$vid; };
       $res=$res."<a href=\"$dest\">$vid</a>$sep"; }
    if ($t eq "radio")
    { if ( substr($p,0,1) eq "*")
      { $p=substr($p,1);
        $res=$res."<input type=radio name=\"$n\" value=\"$p\" checked>$p$sep";
      }
      else
      { $res=$res."<input type=radio name=\"$n\" value=\"$p\">$p$sep";
      };
    }
    if (($t eq "option") || ($t eq "options"))
    { if ( substr($p,0,1) eq "*")
      { $p=substr($p,1);
        $res=$res."<option value=\"$p\" selected>$p";
      }
      else
      { $res=$res."<option value=\"$p\">$p";
      };
     }
    if ($t eq "submit")
    { $res=$res."<input name=\"$n\" type=submit value=\"$p\">$sep"; }
  }
  if (($t eq "option")||($t eq "options")) { $res=$res."</select>"; }
  if ($t ne "hidden") { $res=$res."</td></tr></table>"; }
  return $res."\n";
}

#liste - conversione da e a ascii
sub stpop($)
{  my @a=split(/ /,$_[0]);
   $res=$a[$#a];
   $_[0]=substr($_[0],0,length($_[0])-(length($res)+1));
   return fromasc($res);
}

sub EWsplit($$)
{ my $a=""; my $p;
  foreach $p(split( $_[0], $_[1]))
  { $a=$a.toasc($p)." ";
  } return $a;
}

sub EWdate()
{ my @ti=localtime(time);
  return $ti[3]." ".($ti[4]+1)." ".($ti[5]+1900);
}


my @parname;
my @parvalue;
srand(time());
read_form_buffer();
#jumper area
if (get_par("EWjump")>0)
{ jumper(get_par("EWjump"));
};
my $ax,$bx,$cx,$dx,@as;
	my $TB_oggetti="oggetti:id:categoria:oggetto:costo";
	my $EWB_id=""; 
	my $EWB_categoria=""; 
	my $EWB_oggetto=""; 
	my $EWB_costo=""; 
		my $TB_predef="predef:categoria:nome:ids";
	my $EWB_categoria=""; 
	my $EWB_nome=""; 
	my $EWB_ids=""; 
		my $TB_lastmod="lastmod:data";
	my $EWB_data=""; 
		my $TB_carrello="carrello:ip:idss:quantita:data";
	my $EWB_ip=""; 
	my $EWB_idss=""; 
	my $EWB_quantita=""; 
	my $EWB_data=""; 
	
my $EWB_ts1;
	
my $EWB_ts2;
	
my $EWB_ts3;
	
my $EWB_soglia;
	$ax=122;
	$EWB_ts1=$ax;$ax=125;
	$EWB_ts2=$ax;$ax=133;
	$EWB_ts3=$ax;$ax=50;
	$EWB_soglia=$ax;
my $EWB_clip;
	$ax="REMOTE_HOST";
	$ax=EWgetenvvar($ax);
	$EWB_clip=$ax;$ax=$EWB_clip;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area100; };
	$ax="carrello non utilizzabile con il vostro browser<br>
scusate il disguido.";
	$ax=print join(($ax), split("<>",$EWB_template));
	goto areaend100;
	
area100:;
	;

areaend100:;
	
my $EWB_a;
	
my $EWB_b;
	$ax=";";
	push @as,$ax;
	$ax=(EWgetenvvar("QUERY_STRING"));
	$bx=pop @as;
	$ax=EWsplit($bx,$ax);
	$EWB_a=$ax;$ax=(EWgetenvvar("QUERY_STRING"));
	$EWB_b=$ax;$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	push @as,$ax;
	$ax="DEL=";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area101; };
	
my $EWB_code;
	$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_b;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$EWB_code=$ax;$ax="carrello:ip:idss:quantita:data";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  open rof,"> ".checkpath().".TB$n.bkp";
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area102:;
  if ($g > $#f) { goto area104; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_ip;
	push @as,$ax;
	$ax=$EWB_clip;
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_code;
	push @as,$ax;
	$ax=$EWB_idss;
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if ($ax) { goto area103;};
	print rof $l."\n";

area103:;
  $g=$g+1;
  goto area102;
area104: ;
	
  close rof;  
  #copia di un file sull altro
  open rif,checkpath().".TB$n.bkp";
  open rof, ">".checkpath().".TB$n.tab";
  my @fl=<rif>;
  my $rw;
  foreach $rw(@fl)
  { print rof $rw; };  
  close rif;
  close rof;
  tab_unlock($n);
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax="";
	$EWB_a=$ax;$ax="";
	$EWB_b=$ax;goto areaend101;
	
area101:;
	;

areaend101:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="SVUOTA";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area105; };
	
area106:;
	$ax=$EWB_a;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (! ($ax)) {goto area107;};
	
my $EWB_i;
	$ax=stpop($EWB_a);
	$EWB_i=$ax;$ax=(EWdate ());
	$EWB_data=$ax;$ax=$EWB_i;
	$EWB_idss=$ax;$ax=$EWB_clip;
	$EWB_ip=$ax;
my $EWB_q;
	$ax=1;
	$EWB_q=$ax;$ax="carrello:ip:idss:quantita:data";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  tab_unlock($n);
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area108:;
  if ($g > $#f) { goto area110; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_ip;
	push @as,$ax;
	$ax=$EWB_clip;
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_idss;
	push @as,$ax;
	$ax=$EWB_i;
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area109;};
	$ax=$EWB_q;
	push @as,$ax;
	$ax=$EWB_quantita;
	$bx=pop @as;
	$ax=$bx + $ax;
	$EWB_q=$ax;
area109:;
  $g=$g+1;
  goto area108;
area110: ;
	
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax="carrello:ip:idss:quantita:data";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  open rof,"> ".checkpath().".TB$n.bkp";
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area111:;
  if ($g > $#f) { goto area113; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_ip;
	push @as,$ax;
	$ax=$EWB_clip;
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_idss;
	push @as,$ax;
	$ax=$EWB_i;
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if ($ax) { goto area112;};
	print rof $l."\n";

area112:;
  $g=$g+1;
  goto area111;
area113: ;
	
  close rof;  
  #copia di un file sull altro
  open rif,checkpath().".TB$n.bkp";
  open rof, ">".checkpath().".TB$n.tab";
  my @fl=<rif>;
  my $rw;
  foreach $rw(@fl)
  { print rof $rw; };  
  close rif;
  close rof;
  tab_unlock($n);
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax=(EWdate ());
	$EWB_data=$ax;$ax=$EWB_i;
	$EWB_idss=$ax;$ax=$EWB_clip;
	$EWB_ip=$ax;$ax=$EWB_q;
	$EWB_quantita=$ax;$ax="carrello:ip:idss:quantita:data";
$ax=ewb_add($ax);
	goto area106;
	
area107:;
	$ax="<br>";
	print $ax;
	goto areaend105;
	
area105:;
	$ax="carrello:ip:idss:quantita:data";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  open rof,"> ".checkpath().".TB$n.bkp";
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area114:;
  if ($g > $#f) { goto area116; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_ip;
	push @as,$ax;
	$ax=$EWB_clip;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if ($ax) { goto area115;};
	print rof $l."\n";

area115:;
  $g=$g+1;
  goto area114;
area116: ;
	
  close rof;  
  #copia di un file sull altro
  open rif,checkpath().".TB$n.bkp";
  open rof, ">".checkpath().".TB$n.tab";
  my @fl=<rif>;
  my $rw;
  foreach $rw(@fl)
  { print rof $rw; };  
  close rif;
  close rof;
  tab_unlock($n);
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  
areaend105:;
	
my $EWB_res;
	$ax="
<a href=computers.cgi><img src=back.gif border=0></a>Torna ai listini
    
<a href=comp_carrello.cgi?SVUOTA><img src=svuota.gif border=0></a>
Svuota il carrello
<br><br>";
	$EWB_res=$ax;$ax=$EWB_res;
	push @as,$ax;
	$ax="<table><tr bgcolor=yellow><td> </td><td><b>Codice</b></td><td>
<b>Oggetto</b></td><td><b>Quantita</b></td></tr>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;
my $EWB_cst;
	$ax=0;
	$EWB_cst=$ax;$ax="carrello:ip:idss:quantita:data";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  tab_unlock($n);
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area117:;
  if ($g > $#f) { goto area119; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_ip;
	push @as,$ax;
	$ax=$EWB_clip;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area118;};
	$ax="oggetti:id:categoria:oggetto:costo";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  tab_unlock($n);
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area120:;
  if ($g > $#f) { goto area122; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_id;
	push @as,$ax;
	$ax=$EWB_idss;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area121;};
	$ax=$EWB_res;
	push @as,$ax;
	$ax="<tr bgcolor=\"#eeeeee\">
    <td><a href=\"comp_carrello.cgi?DEL=";
	push @as,$ax;
	$ax=$EWB_idss;
	push @as,$ax;
	$ax="\">
    <img src=del.gif border=0 width=16 height=16>
    </a></td>
        <td>";
	push @as,$ax;
	$ax=$EWB_idss;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax=$EWB_oggetto;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax=$EWB_quantita;
	push @as,$ax;
	$ax="</td></tr>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_quantita;
	$bx=pop @as;
	$ax=$bx * $ax;
	$bx=pop @as;
	$ax=$bx + $ax;
	$EWB_cst=$ax;
area121:;
  $g=$g+1;
  goto area120;
area122: ;
	
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  
area118:;
  $g=$g+1;
  goto area117;
area119: ;
	
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  
my $EWB_ca;
	$ax=0;
	$EWB_ca=$ax;$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_soglia;
	$bx=pop @as;
	$ax=($bx < $ax);
	push @as,$ax;
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=0;
	$bx=pop @as;
	$ax=($bx > $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area123; };
	$ax=$EWB_res;
	push @as,$ax;
	$ax="<font color=red>Il costo complessivo e' minore di ";
	push @as,$ax;
	$ax=$EWB_soglia;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	push @as,$ax;
	$ax="euro.<br>
  Al totale e' stata aggiunta una quota di costo fissa di 8.50 euro.<br></font>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;$ax=8.5;
	$EWB_ca=$ax;goto areaend123;
	
area123:;
	;

areaend123:;
	
my $EWB_a;
	
my $EWB_b;
	
my $EWB_c;
	$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_b;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	push @as,$ax;
	$ax=$EWB_ca;
	$bx=pop @as;
	$ax=$bx + $ax;
	$EWB_a=$ax;$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_b;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	push @as,$ax;
	$ax=$EWB_ca;
	$bx=pop @as;
	$ax=$bx + $ax;
	$EWB_b=$ax;$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_b;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	push @as,$ax;
	$ax=$EWB_ca;
	$bx=pop @as;
	$ax=$bx + $ax;
	$EWB_c=$ax;$ax=$EWB_a;
	push @as,$ax;
	$ax=0;
	$bx=pop @as;
	$ax=($bx > $ax);
	if (!($ax)) { goto area124; };
	$ax=$EWB_res;
	push @as,$ax;
	$ax="</table>
<table><tr><td>Costo con bonifico anticipato
</td><td>";
	push @as,$ax;
	$ax=$EWB_a;
	push @as,$ax;
	$ax="
</td><td>+IVA =";
	push @as,$ax;
	$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_b;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	push @as,$ax;
	$ax="
</td></tr>
<tr><td>Costo con pagamento alla consegna /a 30 gg.
</td><td>";
	push @as,$ax;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="
</td><td>+IVA =";
	push @as,$ax;
	$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_b;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	push @as,$ax;
	$ax="
</td></tr>
<tr><td>Costo con pagamento a 90 gg.
</td><td>";
	push @as,$ax;
	$ax=$EWB_c;
	push @as,$ax;
	$ax="
</td><td>+IVA =";
	push @as,$ax;
	$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_b;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_c;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	push @as,$ax;
	$ax="
</td></tr></table>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;goto areaend124;
	
area124:;
	$ax="</b>";
	push @as,$ax;
	$ax=$EWB_res;
	push @as,$ax;
	$ax="<br>Carrello vuoto<br>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;
areaend124:;
	
my $EWB_b;
	$ax="";
	$EWB_b=$ax;$ax=$EWB_cst;
	push @as,$ax;
	$ax=0;
	$bx=pop @as;
	$ax=($bx > $ax);
	if (!($ax)) { goto area125; };
	$ax="Prosegui con l' ordine";
	$EWB_b=$ax;goto areaend125;
	
area125:;
	;

areaend125:;
	my $form="";
	push @as,"res";
	push @as,$EWB_res;
	push @as,"info";
	push @as,"res";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"id\"") <0)
     { $form=$form.CreateForm("id", $EWB_id, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"oggetto\"") <0)
     { $form=$form.CreateForm("oggetto", $EWB_oggetto, "hidden");
     } 
    if (index($form, "name=\"costo\"") <0)
     { $form=$form.CreateForm("costo", $EWB_costo, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"nome\"") <0)
     { $form=$form.CreateForm("nome", $EWB_nome, "hidden");
     } 
    if (index($form, "name=\"ids\"") <0)
     { $form=$form.CreateForm("ids", $EWB_ids, "hidden");
     } 
    if (index($form, "name=\"data\"") <0)
     { $form=$form.CreateForm("data", $EWB_data, "hidden");
     } 
    if (index($form, "name=\"ip\"") <0)
     { $form=$form.CreateForm("ip", $EWB_ip, "hidden");
     } 
    if (index($form, "name=\"idss\"") <0)
     { $form=$form.CreateForm("idss", $EWB_idss, "hidden");
     } 
    if (index($form, "name=\"quantita\"") <0)
     { $form=$form.CreateForm("quantita", $EWB_quantita, "hidden");
     } 
    if (index($form, "name=\"data\"") <0)
     { $form=$form.CreateForm("data", $EWB_data, "hidden");
     } 
    if (index($form, "name=\"ts1\"") <0)
     { $form=$form.CreateForm("ts1", $EWB_ts1, "hidden");
     } 
    if (index($form, "name=\"ts2\"") <0)
     { $form=$form.CreateForm("ts2", $EWB_ts2, "hidden");
     } 
    if (index($form, "name=\"ts3\"") <0)
     { $form=$form.CreateForm("ts3", $EWB_ts3, "hidden");
     } 
    if (index($form, "name=\"soglia\"") <0)
     { $form=$form.CreateForm("soglia", $EWB_soglia, "hidden");
     } 
    if (index($form, "name=\"clip\"") <0)
     { $form=$form.CreateForm("clip", $EWB_clip, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"res\"") <0)
     { $form=$form.CreateForm("res", $EWB_res, "hidden");
     } 
    if (index($form, "name=\"cst\"") <0)
     { $form=$form.CreateForm("cst", $EWB_cst, "hidden");
     } 
    if (index($form, "name=\"ca\"") <0)
     { $form=$form.CreateForm("ca", $EWB_ca, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"c\"") <0)
     { $form=$form.CreateForm("c", $EWB_c, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
$form=$form.CreateForm("EWjump", 0+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.977837252038629\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab1;
lab1:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_id=get_par("id"); 
$EWB_categoria=get_par("categoria"); 
$EWB_oggetto=get_par("oggetto"); 
$EWB_costo=get_par("costo"); 
$EWB_categoria=get_par("categoria"); 
$EWB_nome=get_par("nome"); 
$EWB_ids=get_par("ids"); 
$EWB_data=get_par("data"); 
$EWB_ip=get_par("ip"); 
$EWB_idss=get_par("idss"); 
$EWB_quantita=get_par("quantita"); 
$EWB_data=get_par("data"); 
$EWB_ts1=get_par("ts1"); 
$EWB_ts2=get_par("ts2"); 
$EWB_ts3=get_par("ts3"); 
$EWB_soglia=get_par("soglia"); 
$EWB_clip=get_par("clip"); 
$EWB_a=get_par("a"); 
$EWB_b=get_par("b"); 
$EWB_res=get_par("res"); 
$EWB_cst=get_par("cst"); 
$EWB_ca=get_par("ca"); 
$EWB_a=get_par("a"); 
$EWB_b=get_par("b"); 
$EWB_c=get_par("c"); 
$EWB_b=get_par("b"); 
retlab1:;
$ax="18:5:h";
	$EWB_format=$ax;
my $EWB_nm;
	
my $EWB_adr;
	
my $EWB_tel;
	
my $EWB_iva;
	
my $EWB_modop;
	
my $EWB_inf;
	$ax="L' ordine va confermato dal nostro ufficio.<br>
Una volta completato il modulo d'ordine contattate telefonicamente il nostro
ufficio allo 0721 715476 per inviare il fax o l'e-mail e completare l' acquisto.
<br><br>";
	$EWB_inf=$ax;$ax="Prepara il modulo";
	$EWB_b=$ax;$ax="Bonifico anticipato;30 giorni;90 giorni";
	$EWB_modop=$ax;my $form="";
	$ax="Nome o ragione sociale";
	push @as,"nm";
	push @as,$EWB_nm;
	push @as,"text";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="Indirizzo";
	push @as,"adr";
	push @as,$EWB_adr;
	push @as,"text";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="Telefono";
	push @as,"tel";
	push @as,$EWB_tel;
	push @as,"text";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="Codice fiscale o partita IVA";
	push @as,"iva";
	push @as,$EWB_iva;
	push @as,"text";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="modo di pagamento";
	push @as,"modop";
	push @as,$EWB_modop;
	push @as,"option";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"id\"") <0)
     { $form=$form.CreateForm("id", $EWB_id, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"oggetto\"") <0)
     { $form=$form.CreateForm("oggetto", $EWB_oggetto, "hidden");
     } 
    if (index($form, "name=\"costo\"") <0)
     { $form=$form.CreateForm("costo", $EWB_costo, "hidden");
     } 
    if (index($form, "name=\"categoria\"") <0)
     { $form=$form.CreateForm("categoria", $EWB_categoria, "hidden");
     } 
    if (index($form, "name=\"nome\"") <0)
     { $form=$form.CreateForm("nome", $EWB_nome, "hidden");
     } 
    if (index($form, "name=\"ids\"") <0)
     { $form=$form.CreateForm("ids", $EWB_ids, "hidden");
     } 
    if (index($form, "name=\"data\"") <0)
     { $form=$form.CreateForm("data", $EWB_data, "hidden");
     } 
    if (index($form, "name=\"ip\"") <0)
     { $form=$form.CreateForm("ip", $EWB_ip, "hidden");
     } 
    if (index($form, "name=\"idss\"") <0)
     { $form=$form.CreateForm("idss", $EWB_idss, "hidden");
     } 
    if (index($form, "name=\"quantita\"") <0)
     { $form=$form.CreateForm("quantita", $EWB_quantita, "hidden");
     } 
    if (index($form, "name=\"data\"") <0)
     { $form=$form.CreateForm("data", $EWB_data, "hidden");
     } 
    if (index($form, "name=\"ts1\"") <0)
     { $form=$form.CreateForm("ts1", $EWB_ts1, "hidden");
     } 
    if (index($form, "name=\"ts2\"") <0)
     { $form=$form.CreateForm("ts2", $EWB_ts2, "hidden");
     } 
    if (index($form, "name=\"ts3\"") <0)
     { $form=$form.CreateForm("ts3", $EWB_ts3, "hidden");
     } 
    if (index($form, "name=\"soglia\"") <0)
     { $form=$form.CreateForm("soglia", $EWB_soglia, "hidden");
     } 
    if (index($form, "name=\"clip\"") <0)
     { $form=$form.CreateForm("clip", $EWB_clip, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"res\"") <0)
     { $form=$form.CreateForm("res", $EWB_res, "hidden");
     } 
    if (index($form, "name=\"cst\"") <0)
     { $form=$form.CreateForm("cst", $EWB_cst, "hidden");
     } 
    if (index($form, "name=\"ca\"") <0)
     { $form=$form.CreateForm("ca", $EWB_ca, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"c\"") <0)
     { $form=$form.CreateForm("c", $EWB_c, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"nm\"") <0)
     { $form=$form.CreateForm("nm", $EWB_nm, "hidden");
     } 
    if (index($form, "name=\"adr\"") <0)
     { $form=$form.CreateForm("adr", $EWB_adr, "hidden");
     } 
    if (index($form, "name=\"tel\"") <0)
     { $form=$form.CreateForm("tel", $EWB_tel, "hidden");
     } 
    if (index($form, "name=\"iva\"") <0)
     { $form=$form.CreateForm("iva", $EWB_iva, "hidden");
     } 
    if (index($form, "name=\"modop\"") <0)
     { $form=$form.CreateForm("modop", $EWB_modop, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
$form=$form.CreateForm("EWjump", 1+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.617346277318092\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab2;
lab2:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_id=get_par("id"); 
$EWB_categoria=get_par("categoria"); 
$EWB_oggetto=get_par("oggetto"); 
$EWB_costo=get_par("costo"); 
$EWB_categoria=get_par("categoria"); 
$EWB_nome=get_par("nome"); 
$EWB_ids=get_par("ids"); 
$EWB_data=get_par("data"); 
$EWB_ip=get_par("ip"); 
$EWB_idss=get_par("idss"); 
$EWB_quantita=get_par("quantita"); 
$EWB_data=get_par("data"); 
$EWB_ts1=get_par("ts1"); 
$EWB_ts2=get_par("ts2"); 
$EWB_ts3=get_par("ts3"); 
$EWB_soglia=get_par("soglia"); 
$EWB_clip=get_par("clip"); 
$EWB_a=get_par("a"); 
$EWB_b=get_par("b"); 
$EWB_res=get_par("res"); 
$EWB_cst=get_par("cst"); 
$EWB_ca=get_par("ca"); 
$EWB_a=get_par("a"); 
$EWB_b=get_par("b"); 
$EWB_c=get_par("c"); 
$EWB_b=get_par("b"); 
$EWB_nm=get_par("nm"); 
$EWB_adr=get_par("adr"); 
$EWB_tel=get_par("tel"); 
$EWB_iva=get_par("iva"); 
$EWB_modop=get_par("modop"); 
$EWB_inf=get_par("inf"); 
retlab2:;

my $EWB_rs;
	$ax="
<div align=right>
<a href=\"javascript:self.print();\"><img src=print.gif border=0></a>
Stampa<br></div>
<div align=left>
StudioIDEA Software di Enrico Betti<br>
Via Pergamino 38 <br>
61034 Fossombrone (PU)<br>
tel. 0721 715476 / 328 5757472<br>
www.w3n.it - enrico@w3n.it<br>
P.IVA 02032210417<br><br>
</div><div align=right>
";
	push @as,$ax;
	$ax=$EWB_nm;
	push @as,$ax;
	$ax="<br>
";
	push @as,$ax;
	$ax=$EWB_adr;
	push @as,$ax;
	$ax="<br>
tel: ";
	push @as,$ax;
	$ax=$EWB_tel;
	push @as,$ax;
	$ax="<br>
iva/cod_fisc:";
	push @as,$ax;
	$ax=$EWB_iva;
	push @as,$ax;
	$ax="<br>
</div>
<div align=center>
<b>Modulo d' ordine <br>
per acquisto hardware - pagamento ";
	push @as,$ax;
	$ax=$EWB_modop;
	push @as,$ax;
	$ax="
<br>
<table border=1><tr><td><b>Codice</b></td><td><b>Oggetto</b></td>
       <td><b>Quantita'</b></td><td><b>Costo</b></td></tr>

";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rs=$ax;$ax=0;
	$EWB_cst=$ax;$ax="carrello:ip:idss:quantita:data";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  tab_unlock($n);
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area126:;
  if ($g > $#f) { goto area128; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_ip;
	push @as,$ax;
	$ax=$EWB_clip;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area127;};
	$ax="oggetti:id:categoria:oggetto:costo";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  tab_unlock($n);
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area129:;
  if ($g > $#f) { goto area131; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_id;
	push @as,$ax;
	$ax=$EWB_idss;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area130;};
	$ax=$EWB_rs;
	push @as,$ax;
	$ax="<tr>
    <td>";
	push @as,$ax;
	$ax=$EWB_idss;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax=$EWB_oggetto;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax=$EWB_quantita;
	push @as,$ax;
	$ax="</td>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rs=$ax;
my $EWB_a;
	$ax=$EWB_modop;
	push @as,$ax;
	$ax="Bonifico anticipato";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area132; };
	$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_b;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_c;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	$EWB_a=$ax;goto areaend132;
	
area132:;
	;

areaend132:;
	$ax=$EWB_modop;
	push @as,$ax;
	$ax="30 giorni";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area133; };
	$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_b;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_c;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	$EWB_a=$ax;goto areaend133;
	
area133:;
	;

areaend133:;
	$ax=$EWB_modop;
	push @as,$ax;
	$ax="90 giorni";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area134; };
	$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_b;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_c;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	$EWB_a=$ax;goto areaend134;
	
area134:;
	;

areaend134:;
	$ax=$EWB_rs;
	push @as,$ax;
	$ax="<td>";
	push @as,$ax;
	$ax=$EWB_a;
	push @as,$ax;
	$ax=" eur</td></tr>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rs=$ax;$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_quantita;
	$bx=pop @as;
	$ax=$bx * $ax;
	$bx=pop @as;
	$ax=$bx + $ax;
	$EWB_cst=$ax;
area130:;
  $g=$g+1;
  goto area129;
area131: ;
	
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  
area127:;
  $g=$g+1;
  goto area126;
area128: ;
	
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax=0;
	$EWB_ca=$ax;$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_soglia;
	$bx=pop @as;
	$ax=($bx < $ax);
	push @as,$ax;
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=0;
	$bx=pop @as;
	$ax=($bx > $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area135; };
	$ax=$EWB_rs;
	push @as,$ax;
	$ax="<tr><td> - </td><td>Contributo spese</td><td>-</td>
   <td>8.50 eur</td></tr>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rs=$ax;$ax=8.5;
	$EWB_ca=$ax;goto areaend135;
	
area135:;
	;

areaend135:;
	$ax=$EWB_modop;
	push @as,$ax;
	$ax="Bonifico anticipato";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area136; };
	$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_b;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_c;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	push @as,$ax;
	$ax=$EWB_ca;
	$bx=pop @as;
	$ax=$bx + $ax;
	$EWB_a=$ax;goto areaend136;
	
area136:;
	;

areaend136:;
	$ax=$EWB_modop;
	push @as,$ax;
	$ax="30 giorni";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area137; };
	$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_b;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_c;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	push @as,$ax;
	$ax=$EWB_ca;
	$bx=pop @as;
	$ax=$bx + $ax;
	$EWB_a=$ax;goto areaend137;
	
area137:;
	;

areaend137:;
	$ax=$EWB_modop;
	push @as,$ax;
	$ax="90 giorni";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area138; };
	$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_b;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_c;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	push @as,$ax;
	$ax=$EWB_ca;
	$bx=pop @as;
	$ax=$bx + $ax;
	$EWB_a=$ax;goto areaend138;
	
area138:;
	;

areaend138:;
	$ax=$EWB_rs;
	push @as,$ax;
	$ax="</table><br>
<div align=right>Costo complessivo: ";
	push @as,$ax;
	$ax=$EWB_a;
	push @as,$ax;
	$ax=" + IVA = ";
	push @as,$ax;
	$ax=$EWB_b;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=4;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_b;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_b;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_c;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_costo;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=120;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rs=$ax;$ax=$EWB_rs;
	push @as,$ax;
	$ax="<br>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rs=$ax;$ax=$EWB_rs;
	$ax=print join(($ax), split("<>",$EWB_template));
	exit(0); 

sub jumper($)
{ my $lab=$_[0];
if ($lab==1) { goto lab1; }
if ($lab==2) { goto lab2; }
};

#Amethist easyweb v. 5.23 - easy 
#Enrico Betti e Paride Dominici



sub ewb_add($)
{  my $cond="my \$line=";
   my $tab=$_[0];
   my $count=0;
   my @tot=split(":",$tab);
   tab_wlock($tab);
   foreach $field(@tot)
   { if ($count>0)
     { $cond=$cond."delchar(\$EWB_".$field.")";
       if ($count<$#tot) {$cond=$cond.".\"#\"."; };
     }
     $count++;
  }
  $cond.=";
if (!(open oof,\">> ".checkpath().".TB$tot[0].tab\"))
{ print \"\\nAttenzione: non posso creare files\\n\";
  exit(0);
};
print oof \$line.\"\\n\";
close oof;
";
  eval($cond);
  tab_unlock($tab);
  return ($res ne "");
};

sub EWconv($)
{ my $a=$_[0];
  $a=join("%3C", split("%253C", $a));
#  $a=~ tr/+/ /;
  $a=~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C",hex($1))/eg;
  $a=join("
", split("%0A", $a));
  $a=join("	", split("%09", $a));
  $a=join("\"", split("%22", $a));
  $a=join("<", split("%3C", $a));
  return $a;
}

sub tab_islock($)
{ my $name=$_[0];
  my $l; my $r=0;
  foreach $l(@EWlocked)
  { if ($l eq $name) {$r=1;}
  } return $r;
}

sub delchar($)
{ my $a=join("<EWB_ASTErISCO>",split "#", $_[0]);
  $a=join("<EWB_LineFEEd>", split(chr(0x0D), $a));
  return join("<EWB_CARRIaGErETURN>", split("\n", $a));
}

sub toasc($)
{ my $a=$_[0];
  my $r; my $i;
  for($i=0; $i<length($a); $i++)
  { my $k=ord(substr($a,$i,1));
    if ($k<16) {$r=$r."0";};
    $r=$r.sprintf("%x",$k);
  } return $r;
}

sub fromasc($)
{ my $a=$_[0];
  my $r; my $i;
  for($i=0; $i<length($a); $i=$i+2)
  { $r=$r.chr(hex(substr($a,$i,2)));
  } return $r;
}
