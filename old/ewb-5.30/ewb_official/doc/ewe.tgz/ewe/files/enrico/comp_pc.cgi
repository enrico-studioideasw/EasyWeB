#!/usr/bin/perl
print "Content-type: text/html\n\n"; 
#!/usr/bin/perl
my @EWlocked;
use IO::Socket;
my @fltype;
my $EWB_tabpath="./";
my $EWB_template="<html><body bgcolor=lightyellow><div align=center><></body></html>";
my $EWB_format="12:5:h";
my $EWB_sqldbase="";
my $EWB_sqlserver="";
srand(time());
my $PROGRAM_NAME;
{ my @a=split('/', $0);
  $PROGRAM_NAME=$a[$#a];
}
my $rlist="";

#gestione di forms multipart encoded
sub read_form_buffer()
{ my $b=$ENV{"CONTENT_LENGTH"};
  my $all=""; my $i;
  for ($i=0; $i<$b;)
  { $all=$all.<>;
    $i=length($all);
  };
  #pesco il boundary e ricostruisco, per quanto possibile, la query string.
  my $boundary=((split("\n", $all))[0]);
  my @all=split($boundary, $all);
  #se la prima riga termina con "name=", lo metto in query string
  $i=0;
  foreach $p(@all)
  {
    my ($a, $first)=(split("\n", $p));
    ($a, $b)=split(" name=\"", $first);
    if ($b ne "")
    { my $name;
      ($name, $b)=split("\"", $b);
      $parname[$i]=$name;
      #il value e' nella quarta riga.
      if (index($first, " filename=\"")<0)
      { my $rest;
          $rest="";
          for($k=4; $k<=(split("\n", $p)); $k++)
          { $rest=$rest.( (split("\n", $p))[$k]);
          };
        if ( ($rest) eq "")
        {
          $parvalue[$i]=((split("\n", $p))[3]);
	  $parvalue[$i]=substr($parvalue[$i], 0, length($parvalue[$i])-1);
	  $fltype[$i]="text";
          if (substr($parvalue[$i],0, length("HidDenFieldDaTa")) eq
                  ("HidDenFieldDaTa"))
          { $parvalue[$i]=fromasc(substr($parvalue[$i],length("HidDenFieldDaTa")));
          };
        }
        else
        { my $k;
          $parvalue[$i]="";
          for($k=3; $k<=(split("\n", $p)); $k++)
          { $parvalue[$i]=$parvalue[$i].( (split("\n", $p))[$k])."\n";
          };
	  $parvalue[$i]=substr($parvalue[$i], 0, length($parvalue[$i])-2);
        };
        $i++;

      } else
      { #cerco il content_type
        $fltype[$i]="file";
        my $ctype=((split("\n", $p))[2]);
	$ctype=substr($ctype, 0, length($ctype)-1);
	#print "Ctype: [$ctype]\n";
        $parvalue[$i] = "";
	if (substr(uc($ctype), 0, length("Content-type: "))  eq "CONTENT-TYPE: ")
	{ #trasferimento file di testo.
	  my @p=split("\n", $p);
	  $p[0]=""; $p[1]=""; $p[2]=""; $p[3]="";
	  $partype[$i]=substr($ctype, length("Content-type: "));
	  #printf("partype: $partype[$i]\n");
	  $parvalue[$i]=join("\n", @p);
	  $parvalue[$i]=substr($parvalue[$i], 4);
          $parvalue[$i]=substr($parvalue[$i], 0, (length($parvalue[$i])-1));
	}
        $i++;
      }
    }
  }

  #se ci sono parametri con nome  replicato, diventano un'unico parametro con
  #valori separati da ;
  my  $p, $r, $fn; my $cnp=0;
  my @pnm; my  @pvl;
  foreach $p(@parname)
  { $fn=0;
    my $cni=0;
    foreach $r(@pnm)
    { if  ($p eq $r)
       { $pvl[$cni]=$pvl[$cni].";".$parvalue[$cnp];
	 $fn=1;
       };
       $cni++;
    };
    if ( $fn==0 )
    { $pnm[$#pnm+1]=$p;
      $pvl[$#pvl+1]=$parvalue[$cnp];
    };
    $cnp++;
  };
  @parname=@pnm;
  @parvalue=@pvl;

  #qui mostro tutti i parametri. Rielaboro quelli corrispondenti a multicheck
  # e piu'avanti anche a multilist.
  my $p; my $cnt=0;
  my  @pv; my @tohide; my  @hideval;
  foreach $p(@parname)
  { if (substr($p, 0, length("EWcHECK_")) eq  "EWcHECK_")
    { $p=substr($p, length("EWcHECK_"));
      my $n=int($p);
      $p=substr($p, length($n));
#      print "Par ".$p." vale ".$parvalue[$cnt]."<br>";

      my $fnd=0;
      for ($n=0; $n<=$#tohide; $n++)
      { if ($p eq $tohide[$n])
        { $fnd=1;
          $hideval[$n]=$hideval[$n].";".$parvalue[$cnt];
        };
      };
      if ($fnd!=1)
      { $n=$#tohide+1;
        $tohide[$n]=$p;
        $hideval[$n]=$parvalue[$cnt];
      };
    };
    $cnt++;
  };
  $cnt=0;
  foreach $p(@tohide)
  { my $a;
    my $ctb=0;
    foreach $a(@parname)
    { if ($a eq $p) { $parvalue[$ctb]=$hideval[$cnt]; }
      $ctb++;
    }
    $cnt++;
  };
}

sub get_par($)
{ my ($name)=@_;
  my $res="";
  my $n; my $i=0;
  foreach $n(@parname)
  { if ($name eq EWconv($n))
    { if ($fltype[$i] ne "file") { $res=EWconv($parvalue[$i]); }
      else { $res=$parvalue[$i]; };
    };
    $i++;
  };
  return $res;
};

#funzioni predefinite
sub tab_wlock($)
{ my $name=$_[0];
  $name=((split(":", $name))[0]);
  my $i; my $d=0;
  if (!tab_islock($name))
  { while (($i<10)&&($d==0))
    { if (!(open (III, "< ".checkpath()."TB".$name.".lck")))
      { if (!(open (OOO, "> ".checkpath()."TB".$name.".lck")))
        { print  "Attenzione: non posso creare files.\n";
          exit(0);
        };
        close OOO;$d=1;
      }
      else
      { close III; sleep (1); $i++;
      }
    }
  }
  push @EWlocked, $name;
}

sub tab_unlock($)
{ my $name=$_[0];
  $name=((split(":", $name))[0]);
  my @a; my $l;
  my $count=0;
  foreach $l(@EWlocked)
  { if (($l ne $name) || ($count>0)) { push @a,$l; }
    if ($l eq $name) {++$count; };
  }
  @EWlocked=@a;
  if ($count=1) { unlink(checkpath()."TB".$name.".lck"); };
}

sub tab_read($)
{ #esegue la lettura di una tabella gia bloccata.
  my @t=split(":", $_[0]);
  open III,"< ".checkpath().".TB$t[0].tab";
    my $k=join("",<III>);
    my @r=split("\n",$k);
  close III;
  return @r;
};
sub addchar($)
{ my $a=join("#",split "<EWB_ASTErISCO>", $_[0]);
  $a=join(chr(0x0D),split("<EWB_LineFEEd>", $a));
  return join("\n", split("<EWB_CARRIaGErETURN>", $a));
}

sub stpop($)
{  my @a=split(/ /,$_[0]);
   $res=$a[$#a];
   $_[0]=substr($_[0],0,length($_[0])-(length($res)+1));
   return fromasc($res);
}

sub EWsplit($$)
{ my $a=""; my $p;
  foreach $p(split( $_[0], $_[1]))
  { $a=$a.toasc($p)." ";
  } return $a;
}


my @parname;
my @parvalue;
srand(time());
read_form_buffer();
#jumper area
if (get_par("EWjump")>0)
{ jumper(get_par("EWjump"));
};
my $ax,$bx,$cx,$dx,@as;
	my $TB_oggetti="oggetti:id:categoria:oggetto:costo";
	my $EWB_id=""; 
	my $EWB_categoria=""; 
	my $EWB_oggetto=""; 
	my $EWB_costo=""; 
		my $TB_predef="predef:categoria:nome:ids";
	my $EWB_categoria=""; 
	my $EWB_nome=""; 
	my $EWB_ids=""; 
		my $TB_lastmod="lastmod:data";
	my $EWB_data=""; 
		my $TB_carrello="carrello:ip:idss:quantita:data";
	my $EWB_ip=""; 
	my $EWB_idss=""; 
	my $EWB_quantita=""; 
	my $EWB_data=""; 
	
my $EWB_ts1;
	
my $EWB_ts2;
	
my $EWB_ts3;
	
my $EWB_soglia;
	$ax=122;
	$EWB_ts1=$ax;$ax=125;
	$EWB_ts2=$ax;$ax=133;
	$EWB_ts3=$ax;$ax=50;
	$EWB_soglia=$ax;
my $EWB_oldcat;
	
my $EWB_res;
	$ax="";
	$EWB_oldcat=$ax;$ax="
<a name=top>
<a href=computers.cgi><img src=back.gif border=0>Indietro</a><br>
      <table border=0 width=90%>";
	$EWB_res=$ax;$ax="predef:categoria:nome:ids";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  tab_unlock($n);
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area100:;
  if ($g > $#f) { goto area102; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area101;};
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=$EWB_oldcat;
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area103; };
	$ax=$EWB_res;
	push @as,$ax;
	$ax="<tr><td width=70><a href=#top>
    <img src=up.gif border=0></a>
    </td><td><br>
    </td><td><br></td><td><br></td><td><br></td></tr>
    <tr bgcolor=yellow><td> </td><td><b><font size=-1>
    ";
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="</font></b>
    </td><td><b><font size=-1>bonifico anticipato</font></b>
    </td><td><b><font size=-1>alla consegna/30gg.</font></b>
    </td><td><b><font size=-1>90gg.</font></b>
    </td></tr>
    ";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;$ax=$EWB_categoria;
	$EWB_oldcat=$ax;goto areaend103;
	
area103:;
	;

areaend103:;
	$ax=$EWB_res;
	push @as,$ax;
	$ax="<tr bgcolor=\"#eeeeee\">
  <td><a href=\"comp_carrello.cgi?";
	push @as,$ax;
	$ax=$EWB_ids;
	push @as,$ax;
	$ax="\"><img src=carrello.gif border=0
  title=\"Aggiungi al carrello\"></a>

<a href=comp_carrello.cgi><img src=carrello1.gif border=0 title=\"Il tuo carrello\"></a>
      <br>
</td>
  <td><b><font size=-1>";
	push @as,$ax;
	$ax=$EWB_nome;
	push @as,$ax;
	$ax="</b><br>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;
my $EWB_a;
	
my $EWB_n;
	
my $EWB_cst;
	$ax=0;
	$EWB_cst=$ax;$ax=";";
	push @as,$ax;
	$ax=$EWB_ids;
	$bx=pop @as;
	$ax=EWsplit($bx,$ax);
	$EWB_a=$ax;$ax="";
	$EWB_n=$ax;
area104:;
	$ax=$EWB_a;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (! ($ax)) {goto area105;};
	
my $EWB_vn;
	$ax=stpop($EWB_a);
	$EWB_vn=$ax;$ax="oggetti:id:categoria:oggetto:costo";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  tab_unlock($n);
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area106:;
  if ($g > $#f) { goto area108; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_vn;
	push @as,$ax;
	$ax=$EWB_id;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area109; };
	$ax=$EWB_oggetto;
	push @as,$ax;
	$ax="<br>";
	push @as,$ax;
	$ax=$EWB_n;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_n=$ax;$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_costo;
	$bx=pop @as;
	$ax=$bx + $ax;
	$EWB_cst=$ax;goto areaend109;
	
area109:;
	;

areaend109:;
	
area107:;
  $g=$g+1;
  goto area106;
area108: ;
	
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  goto area104;
	
area105:;
	$ax=$EWB_res;
	push @as,$ax;
	$ax=$EWB_n;
	push @as,$ax;
	$ax="</font><br>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;$ax=$EWB_res;
	push @as,$ax;
	$ax="</td><td><font size=-1>";
	push @as,$ax;
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	push @as,$ax;
	$ax=" eur</font></td><td><font size=-1>";
	push @as,$ax;
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	push @as,$ax;
	$ax=" eur</font></td><td><font size=-1>";
	push @as,$ax;
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts1;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts2;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	$ax=$EWB_cst;
	push @as,$ax;
	$ax=$EWB_ts3;
	$bx=pop @as;
	$ax=$bx * $ax;
	$ax=int($ax);
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$ax=$bx / $ax;
	push @as,$ax;
	$ax=" eur</font></td></tr>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;
area101:;
  $g=$g+1;
  goto area100;
area102: ;
	
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax=$EWB_res;
	push @as,$ax;
	$ax="</table>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;$ax=$EWB_res;
	$ax=print join(($ax), split("<>",$EWB_template));
	exit(0); 

sub jumper($)
{ my $lab=$_[0];
};

#Amethist easyweb v. 5.23 - easy 
#Enrico Betti e Paride Dominici



sub checkpath()
{ my $a=$EWB_tabpath;
  if (substr($a,length($a)-1,1) ne "/")
  { $a=$a."/";
  }; return $a;
};

sub EWconv($)
{ my $a=$_[0];
  $a=join("%3C", split("%253C", $a));
#  $a=~ tr/+/ /;
  $a=~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C",hex($1))/eg;
  $a=join("
", split("%0A", $a));
  $a=join("	", split("%09", $a));
  $a=join("\"", split("%22", $a));
  $a=join("<", split("%3C", $a));
  return $a;
}

sub tab_islock($)
{ my $name=$_[0];
  my $l; my $r=0;
  foreach $l(@EWlocked)
  { if ($l eq $name) {$r=1;}
  } return $r;
}

sub toasc($)
{ my $a=$_[0];
  my $r; my $i;
  for($i=0; $i<length($a); $i++)
  { my $k=ord(substr($a,$i,1));
    if ($k<16) {$r=$r."0";};
    $r=$r.sprintf("%x",$k);
  } return $r;
}

sub fromasc($)
{ my $a=$_[0];
  my $r; my $i;
  for($i=0; $i<length($a); $i=$i+2)
  { $r=$r.chr(hex(substr($a,$i,2)));
  } return $r;
}
