#!/usr/bin/perl
print "Content-type: text/html\n\n"; 
#!/usr/bin/perl
my @EWlocked;
use IO::Socket;
my @fltype;
my $EWB_tabpath="./";
my $EWB_template="<html><body bgcolor=lightyellow><div align=center><></body></html>";
my $EWB_format="12:5:h";
my $EWB_sqldbase="";
my $EWB_sqlserver="";
srand(time());
my $PROGRAM_NAME;
{ my @a=split('/', $0);
  $PROGRAM_NAME=$a[$#a];
}
my $rlist="";

#gestione di forms multipart encoded
sub read_form_buffer()
{ my $b=$ENV{"CONTENT_LENGTH"};
  my $all=""; my $i;
  for ($i=0; $i<$b;)
  { $all=$all.<>;
    $i=length($all);
  };
  #pesco il boundary e ricostruisco, per quanto possibile, la query string.
  my $boundary=((split("\n", $all))[0]);
  my @all=split($boundary, $all);
  #se la prima riga termina con "name=", lo metto in query string
  $i=0;
  foreach $p(@all)
  {
    my ($a, $first)=(split("\n", $p));
    ($a, $b)=split(" name=\"", $first);
    if ($b ne "")
    { my $name;
      ($name, $b)=split("\"", $b);
      $parname[$i]=$name;
      #il value e' nella quarta riga.
      if (index($first, " filename=\"")<0)
      { my $rest;
          $rest="";
          for($k=4; $k<=(split("\n", $p)); $k++)
          { $rest=$rest.( (split("\n", $p))[$k]);
          };
        if ( ($rest) eq "")
        {
          $parvalue[$i]=((split("\n", $p))[3]);
	  $parvalue[$i]=substr($parvalue[$i], 0, length($parvalue[$i])-1);
	  $fltype[$i]="text";
          if (substr($parvalue[$i],0, length("HidDenFieldDaTa")) eq
                  ("HidDenFieldDaTa"))
          { $parvalue[$i]=fromasc(substr($parvalue[$i],length("HidDenFieldDaTa")));
          };
        }
        else
        { my $k;
          $parvalue[$i]="";
          for($k=3; $k<=(split("\n", $p)); $k++)
          { $parvalue[$i]=$parvalue[$i].( (split("\n", $p))[$k])."\n";
          };
	  $parvalue[$i]=substr($parvalue[$i], 0, length($parvalue[$i])-2);
        };
        $i++;

      } else
      { #cerco il content_type
        $fltype[$i]="file";
        my $ctype=((split("\n", $p))[2]);
	$ctype=substr($ctype, 0, length($ctype)-1);
	#print "Ctype: [$ctype]\n";
        $parvalue[$i] = "";
	if (substr(uc($ctype), 0, length("Content-type: "))  eq "CONTENT-TYPE: ")
	{ #trasferimento file di testo.
	  my @p=split("\n", $p);
	  $p[0]=""; $p[1]=""; $p[2]=""; $p[3]="";
	  $partype[$i]=substr($ctype, length("Content-type: "));
	  #printf("partype: $partype[$i]\n");
	  $parvalue[$i]=join("\n", @p);
	  $parvalue[$i]=substr($parvalue[$i], 4);
          $parvalue[$i]=substr($parvalue[$i], 0, (length($parvalue[$i])-1));
	}
        $i++;
      }
    }
  }

  #se ci sono parametri con nome  replicato, diventano un'unico parametro con
  #valori separati da ;
  my  $p, $r, $fn; my $cnp=0;
  my @pnm; my  @pvl;
  foreach $p(@parname)
  { $fn=0;
    my $cni=0;
    foreach $r(@pnm)
    { if  ($p eq $r)
       { $pvl[$cni]=$pvl[$cni].";".$parvalue[$cnp];
	 $fn=1;
       };
       $cni++;
    };
    if ( $fn==0 )
    { $pnm[$#pnm+1]=$p;
      $pvl[$#pvl+1]=$parvalue[$cnp];
    };
    $cnp++;
  };
  @parname=@pnm;
  @parvalue=@pvl;

  #qui mostro tutti i parametri. Rielaboro quelli corrispondenti a multicheck
  # e piu'avanti anche a multilist.
  my $p; my $cnt=0;
  my  @pv; my @tohide; my  @hideval;
  foreach $p(@parname)
  { if (substr($p, 0, length("EWcHECK_")) eq  "EWcHECK_")
    { $p=substr($p, length("EWcHECK_"));
      my $n=int($p);
      $p=substr($p, length($n));
#      print "Par ".$p." vale ".$parvalue[$cnt]."<br>";

      my $fnd=0;
      for ($n=0; $n<=$#tohide; $n++)
      { if ($p eq $tohide[$n])
        { $fnd=1;
          $hideval[$n]=$hideval[$n].";".$parvalue[$cnt];
        };
      };
      if ($fnd!=1)
      { $n=$#tohide+1;
        $tohide[$n]=$p;
        $hideval[$n]=$parvalue[$cnt];
      };
    };
    $cnt++;
  };
  $cnt=0;
  foreach $p(@tohide)
  { my $a;
    my $ctb=0;
    foreach $a(@parname)
    { if ($a eq $p) { $parvalue[$ctb]=$hideval[$cnt]; }
      $ctb++;
    }
    $cnt++;
  };
}

sub get_par($)
{ my ($name)=@_;
  my $res="";
  my $n; my $i=0;
  foreach $n(@parname)
  { if ($name eq EWconv($n))
    { if ($fltype[$i] ne "file") { $res=EWconv($parvalue[$i]); }
      else { $res=$parvalue[$i]; };
    };
    $i++;
  };
  return $res;
};

#funzioni predefinite
sub EWload($)
{ open iif,"<".$_[0];
  my $a=join("",<iif>);
  close iif;
  return $a;
}

sub EWgetenvvar($)
{
  my $r;
  $r= $ENV{$_[0]};
  return $r;
}

#2.10 fine
sub tab_wlock($)
{ my $name=$_[0];
  $name=((split(":", $name))[0]);
  my $i; my $d=0;
  if (!tab_islock($name))
  { while (($i<10)&&($d==0))
    { if (!(open (III, "< ".checkpath()."TB".$name.".lck")))
      { if (!(open (OOO, "> ".checkpath()."TB".$name.".lck")))
        { print  "Attenzione: non posso creare files.\n";
          exit(0);
        };
        close OOO;$d=1;
      }
      else
      { close III; sleep (1); $i++;
      }
    }
  }
  push @EWlocked, $name;
}

sub tab_unlock($)
{ my $name=$_[0];
  $name=((split(":", $name))[0]);
  my @a; my $l;
  my $count=0;
  foreach $l(@EWlocked)
  { if (($l ne $name) || ($count>0)) { push @a,$l; }
    if ($l eq $name) {++$count; };
  }
  @EWlocked=@a;
  if ($count=1) { unlink(checkpath()."TB".$name.".lck"); };
}

sub tab_sort($$)
{ my ($name,$s)=@_; my $r=""; my $l;
  my $n=((split(":",$name))[0]);
  $name=substr($name,length($n)+1);
  my $p; my $c=0;
  foreach $p(split(":",$name))
  { if ($p eq $s) { $k=$c; };
    $c++;
  }
  my @b; $c=0;
  tab_wlock($n);
  open III,"<".checkpath().".TB$n.tab";
  my @a=(<III>); close III;
  foreach $p(@a)
  { my $t;
    my @p=split("#",$p);
    $t=$p[0];
    $p[0]=$p[$k];
    $p[$k]=$t;
    $b[$c]=join("#",@p);
    $c=$c+1;
  }
  @b=sort(@b);
  $c=0;
  foreach $p(@b)
  { my $t;
    my @p=split("#",$p);
    $t=$p[0];
    $p[0]=$p[$k];
    $p[$k]=$t;
    $a[$c]=join("#",@p);
    $c=$c+1;
  }
  open oof,"> ".checkpath().".TB$n.tab";
  foreach $l(@a)
  { print oof $l;
  }
  close oof; tab_unlock($n); return $r;
}
sub tab_read($)
{ #esegue la lettura di una tabella gia bloccata.
  my @t=split(":", $_[0]);
  open III,"< ".checkpath().".TB$t[0].tab";
    my $k=join("",<III>);
    my @r=split("\n",$k);
  close III;
  return @r;
};
sub addchar($)
{ my $a=join("#",split "<EWB_ASTErISCO>", $_[0]);
  $a=join(chr(0x0D),split("<EWB_LineFEEd>", $a));
  return join("\n", split("<EWB_CARRIaGErETURN>", $a));
}

sub stpop($)
{  my @a=split(/ /,$_[0]);
   $res=$a[$#a];
   $_[0]=substr($_[0],0,length($_[0])-(length($res)+1));
   return fromasc($res);
}

sub EWsplit($$)
{ my $a=""; my $p;
  foreach $p(split( $_[0], $_[1]))
  { $a=$a.toasc($p)." ";
  } return $a;
}


my @parname;
my @parvalue;
srand(time());
read_form_buffer();
#jumper area
if (get_par("EWjump")>0)
{ jumper(get_par("EWjump"));
};
my $ax,$bx,$cx,$dx,@as;
	my $TB_cats="cats:categoria:lingua:descrizione:aree:areeinfo:note";
	my $EWB_categoria=""; 
	my $EWB_lingua=""; 
	my $EWB_descrizione=""; 
	my $EWB_aree=""; 
	my $EWB_areeinfo=""; 
	my $EWB_note=""; 
		my $TB_order="order:ordine:lingua:categoria:sottocategorie";
	my $EWB_ordine=""; 
	my $EWB_lingua=""; 
	my $EWB_categoria=""; 
	my $EWB_sottocategorie=""; 
		my $TB_prodotti="prodotti:codice:categoria:gruppo:lingua:foto:stringa:stringainfo:notap";
	my $EWB_codice=""; 
	my $EWB_categoria=""; 
	my $EWB_gruppo=""; 
	my $EWB_lingua=""; 
	my $EWB_foto=""; 
	my $EWB_stringa=""; 
	my $EWB_stringainfo=""; 
	my $EWB_notap=""; 
	$ax="prodotti.htm";
	$ax=EWload($ax);
	$EWB_template=$ax;
my $EWB_qs;
	$ax=(EWgetenvvar("QUERY_STRING"));
	$EWB_qs=$ax;
my $EWB_lng;
	
my $EWB_vcat;
	$ax="";
	$EWB_vcat=$ax;$ax="order:ordine:lingua:categoria:sottocategorie";
push @as,$ax;
	$ax="ordine";
	$bx=pop @as;
	$ax=tab_sort($bx,$ax);$ax="&";
	push @as,$ax;
	$ax=$EWB_qs;
	$bx=pop @as;
	$ax=EWsplit($bx,$ax);
	$EWB_qs=$ax;$ax=stpop($EWB_qs);
	$EWB_vcat=$ax;$ax=stpop($EWB_qs);
	$EWB_lng=$ax;$ax=$EWB_lng;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area100; };
	$ax="Italiano";
	$EWB_lng=$ax;goto areaend100;
	
area100:;
	;

areaend100:;
	$ax=$EWB_vcat;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area101; };
	
my $EWB_res;
	$ax="<span style=\"font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: normal;
	color: #E90101;
	text-transform: uppercase;
        text-decoration: none;\"><ul>\n";
	$EWB_res=$ax;$ax="order:ordine:lingua:categoria:sottocategorie";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area102:;
  if ($g > $#f) { goto area104; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area103;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_lingua;
	push @as,$ax;
	$ax=$EWB_lng;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area103;};
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$EWB_categoria=$ax;$ax=$EWB_res;
	push @as,$ax;
	$ax="  <li class=\"testoRosso\">
<a href=\"index.cgi?";
	push @as,$ax;
	$ax=$EWB_lng;
	push @as,$ax;
	$ax="&";
	push @as,$ax;
	$ax=$EWB_ordine;
	push @as,$ax;
	$ax="&\" style=\"border-bottom-style: none;\">";
	push @as,$ax;
	$ax=$EWB_categoria;
	$ax=uc($ax);
	push @as,$ax;
	$ax="<br>\n";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;
area103:;
  $g=$g+1;
  goto area102;
area104:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax=$EWB_res;
	push @as,$ax;
	$ax="</ul></span>\n";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;$ax=$EWB_res;
	$ax=print join(($ax), split("<>",$EWB_template));
	exit (0);
	goto areaend101;
	
area101:;
	;

areaend101:;
	goto ENDEWBshowcat;
	
JMPEWBshowcat:
	my $EWB_ct = pop @varstack;
	my $EWB_size = pop @varstack;
	
my $EWB_rs;
	$ax=$EWB_size;
	push @as,$ax;
	$ax=0;
	$bx=pop @as;
	$ax=($bx > $ax);
	if (!($ax)) { goto area105; };
	$ax="<span style=\"font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 18px;
        font-weight: bolder;
        color: #E90101;
        border-top-width: 1px;
        border-right-width: 1px;
        border-bottom-width: 1px;
        border-left-width: 1px;
        border-top-style: none;
        border-right-style: none;
        border-bottom-style: none;
        border-left-style: none;
        border-top-color: #CC0000;
        border-right-color: #CC0000;
        border-bottom-color: #CC0000;
        border-left-color: #CC0000;\">
    ";
	push @as,$ax;
	$ax=$EWB_ct;
	push @as,$ax;
	$ax="
    </span><hr><br>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rs=$ax;goto areaend105;
	
area105:;
	$ax="<span style=\"font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 14px;
        color: #333333;
        font-weight: bolder;\"> 
    ";
	push @as,$ax;
	$ax=$EWB_ct;
	push @as,$ax;
	$ax="
    </span><br>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rs=$ax;
areaend105:;
	
my $EWB_ra;
	
my $EWB_rb;
	
my $EWB_ncampi;
	$ax="";
	$EWB_ra=$ax;$ax="";
	$EWB_rb=$ax;$ax=2;
	$EWB_ncampi=$ax;$ax=$EWB_rs;
	push @as,$ax;
	$ax="<table width=500 border=0 valign=top><tr><td>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rs=$ax;$ax="<table border=0 cellspacing=0 cellpadding=4 width=100%><tr valign=top>";
	$EWB_ra=$ax;
my $EWB_flds;
	
my $EWB_tmp;
	
my $EWB_nt;
	$ax="";
	$EWB_flds=$ax;$ax="";
	$EWB_tmp=$ax;$ax="cats:categoria:lingua:descrizione:aree:areeinfo:note";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area106:;
  if ($g > $#f) { goto area108; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area107;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=$EWB_ct;
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_lingua;
	push @as,$ax;
	$ax=$EWB_lng;
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area107;};
	$ax=$EWB_aree;
	$EWB_flds=$ax;$ax=$EWB_note;
	$EWB_nt=$ax;
area107:;
  $g=$g+1;
  goto area106;
area108:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax=$EWB_flds;
	$EWB_tmp=$ax;
area109:;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (! ($ax)) {goto area110;};
	
my $EWB_a;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	push @as,$ax;
	$ax=0;
	$bx=pop @as;
	$ax=($bx > $ax);
	if (!($ax)) { goto area111; };
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$EWB_a=$ax;$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=$EWB_a;
	$ax=length($ax);
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=$bx + $ax;
	push @as,$ax;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx);
	$EWB_tmp=$ax;goto areaend111;
	
area111:;
	$ax=$EWB_tmp;
	$EWB_a=$ax;$ax="";
	$EWB_tmp=$ax;
areaend111:;
	$ax=$EWB_a;
	$ax=length($ax);
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=($bx > $ax);
	push @as,$ax;
	$ax=$EWB_tmp;
	$ax=length($ax);
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=($bx > $ax);
	$bx=pop @as;
	$ax=$bx || $ax;
	if (!($ax)) { goto area112; };
	$ax=$EWB_ra;
	push @as,$ax;
	$ax="<td>
<span style=\"font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 10px;
        color: #333333;\";
><strong>";
	push @as,$ax;
	$ax=$EWB_a;
	push @as,$ax;
	$ax="</strong></span></td>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_ra=$ax;$ax=$EWB_ncampi;
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=$bx + $ax;
	$EWB_ncampi=$ax;goto areaend112;
	
area112:;
	;

areaend112:;
	goto area109;
	
area110:;
	$ax=$EWB_ra;
	push @as,$ax;
	$ax="<td></td><td></td><td></td></tr>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_ra=$ax;$ax="prodotti:codice:categoria:gruppo:lingua:foto:stringa:stringainfo:notap";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area113:;
  if ($g > $#f) { goto area115; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area114;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=$EWB_ct;
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_lingua;
	push @as,$ax;
	$ax=$EWB_lng;
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area114;};
	
my $EWB_cnt;
	$ax=0;
	$EWB_cnt=$ax;
my $EWB_modello;
	$ax=$EWB_stringa;
	$EWB_tmp=$ax;$ax=$EWB_ra;
	push @as,$ax;
	$ax="<tr valign=top>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_ra=$ax;
area116:;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (! ($ax)) {goto area117;};
	
my $EWB_a;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=$EWB_a;
	$ax=length($ax);
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=$bx + $ax;
	push @as,$ax;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	push @as,$ax;
	$ax=0;
	$bx=pop @as;
	$ax=($bx >= $ax);
	if (!($ax)) { goto area118; };
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=$EWB_a;
	$ax=length($ax);
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=$bx + $ax;
	push @as,$ax;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=$EWB_a;
	$ax=length($ax);
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=$bx + $ax;
	push @as,$ax;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$EWB_a=$ax;$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=$EWB_a;
	$ax=length($ax);
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=$bx + $ax;
	push @as,$ax;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=$EWB_a;
	$ax=length($ax);
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=$bx + $ax;
	push @as,$ax;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=$EWB_a;
	$ax=length($ax);
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=$bx + $ax;
	push @as,$ax;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx);
	$EWB_tmp=$ax;goto areaend118;
	
area118:;
	$ax=$EWB_tmp;
	$EWB_a=$ax;$ax="";
	$EWB_tmp=$ax;
areaend118:;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=$EWB_a;
	$ax=length($ax);
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=$bx + $ax;
	push @as,$ax;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_categoria;
	push @as,$ax;
	$ax="<BR>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=$EWB_a;
	$ax=length($ax);
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=$bx + $ax;
	push @as,$ax;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=index($bx,$ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=$EWB_a;
	$ax=length($ax);
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=$bx + $ax;
	push @as,$ax;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx);
	$ax=$EWB_a;
	push @as,$ax;
	$ax="<VENTOLA>";
	$bx=pop @as;
	$ax=index($bx,$ax);
	push @as,$ax;
	$ax=0;
	$bx=pop @as;
	$ax=($bx >= $ax);
	if (!($ax)) { goto area119; };
	$ax="<img src=v.gif alt=ventilata>";
	$EWB_a=$ax;goto areaend119;
	
area119:;
	;

areaend119:;
	$ax=$EWB_a;
	$ax=length($ax);
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=($bx > $ax);
	push @as,$ax;
	$ax=$EWB_tmp;
	$ax=length($ax);
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=($bx > $ax);
	$bx=pop @as;
	$ax=$bx || $ax;
	if (!($ax)) { goto area120; };
	$ax=$EWB_ra;
	push @as,$ax;
	$ax="<td style=\"border-top: 1px solid #CCCCCC;\">
<span style=\"font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 10px;
        color: #333333;
        border-top: 1px none #CCCCCC;
        border-right: 1px none #CCCCCC;
        border-bottom: 1px none #CCCCCC;
        border-left: 1px none #CCCCCC;\">
";
	push @as,$ax;
	$ax=$EWB_a;
	push @as,$ax;
	$ax="</span></td>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_ra=$ax;$ax=$EWB_cnt;
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=($bx == $ax);
	if (!($ax)) { goto area121; };
	$ax=$EWB_a;
	$EWB_modello=$ax;goto areaend121;
	
area121:;
	;

areaend121:;
	$ax=$EWB_cnt;
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=$bx + $ax;
	$EWB_cnt=$ax;goto areaend120;
	
area120:;
	;

areaend120:;
	goto area116;
	
area117:;
	
area122:;
	$ax=$EWB_cnt;
	push @as,$ax;
	$ax=$EWB_ncampi;
	$bx=pop @as;
	$ax=($bx < $ax);
	if (! ($ax)) {goto area123;};
	$ax=$EWB_ra;
	push @as,$ax;
	$ax="<td></td>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_ra=$ax;$ax=$EWB_cnt;
	push @as,$ax;
	$ax=1;
	$bx=pop @as;
	$ax=$bx + $ax;
	$EWB_cnt=$ax;goto area122;
	
area123:;
	$ax=$EWB_ra;
	push @as,$ax;
	$ax="<td>
<a href=\"info.cgi?";
	push @as,$ax;
	$ax=$EWB_codice;
	push @as,$ax;
	$ax="\">
<span style=\"font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 10px;
        color: #333333;
        border-top: 1px solid #CCCCCC;
        border-right: 1px none #CCCCCC;
        border-bottom: 1px none #CCCCCC;
        border-left: 1px none #CCCCCC;\">
info</span></a>
</td></tr>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_ra=$ax;$ax=$EWB_foto;
	push @as,$ax;
	$ax=0;
	$bx=pop @as;
	$ax=($bx > $ax);
	if (!($ax)) { goto area124; };
	$ax=$EWB_rb;
	push @as,$ax;
	$ax="
<span style=\"font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 9px;
        color: #999999;
        font-style: italic;\">
<a href=img_";
	push @as,$ax;
	$ax=$EWB_codice;
	push @as,$ax;
	$ax=".jpg><img src=\"img_";
	push @as,$ax;
	$ax=$EWB_codice;
	push @as,$ax;
	$ax=".jpg\" width=80 
border=0></a><br>";
	push @as,$ax;
	$ax=$EWB_modello;
	push @as,$ax;
	$ax="<br></span>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rb=$ax;goto areaend124;
	
area124:;
	;

areaend124:;
	
area114:;
  $g=$g+1;
  goto area113;
area115:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax=$EWB_ra;
	push @as,$ax;
	$ax="</table>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_ra=$ax;$ax=$EWB_rs;
	push @as,$ax;
	$ax=$EWB_ra;
	push @as,$ax;
	$ax="</td><td valign=top>";
	push @as,$ax;
	$ax=$EWB_rb;
	push @as,$ax;
	$ax="</td></tr></table>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_rs=$ax;$ax=$EWB_rs;
	push @as,$ax;
	$ax="<br>";
	$bx=pop @as;
	$ax=$bx.$ax;
	print $ax;
	goto (pop @varstack);
	
ENDEWBshowcat:
	;
	
my $EWB_subcat;
	
my $EWB_tmp;
	
my $EWB_ctname;
	$ax="";
	$EWB_ctname=$ax;$ax="order:ordine:lingua:categoria:sottocategorie";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area125:;
  if ($g > $#f) { goto area127; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area126;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_vcat;
	push @as,$ax;
	$ax=$EWB_ordine;
	$bx=pop @as;
	$ax=($bx eq $ax);
	push @as,$ax;
	$ax=$EWB_lng;
	push @as,$ax;
	$ax=$EWB_lingua;
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area126;};
	$ax=$EWB_sottocategorie;
	$EWB_subcat=$ax;$ax=$EWB_categoria;
	$EWB_ctname=$ax;
area126:;
  $g=$g+1;
  goto area125;
area127:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax=";";
	push @as,$ax;
	$ax=$EWB_subcat;
	$bx=pop @as;
	$ax=EWsplit($bx,$ax);
	$EWB_subcat=$ax;$ax="";
	$EWB_tmp=$ax;
area128:;
	$ax=$EWB_subcat;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (! ($ax)) {goto area129;};
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax=stpop($EWB_subcat);
	push @as,$ax;
	$ax=";";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_tmp=$ax;goto area128;
	
area129:;
	
my $EWB_tp;
	
my $EWB_ta;
	
my $EWB_tb;
	$ax="<>";
	push @as,$ax;
	$ax=$EWB_template;
	$bx=pop @as;
	$ax=EWsplit($bx,$ax);
	$EWB_tp=$ax;$ax=stpop($EWB_tp);
	$EWB_tb=$ax;$ax=stpop($EWB_tp);
	$EWB_ta=$ax;$ax=$EWB_ta;
	print $ax;
	push @varstack, area130;
	$ax=1;
	push @varstack, $ax;
	$ax=$EWB_ctname;
	push @varstack, $ax;
	goto JMPEWBshowcat;
	
area130:
	$ax=";";
	push @as,$ax;
	$ax=$EWB_tmp;
	$bx=pop @as;
	$ax=EWsplit($bx,$ax);
	$EWB_tmp=$ax;
area132:;
	$ax=$EWB_tmp;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (! ($ax)) {goto area133;};
	$ax=stpop($EWB_tmp);
	$EWB_subcat=$ax;$ax=$EWB_subcat;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area134; };
	push @varstack, area135;
	$ax=0;
	push @varstack, $ax;
	$ax=$EWB_subcat;
	push @varstack, $ax;
	goto JMPEWBshowcat;
	
area135:
	goto areaend134;
	
area134:;
	;

areaend134:;
	goto area132;
	
area133:;
	$ax=$EWB_tb;
	print $ax;
	exit(0); 

sub jumper($)
{ my $lab=$_[0];
};

#Amethist easyweb v. 5.23 - easy 
#Enrico Betti e Paride Dominici



sub checkpath()
{ my $a=$EWB_tabpath;
  if (substr($a,length($a)-1,1) ne "/")
  { $a=$a."/";
  }; return $a;
};

sub EWconv($)
{ my $a=$_[0];
  $a=join("%3C", split("%253C", $a));
#  $a=~ tr/+/ /;
  $a=~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C",hex($1))/eg;
  $a=join("
", split("%0A", $a));
  $a=join("	", split("%09", $a));
  $a=join("\"", split("%22", $a));
  $a=join("<", split("%3C", $a));
  return $a;
}

sub tab_islock($)
{ my $name=$_[0];
  my $l; my $r=0;
  foreach $l(@EWlocked)
  { if ($l eq $name) {$r=1;}
  } return $r;
}

sub toasc($)
{ my $a=$_[0];
  my $r; my $i;
  for($i=0; $i<length($a); $i++)
  { my $k=ord(substr($a,$i,1));
    if ($k<16) {$r=$r."0";};
    $r=$r.sprintf("%x",$k);
  } return $r;
}

sub fromasc($)
{ my $a=$_[0];
  my $r; my $i;
  for($i=0; $i<length($a); $i=$i+2)
  { $r=$r.chr(hex(substr($a,$i,2)));
  } return $r;
}
