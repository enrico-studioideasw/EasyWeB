#!/usr/bin/perl
print "Content-type: text/html\n\n"; 
#!/usr/bin/perl
my @EWlocked;
use IO::Socket;
my @fltype;
my $EWB_tabpath="./";
my $EWB_template="<html><body bgcolor=lightyellow><div align=center><></body></html>";
my $EWB_format="12:5:h";
my $EWB_sqldbase="";
my $EWB_sqlserver="";
srand(time());
my $PROGRAM_NAME;
{ my @a=split('/', $0);
  $PROGRAM_NAME=$a[$#a];
}
my $rlist="";

#gestione di forms multipart encoded
sub read_form_buffer()
{ my $b=$ENV{"CONTENT_LENGTH"};
  my $all=""; my $i;
  for ($i=0; $i<$b;)
  { $all=$all.<>;
    $i=length($all);
  };
  #pesco il boundary e ricostruisco, per quanto possibile, la query string.
  my $boundary=((split("\n", $all))[0]);
  my @all=split($boundary, $all);
  #se la prima riga termina con "name=", lo metto in query string
  $i=0;
  foreach $p(@all)
  {
    my ($a, $first)=(split("\n", $p));
    ($a, $b)=split(" name=\"", $first);
    if ($b ne "")
    { my $name;
      ($name, $b)=split("\"", $b);
      $parname[$i]=$name;
      #il value e' nella quarta riga.
      if (index($first, " filename=\"")<0)
      { my $rest;
          $rest="";
          for($k=4; $k<=(split("\n", $p)); $k++)
          { $rest=$rest.( (split("\n", $p))[$k]);
          };
        if ( ($rest) eq "")
        {
          $parvalue[$i]=((split("\n", $p))[3]);
	  $parvalue[$i]=substr($parvalue[$i], 0, length($parvalue[$i])-1);
	  $fltype[$i]="text";
          if (substr($parvalue[$i],0, length("HidDenFieldDaTa")) eq
                  ("HidDenFieldDaTa"))
          { $parvalue[$i]=fromasc(substr($parvalue[$i],length("HidDenFieldDaTa")));
          };
        }
        else
        { my $k;
          $parvalue[$i]="";
          for($k=3; $k<=(split("\n", $p)); $k++)
          { $parvalue[$i]=$parvalue[$i].( (split("\n", $p))[$k])."\n";
          };
	  $parvalue[$i]=substr($parvalue[$i], 0, length($parvalue[$i])-2);
        };
        $i++;

      } else
      { #cerco il content_type
        $fltype[$i]="file";
        my $ctype=((split("\n", $p))[2]);
	$ctype=substr($ctype, 0, length($ctype)-1);
	#print "Ctype: [$ctype]\n";
        $parvalue[$i] = "";
	if (substr(uc($ctype), 0, length("Content-type: "))  eq "CONTENT-TYPE: ")
	{ #trasferimento file di testo.
	  my @p=split("\n", $p);
	  $p[0]=""; $p[1]=""; $p[2]=""; $p[3]="";
	  $partype[$i]=substr($ctype, length("Content-type: "));
	  #printf("partype: $partype[$i]\n");
	  $parvalue[$i]=join("\n", @p);
	  $parvalue[$i]=substr($parvalue[$i], 4);
          $parvalue[$i]=substr($parvalue[$i], 0, (length($parvalue[$i])-1));
	}
        $i++;
      }
    }
  }

  #se ci sono parametri con nome  replicato, diventano un'unico parametro con
  #valori separati da ;
  my  $p, $r, $fn; my $cnp=0;
  my @pnm; my  @pvl;
  foreach $p(@parname)
  { $fn=0;
    my $cni=0;
    foreach $r(@pnm)
    { if  ($p eq $r)
       { $pvl[$cni]=$pvl[$cni].";".$parvalue[$cnp];
	 $fn=1;
       };
       $cni++;
    };
    if ( $fn==0 )
    { $pnm[$#pnm+1]=$p;
      $pvl[$#pvl+1]=$parvalue[$cnp];
    };
    $cnp++;
  };
  @parname=@pnm;
  @parvalue=@pvl;

  #qui mostro tutti i parametri. Rielaboro quelli corrispondenti a multicheck
  # e piu'avanti anche a multilist.
  my $p; my $cnt=0;
  my  @pv; my @tohide; my  @hideval;
  foreach $p(@parname)
  { if (substr($p, 0, length("EWcHECK_")) eq  "EWcHECK_")
    { $p=substr($p, length("EWcHECK_"));
      my $n=int($p);
      $p=substr($p, length($n));
#      print "Par ".$p." vale ".$parvalue[$cnt]."<br>";

      my $fnd=0;
      for ($n=0; $n<=$#tohide; $n++)
      { if ($p eq $tohide[$n])
        { $fnd=1;
          $hideval[$n]=$hideval[$n].";".$parvalue[$cnt];
        };
      };
      if ($fnd!=1)
      { $n=$#tohide+1;
        $tohide[$n]=$p;
        $hideval[$n]=$parvalue[$cnt];
      };
    };
    $cnt++;
  };
  $cnt=0;
  foreach $p(@tohide)
  { my $a;
    my $ctb=0;
    foreach $a(@parname)
    { if ($a eq $p) { $parvalue[$ctb]=$hideval[$cnt]; }
      $ctb++;
    }
    $cnt++;
  };
}

sub checkpath()
{ my $a=$EWB_tabpath;
  if (substr($a,length($a)-1,1) ne "/")
  { $a=$a."/";
  }; return $a;
};

sub get_par($)
{ my ($name)=@_;
  my $res="";
  my $n; my $i=0;
  foreach $n(@parname)
  { if ($name eq EWconv($n))
    { if ($fltype[$i] ne "file") { $res=EWconv($parvalue[$i]); }
      else { $res=$parvalue[$i]; };
    };
    $i++;
  };
  return $res;
};

#funzioni predefinite
sub EWload($)
{ open iif,"<".$_[0];
  my $a=join("",<iif>);
  close iif;
  return $a;
}

sub EWgetenvvar($)
{
  my $r;
  $r= $ENV{$_[0]};
  return $r;
}

#2.10 fine
sub tab_wlock($)
{ my $name=$_[0];
  $name=((split(":", $name))[0]);
  my $i; my $d=0;
  if (!tab_islock($name))
  { while (($i<10)&&($d==0))
    { if (!(open (III, "< ".checkpath()."TB".$name.".lck")))
      { if (!(open (OOO, "> ".checkpath()."TB".$name.".lck")))
        { print  "Attenzione: non posso creare files.\n";
          exit(0);
        };
        close OOO;$d=1;
      }
      else
      { close III; sleep (1); $i++;
      }
    }
  }
  push @EWlocked, $name;
}

sub tab_unlock($)
{ my $name=$_[0];
  $name=((split(":", $name))[0]);
  my @a; my $l;
  my $count=0;
  foreach $l(@EWlocked)
  { if (($l ne $name) || ($count>0)) { push @a,$l; }
    if ($l eq $name) {++$count; };
  }
  @EWlocked=@a;
  if ($count=1) { unlink(checkpath()."TB".$name.".lck"); };
}

sub tab_sort($$)
{ my ($name,$s)=@_; my $r=""; my $l;
  my $n=((split(":",$name))[0]);
  $name=substr($name,length($n)+1);
  my $p; my $c=0;
  foreach $p(split(":",$name))
  { if ($p eq $s) { $k=$c; };
    $c++;
  }
  my @b; $c=0;
  tab_wlock($n);
  open III,"<".checkpath().".TB$n.tab";
  my @a=(<III>); close III;
  foreach $p(@a)
  { my $t;
    my @p=split("#",$p);
    $t=$p[0];
    $p[0]=$p[$k];
    $p[$k]=$t;
    $b[$c]=join("#",@p);
    $c=$c+1;
  }
  @b=sort(@b);
  $c=0;
  foreach $p(@b)
  { my $t;
    my @p=split("#",$p);
    $t=$p[0];
    $p[0]=$p[$k];
    $p[$k]=$t;
    $a[$c]=join("#",@p);
    $c=$c+1;
  }
  open oof,"> ".checkpath().".TB$n.tab";
  foreach $l(@a)
  { print oof $l;
  }
  close oof; tab_unlock($n); return $r;
}
sub tab_read($)
{ #esegue la lettura di una tabella gia bloccata.
  my @t=split(":", $_[0]);
  open III,"< ".checkpath().".TB$t[0].tab";
    my $k=join("",<III>);
    my @r=split("\n",$k);
  close III;
  return @r;
};
sub addchar($)
{ my $a=join("#",split "<EWB_ASTErISCO>", $_[0]);
  $a=join(chr(0x0D),split("<EWB_LineFEEd>", $a));
  return join("\n", split("<EWB_CARRIaGErETURN>", $a));
}

sub CreateForm
{ #nomecampo, valore, tipo campo, nome a video
  my ($n,$v,$t,$vidname)=@_;
  if ($t eq "hidden")
  { #conversione di un campo hidden, analoga a push
    $v="HidDenFieldDaTa".toasc($v);
  }
  else
  { if (($t ne "textarea")&&($t ne "info"))
    { $v=join("%22", (split "\"", $v));
      $v=join("%09", (split "\t", $v));
      $v=join("%0A", (split "\n", $v));
      $v=join("%3C", (split "<", $v));
    };
  };
  my @f=split(":", $EWB_format);
  if ($f[0]<1) {$f[0]=12; };
  if ($f[1]<1) {$f[1]=5; };

  my $res;
  my $vn=$vidname;
  if (length($vidname) <2) { $vidname=$n; };
  $res="<table border=0><tr><td>$vidname</td><td>";

  if (($t eq "submit") && (length($vn)<2)) { $res="<table border=0><tr><td></td><td>"; };
  if ($t eq "file")
  { $res=$res."<input name=\"$n\" value=\"\" type=file>"; }
  if ($t eq "text")
  { $res=$res."<input name=\"$n\" value=\"$v\" size=".$f[0].">"; }
  if ($t eq "password")
  { $res=$res."<input name=\"$n\" type=password value=\"$v\" size=".$f[0].">"; }
  if ($t eq "hidden")
  { $res="<input name=\"$n\" type=hidden value=\"$v\">"; }
  if ($t eq "checkbox")
  { $res=$res."<input name=\"$n\" type=checkbox value=\"1\">"; }
  if ($t eq "info")
  { $res="<table border=0><tr><td><b> $v </b>"; }
  if ($t eq "textarea")
  { $res=$res."<textarea name=\"$n\" cols=".$f[0]." rows=".$f[1].">$v</textarea>"; }
  #tipi composti
  if ($t eq "option") { $res=$res."\n<select name=\"$n\">"; }
  if ($t eq "options") { $res=$res."\n<select name=\"$n\" multiple>"; }
  my @v=split(/;/,$v); my $p;

  if ($t eq "checks")
  { $res=$res."<input name=\"$n\" type=hidden value=\"\">\n";
  }

  my $sep; if ($f[2] eq "v") { $sep="<br>"; } else{ $sep=" &nbsp; "; };
  my $counter=0;
  foreach $p(@v)
  {
    if ($t eq "checks")
    { my $CV="";
      if (substr($p, 0, 1) eq  "*")
      { $p=substr($p, 1);
        $CV="checked";
      };
      $res=$res."<input name=\"EWcHECK_".$counter.$n."\" type=checkbox $CV value=\"$p\">$p $sep\n";
      $counter++;
    }
    if ($t eq "links")
    {  my ($vid,$dest)=split("->", $p);
       if ($dest eq "") { $dest=$vid; };
       $res=$res."<a href=\"$dest\">$vid</a>$sep"; }
    if ($t eq "radio")
    { if ( substr($p,0,1) eq "*")
      { $p=substr($p,1);
        $res=$res."<input type=radio name=\"$n\" value=\"$p\" checked>$p$sep";
      }
      else
      { $res=$res."<input type=radio name=\"$n\" value=\"$p\">$p$sep";
      };
    }
    if (($t eq "option") || ($t eq "options"))
    { if ( substr($p,0,1) eq "*")
      { $p=substr($p,1);
        $res=$res."<option value=\"$p\" selected>$p";
      }
      else
      { $res=$res."<option value=\"$p\">$p";
      };
     }
    if ($t eq "submit")
    { $res=$res."<input name=\"$n\" type=submit value=\"$p\">$sep"; }
  }
  if (($t eq "option")||($t eq "options")) { $res=$res."</select>"; }
  if ($t ne "hidden") { $res=$res."</td></tr></table>"; }
  return $res."\n";
}

#liste - conversione da e a ascii
sub stpop($)
{  my @a=split(/ /,$_[0]);
   $res=$a[$#a];
   $_[0]=substr($_[0],0,length($_[0])-(length($res)+1));
   return fromasc($res);
}

sub EWsplit($$)
{ my $a=""; my $p;
  foreach $p(split( $_[0], $_[1]))
  { $a=$a.toasc($p)." ";
  } return $a;
}


my @parname;
my @parvalue;
srand(time());
read_form_buffer();
#jumper area
if (get_par("EWjump")>0)
{ jumper(get_par("EWjump"));
};
my $ax,$bx,$cx,$dx,@as;
	my $TB_imm_utenti="imm_utenti:user:pass";
	my $EWB_user=""; 
	my $EWB_pass=""; 
		my $TB_tipi_loc="tipi_loc:tipol";
	my $EWB_tipol=""; 
		my $TB_tipi_imm="tipi_imm:tipo";
	my $EWB_tipo=""; 
		my $TB_tipi_prezzo="tipi_prezzo:prezzoa:prezzob";
	my $EWB_prezzoa=""; 
	my $EWB_prezzob=""; 
		my $TB_imm_case="imm_case:imgcode:tipol:tipoimm:prezzo:tipocasa:descrizione";
	my $EWB_imgcode=""; 
	my $EWB_tipol=""; 
	my $EWB_tipoimm=""; 
	my $EWB_prezzo=""; 
	my $EWB_tipocasa=""; 
	my $EWB_descrizione=""; 
		my $TB_images="images:imgcode:imgfile";
	my $EWB_imgcode=""; 
	my $EWB_imgfile=""; 
	
my $EWB_b;
	$ax="Accedi";
	$EWB_b=$ax;
my $EWB_lg;
	$ax="";
	$EWB_lg=$ax;$ax="imm_edit.html";
	$ax=EWload($ax);
	$EWB_template=$ax;
my $EWB_qs;
	$ax=(EWgetenvvar("QUERY_STRING"));
	$EWB_qs=$ax;$ax=$EWB_qs;
	push @as,$ax;
	$ax="sk345623421234235423564236787685678rtyhr5uetyjh454u6h35ycrrt23";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area100; };
	$ax="";
	$EWB_qs=$ax;$ax="skiphome";
	$EWB_lg=$ax;goto areaend100;
	
area100:;
	;

areaend100:;
	$ax=$EWB_qs;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=2;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	push @as,$ax;
	$ax="ed";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area101; };
	$ax=$EWB_qs;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=2;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_qs;
	push @as,$ax;
	$ax=2;
	push @as,$ax;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx);
	$EWB_imgcode=$ax;$ax="ad";
	$EWB_qs=$ax;goto areaend101;
	
area101:;
	;

areaend101:;
	$ax=$EWB_qs;
	push @as,$ax;
	$ax="ad";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area102; };
	
my $EWB_a;
	$ax="";
	$EWB_a=$ax;$ax="";
	$EWB_tipoimm=$ax;$ax=$EWB_imgcode;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area103; };
	$ax="<font face=terminal>imgcode:[";
	push @as,$ax;
	$ax=$EWB_imgcode;
	push @as,$ax;
	$ax="]</font>\n";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	print $ax;
	$ax="imm_case:imgcode:tipol:tipoimm:prezzo:tipocasa:descrizione";
$ax=ewb_exist($ax);
	$ax=$EWB_tipol;
	push @as,$ax;
	$ax=";";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_a=$ax;$ax=$EWB_tipoimm;
	push @as,$ax;
	$ax=";";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_tipoimm=$ax;goto areaend103;
	
area103:;
	;

areaend103:;
	$ax="30:7:h";
	$EWB_format=$ax;$ax="tipi_loc:tipol";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  tab_unlock($n);
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area104:;
  if ($g > $#f) { goto area106; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_tipol;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area105;};
	$ax=$EWB_a;
	push @as,$ax;
	$ax=$EWB_tipol;
	push @as,$ax;
	$ax=";";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_a=$ax;
area105:;
  $g=$g+1;
  goto area104;
area106: ;
	
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax=$EWB_a;
	$EWB_tipol=$ax;$ax="Inserisci;Annulla";
	$EWB_a=$ax;$ax="skip";
	$EWB_lg=$ax;$ax="";
	$EWB_qs=$ax;$ax="tipi_imm:tipo";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  tab_unlock($n);
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area107:;
  if ($g > $#f) { goto area109; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_tipo;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area108;};
	$ax=$EWB_tipoimm;
	push @as,$ax;
	$ax=$EWB_tipo;
	push @as,$ax;
	$ax=";";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_tipoimm=$ax;
area108:;
  $g=$g+1;
  goto area107;
area109: ;
	
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax=$EWB_imgcode;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area110; };
	$ax="imgcode non nullo\n";
	print $ax;
	my $form="";
	push @as,"imgcode";
	push @as,$EWB_imgcode;
	push @as,"info";
	push @as,"imgcode";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="Tipo di locazione";
	push @as,"tipol";
	push @as,$EWB_tipol;
	push @as,"option";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="Tipo di immobile";
	push @as,"tipoimm";
	push @as,$EWB_tipoimm;
	push @as,"option";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="Breve";
	push @as,"tipocasa";
	push @as,$EWB_tipocasa;
	push @as,"text";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="Descrizione";
	push @as,"descrizione";
	push @as,$EWB_descrizione;
	push @as,"textarea";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="Prezzo";
	push @as,"prezzo";
	push @as,$EWB_prezzo;
	push @as,"text";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"a";
	push @as,$EWB_a;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lg\"") <0)
     { $form=$form.CreateForm("lg", $EWB_lg, "hidden");
     } 
    if (index($form, "name=\"qs\"") <0)
     { $form=$form.CreateForm("qs", $EWB_qs, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
$form=$form.CreateForm("EWjump", 0+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.602708411942334\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab1;
lab1:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_b=get_par("b"); 
$EWB_lg=get_par("lg"); 
$EWB_qs=get_par("qs"); 
$EWB_a=get_par("a"); 
retlab1:;
goto areaend110;
	
area110:;
	my $form="";
	$ax="codice riferimento";
	push @as,"imgcode";
	push @as,$EWB_imgcode;
	push @as,"text";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="Tipo di locazione";
	push @as,"tipol";
	push @as,$EWB_tipol;
	push @as,"option";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="Tipo di immobile";
	push @as,"tipoimm";
	push @as,$EWB_tipoimm;
	push @as,"option";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="Breve";
	push @as,"tipocasa";
	push @as,$EWB_tipocasa;
	push @as,"text";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="Descrizione";
	push @as,"descrizione";
	push @as,$EWB_descrizione;
	push @as,"textarea";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="Prezzo";
	push @as,"prezzo";
	push @as,$EWB_prezzo;
	push @as,"text";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"a";
	push @as,$EWB_a;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lg\"") <0)
     { $form=$form.CreateForm("lg", $EWB_lg, "hidden");
     } 
    if (index($form, "name=\"qs\"") <0)
     { $form=$form.CreateForm("qs", $EWB_qs, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
$form=$form.CreateForm("EWjump", 1+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.0936138526044203\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab2;
lab2:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_b=get_par("b"); 
$EWB_lg=get_par("lg"); 
$EWB_qs=get_par("qs"); 
$EWB_a=get_par("a"); 
retlab2:;

areaend110:;
	$ax=$EWB_a;
	push @as,$ax;
	$ax="Inserisci";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area111; };
	$ax=$EWB_imgcode;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area112; };
	$ax="imm_case:imgcode:tipol:tipoimm:prezzo:tipocasa:descrizione";
$ax=ewb_add($ax);
	$ax="imm_case:imgcode:tipol:tipoimm:prezzo:tipocasa:descrizione";
push @as,$ax;
	$ax="imgcode";
	$bx=pop @as;
	$ax=tab_sort($bx,$ax);goto areaend112;
	
area112:;
	
areaend112:;
	goto areaend111;
	
area111:;
	;

areaend111:;
	goto areaend102;
	
area102:;
	;

areaend102:;
	
my $EWB_b;
	
my $EWB_inf;
	$ax=$EWB_lg;
	push @as,$ax;
	$ax="skip";
	$bx=pop @as;
	$ax=($bx ne $ax);
	push @as,$ax;
	$ax=$EWB_lg;
	push @as,$ax;
	$ax="skiphome";
	$bx=pop @as;
	$ax=($bx ne $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area113; };
	$ax="Accedi";
	$EWB_b=$ax;$ax="Gestione archivio immobiliare<br></b>
       Da questo punto e' possibile amministrare l' archivio
       immobili e le tabelle di supporto";
	$EWB_inf=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"user";
	push @as,$EWB_user;
	push @as,"text";
	push @as,"user";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"pass";
	push @as,$EWB_pass;
	push @as,"password";
	push @as,"pass";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lg\"") <0)
     { $form=$form.CreateForm("lg", $EWB_lg, "hidden");
     } 
    if (index($form, "name=\"qs\"") <0)
     { $form=$form.CreateForm("qs", $EWB_qs, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
$form=$form.CreateForm("EWjump", 2+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.720659196182293\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab3;
lab3:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_b=get_par("b"); 
$EWB_lg=get_par("lg"); 
$EWB_qs=get_par("qs"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
retlab3:;
$ax="imm_utenti:user:pass";
$ax=ewb_login($ax);
	$ax=!$ax;
	if (!($ax)) { goto area114; };
	$ax="<h3>Errore</h3>
        La password indicata non e' valida per l' accesso.";
	$ax=print join(($ax), split("<>",$EWB_template));
	exit (0);
	goto areaend114;
	
area114:;
	;

areaend114:;
	goto areaend113;
	
area113:;
	;

areaend113:;
	
area115:;
	$ax=1;
	if (! ($ax)) {goto area116;};
	$ax="Gestione archivio immobiliare<br></b>
       Da questo punto e' possibile amministrare l' archivio
       immobili e le tabelle di supporto";
	$EWB_inf=$ax;$ax="Tipi di locazione;Tipi di immobile;Fasce di prezzo;Immobili";
	$EWB_b=$ax;$ax=$EWB_lg;
	push @as,$ax;
	$ax="skip";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (!($ax)) { goto area117; };
	my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lg\"") <0)
     { $form=$form.CreateForm("lg", $EWB_lg, "hidden");
     } 
    if (index($form, "name=\"qs\"") <0)
     { $form=$form.CreateForm("qs", $EWB_qs, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
$form=$form.CreateForm("EWjump", 3+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.638971612878727\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab4;
lab4:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_b=get_par("b"); 
$EWB_lg=get_par("lg"); 
$EWB_qs=get_par("qs"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
retlab4:;
goto areaend117;
	
area117:;
	$ax="Immobili";
	$EWB_b=$ax;$ax="";
	$EWB_lg=$ax;
areaend117:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Immobili";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area118; };
	
my $EWB_res;
	$ax="Elenco immobili registrati</b><br>
    <table border=0 bgcolor=EEEEEE>
    <tr bgcolor=dddddd>
    <td>Codice
    </td><td>Tipo di locazione
    </td><td>Tipo di immobile
    </td><td>Tipo    
    </td><td>Descrizione
    </td><td>Immagini
    </td><td>Prezzo
    </td></tr>
    ";
	$EWB_res=$ax;$ax="imm_case:imgcode:tipol:tipoimm:prezzo:tipocasa:descrizione";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area119:;
  if ($g > $#f) { goto area121; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area120;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_res;
	push @as,$ax;
	$ax="<tr><td><a href=\"imm_edit.cgi?ed";
	push @as,$ax;
	$ax=$EWB_imgcode;
	push @as,$ax;
	$ax="\">
               <img src=edit.gif border=0></a>
               <a href=\"imm_foto.cgi?";
	push @as,$ax;
	$ax=$EWB_imgcode;
	push @as,$ax;
	$ax="\">
               <img src=foto.gif border=0></a>
               <a href=\"imm_edit.cgi?dl";
	push @as,$ax;
	$ax=$EWB_imgcode;
	push @as,$ax;
	$ax="\">
               <img src=del.gif border=0></a>
              ";
	push @as,$ax;
	$ax=$EWB_imgcode;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax=$EWB_tipol;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax=$EWB_tipoimm;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax=$EWB_tipocasa;
	push @as,$ax;
	$ax="</td><td>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;$ax=$EWB_res;
	push @as,$ax;
	$ax=$EWB_qs;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=2;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_qs;
	push @as,$ax;
	$ax=2;
	push @as,$ax;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx);
	$ax=$EWB_descrizione;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=100;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	push @as,$ax;
	$ax="...</td><td>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;
my $EWB_a;
	$ax=$EWB_imgcode;
	$EWB_a=$ax;$ax="images:imgcode:imgfile";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  tab_unlock($n);
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area122:;
  if ($g > $#f) { goto area124; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_imgcode;
	push @as,$ax;
	$ax=$EWB_a;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area123;};
	$ax=$EWB_res;
	push @as,$ax;
	$ax="<img src=";
	push @as,$ax;
	$ax=$EWB_imgfile;
	push @as,$ax;
	$ax=" width=50>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;
area123:;
  $g=$g+1;
  goto area122;
area124: ;
	
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax=$EWB_res;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax=$EWB_prezzo;
	push @as,$ax;
	$ax="</td></tr>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;
area120:;
  $g=$g+1;
  goto area119;
area121:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax=$EWB_res;
	push @as,$ax;
	$ax="<tr><td>
                   <a href=\"imm_edit.cgi?ad\">
               <img src=edit.gif border=0></a>Aggiungi
             </td><td>
                   <!--<a href=\"imm_foto.cgi\">
               <img src=foto.gif border=0></a>Gestisci foto
-->
             </td><td>
                   <a href=\"imm_edit.cgi?sk345623421234235423564236787685678rtyhr5uetyjh454u6h35ycrrt23\">
               <img src=skip.gif border=0></a>Torna alla home 

             </td><td>
             </td><td>
             </td><td>
             </td><td></td>
    </tr></table>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;$ax=$EWB_res;
	$ax=print join(($ax), split("<>",$EWB_template));
	exit (0);
	goto areaend118;
	
area118:;
	;

areaend118:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Tipi di locazione";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area125; };
	
my $EWB_a;
	$ax="";
	$EWB_a=$ax;$ax="tipi_loc:tipol";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area126:;
  if ($g > $#f) { goto area128; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area127;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=$EWB_tipol;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_a=$ax;
area127:;
  $g=$g+1;
  goto area126;
area128:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax="Tipologie di locazione previste<br></b>
         Qui possono essere indicate le tipologie di locazione per 
         un immobile. ";
	$EWB_inf=$ax;$ax="Modifica;Indietro";
	$EWB_b=$ax;$ax="50:5:h";
	$EWB_format=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="  ";
	push @as,"a";
	push @as,$EWB_a;
	push @as,"textarea";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lg\"") <0)
     { $form=$form.CreateForm("lg", $EWB_lg, "hidden");
     } 
    if (index($form, "name=\"qs\"") <0)
     { $form=$form.CreateForm("qs", $EWB_qs, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
$form=$form.CreateForm("EWjump", 4+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.42762253329882\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab5;
lab5:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_b=get_par("b"); 
$EWB_lg=get_par("lg"); 
$EWB_qs=get_par("qs"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
$EWB_a=get_par("a"); 
retlab5:;
$ax="12:5:h";
	$EWB_format=$ax;$ax=$EWB_b;
	push @as,$ax;
	$ax="Modifica";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area129; };
	$ax="tipi_loc:tipol";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  open rof,"> ".checkpath().".TB$n.bkp";
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area130:;
  if ($g > $#f) { goto area132; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=1;
	if ($ax) { goto area131;};
	print rof $l."\n";

area131:;
  $g=$g+1;
  goto area130;
area132: ;
	
  close rof;  
  #copia di un file sull altro
  open rif,checkpath().".TB$n.bkp";
  open rof, ">".checkpath().".TB$n.tab";
  my @fl=<rif>;
  my $rw;
  foreach $rw(@fl)
  { print rof $rw; };  
  close rif;
  close rof;
  tab_unlock($n);
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax="\n";
	push @as,$ax;
	$ax=$EWB_a;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_a=$ax;$ax="\n";
	push @as,$ax;
	$ax=$EWB_a;
	$bx=pop @as;
	$ax=EWsplit($bx,$ax);
	$EWB_a=$ax;
area133:;
	$ax=$EWB_a;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (! ($ax)) {goto area134;};
	$ax=stpop($EWB_a);
	$EWB_tipol=$ax;$ax=$EWB_tipol;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	push @as,$ax;
	$ax=$EWB_a;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area135; };
	$ax="tipi_loc:tipol";
$ax=ewb_add($ax);
	goto areaend135;
	
area135:;
	;

areaend135:;
	goto area133;
	
area134:;
	$ax="Dati modificati";
	$EWB_inf=$ax;$ax="Ok";
	$EWB_b=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lg\"") <0)
     { $form=$form.CreateForm("lg", $EWB_lg, "hidden");
     } 
    if (index($form, "name=\"qs\"") <0)
     { $form=$form.CreateForm("qs", $EWB_qs, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
$form=$form.CreateForm("EWjump", 5+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.873872240990735\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab6;
lab6:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_b=get_par("b"); 
$EWB_lg=get_par("lg"); 
$EWB_qs=get_par("qs"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
$EWB_a=get_par("a"); 
retlab6:;
goto areaend129;
	
area129:;
	;

areaend129:;
	goto areaend125;
	
area125:;
	;

areaend125:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Tipi di immobile";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area136; };
	
my $EWB_a;
	$ax="";
	$EWB_a=$ax;$ax="tipi_imm:tipo";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area137:;
  if ($g > $#f) { goto area139; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area138;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=$EWB_tipo;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_a=$ax;
area138:;
  $g=$g+1;
  goto area137;
area139:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax="Tipologie di immobile<br></b>
         Qui possono essere indicate le tipologie a cui possono appartenere
         diversi immobili. ";
	$EWB_inf=$ax;$ax="Modifica;Indietro";
	$EWB_b=$ax;$ax="50:5:h";
	$EWB_format=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="  ";
	push @as,"a";
	push @as,$EWB_a;
	push @as,"textarea";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lg\"") <0)
     { $form=$form.CreateForm("lg", $EWB_lg, "hidden");
     } 
    if (index($form, "name=\"qs\"") <0)
     { $form=$form.CreateForm("qs", $EWB_qs, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
$form=$form.CreateForm("EWjump", 6+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.314860723350957\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab7;
lab7:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_b=get_par("b"); 
$EWB_lg=get_par("lg"); 
$EWB_qs=get_par("qs"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
$EWB_a=get_par("a"); 
retlab7:;
$ax="12:5:h";
	$EWB_format=$ax;$ax=$EWB_b;
	push @as,$ax;
	$ax="Modifica";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area140; };
	$ax="tipi_imm:tipo";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  open rof,"> ".checkpath().".TB$n.bkp";
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area141:;
  if ($g > $#f) { goto area143; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=1;
	if ($ax) { goto area142;};
	print rof $l."\n";

area142:;
  $g=$g+1;
  goto area141;
area143: ;
	
  close rof;  
  #copia di un file sull altro
  open rif,checkpath().".TB$n.bkp";
  open rof, ">".checkpath().".TB$n.tab";
  my @fl=<rif>;
  my $rw;
  foreach $rw(@fl)
  { print rof $rw; };  
  close rif;
  close rof;
  tab_unlock($n);
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax="\n";
	push @as,$ax;
	$ax=$EWB_a;
	push @as,$ax;
	$ax="\n";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_a=$ax;$ax="\n";
	push @as,$ax;
	$ax=$EWB_a;
	$bx=pop @as;
	$ax=EWsplit($bx,$ax);
	$EWB_a=$ax;
area144:;
	$ax=$EWB_a;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	if (! ($ax)) {goto area145;};
	$ax=stpop($EWB_a);
	$EWB_tipo=$ax;$ax=$EWB_tipo;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	push @as,$ax;
	$ax=$EWB_a;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx ne $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area146; };
	$ax="tipi_imm:tipo";
$ax=ewb_add($ax);
	goto areaend146;
	
area146:;
	;

areaend146:;
	goto area144;
	
area145:;
	$ax="Dati modificati";
	$EWB_inf=$ax;$ax="Ok";
	$EWB_b=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lg\"") <0)
     { $form=$form.CreateForm("lg", $EWB_lg, "hidden");
     } 
    if (index($form, "name=\"qs\"") <0)
     { $form=$form.CreateForm("qs", $EWB_qs, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
$form=$form.CreateForm("EWjump", 7+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.531505889998776\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab8;
lab8:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_b=get_par("b"); 
$EWB_lg=get_par("lg"); 
$EWB_qs=get_par("qs"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
$EWB_a=get_par("a"); 
retlab8:;
goto areaend140;
	
area140:;
	;

areaend140:;
	goto areaend136;
	
area136:;
	;

areaend136:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Fasce di prezzo";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area147; };
	$ax="Indietro";
	$EWB_b=$ax;$ax="Fasce di prezzo<br></b>
           Qui possono essere impostate le fasce di prezzo su cui un cliente
           possa effettuare la ricerca.";
	$EWB_inf=$ax;
my $EWB_res;
	$ax="<table border=0 width=50%>
      <tr bgcolor=#DDDDDD><td width=50%><b>Da</b></td><td><b>A</b></td></tr>";
	$EWB_res=$ax;$ax="tipi_prezzo:prezzoa:prezzob";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  tab_unlock($n);
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area148:;
  if ($g > $#f) { goto area150; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_res;
	push @as,$ax;
	$ax="<tr bgcolor=#EEEEEE><td>";
	push @as,$ax;
	$ax=$EWB_prezzoa;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax=$EWB_prezzob;
	push @as,$ax;
	$ax="</td></tr>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;
area149:;
  $g=$g+1;
  goto area148;
area150: ;
	
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax=$EWB_res;
	push @as,$ax;
	$ax="</table>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;$ax=$EWB_inf;
	push @as,$ax;
	$ax="<br>";
	push @as,$ax;
	$ax=$EWB_res;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_inf=$ax;$ax="Aggiungi;Cancella;Indietro";
	$EWB_b=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lg\"") <0)
     { $form=$form.CreateForm("lg", $EWB_lg, "hidden");
     } 
    if (index($form, "name=\"qs\"") <0)
     { $form=$form.CreateForm("qs", $EWB_qs, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"res\"") <0)
     { $form=$form.CreateForm("res", $EWB_res, "hidden");
     } 
$form=$form.CreateForm("EWjump", 8+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.638711277386765\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab9;
lab9:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_b=get_par("b"); 
$EWB_lg=get_par("lg"); 
$EWB_qs=get_par("qs"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
$EWB_res=get_par("res"); 
retlab9:;
$ax=$EWB_b;
	push @as,$ax;
	$ax="Aggiungi";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area151; };
	$ax="Aggiungi;Annulla";
	$EWB_b=$ax;$ax=0;
	$EWB_prezzoa=$ax;$ax=0;
	$EWB_prezzob=$ax;my $form="";
	$ax="Da ";
	push @as,"prezzoa";
	push @as,$EWB_prezzoa;
	push @as,"text";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	$ax="A ";
	push @as,"prezzob";
	push @as,$EWB_prezzob;
	push @as,"text";
	push @as,$ax;
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lg\"") <0)
     { $form=$form.CreateForm("lg", $EWB_lg, "hidden");
     } 
    if (index($form, "name=\"qs\"") <0)
     { $form=$form.CreateForm("qs", $EWB_qs, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"res\"") <0)
     { $form=$form.CreateForm("res", $EWB_res, "hidden");
     } 
$form=$form.CreateForm("EWjump", 9+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.0116122947663371\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab10;
lab10:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_b=get_par("b"); 
$EWB_lg=get_par("lg"); 
$EWB_qs=get_par("qs"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
$EWB_res=get_par("res"); 
retlab10:;
$ax=$EWB_b;
	push @as,$ax;
	$ax="Aggiungi";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area152; };
	$ax=$EWB_prezzoa;
	push @as,$ax;
	$ax=0;
	$bx=pop @as;
	$ax=($bx >= $ax);
	push @as,$ax;
	$ax=$EWB_prezzob;
	push @as,$ax;
	$ax=$EWB_prezzoa;
	$bx=pop @as;
	$ax=($bx > $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	if (!($ax)) { goto area153; };
	$ax="tipi_prezzo:prezzoa:prezzob";
$ax=ewb_add($ax);
	$ax="Ok";
	$EWB_b=$ax;$ax="Fascia di prezzo inserita";
	$EWB_inf=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lg\"") <0)
     { $form=$form.CreateForm("lg", $EWB_lg, "hidden");
     } 
    if (index($form, "name=\"qs\"") <0)
     { $form=$form.CreateForm("qs", $EWB_qs, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"res\"") <0)
     { $form=$form.CreateForm("res", $EWB_res, "hidden");
     } 
$form=$form.CreateForm("EWjump", 10+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.78907124560082\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab11;
lab11:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_b=get_par("b"); 
$EWB_lg=get_par("lg"); 
$EWB_qs=get_par("qs"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
$EWB_res=get_par("res"); 
retlab11:;
goto areaend153;
	
area153:;
	$ax="Ok";
	$EWB_b=$ax;$ax="I dati indicati sono errati";
	$EWB_inf=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lg\"") <0)
     { $form=$form.CreateForm("lg", $EWB_lg, "hidden");
     } 
    if (index($form, "name=\"qs\"") <0)
     { $form=$form.CreateForm("qs", $EWB_qs, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"res\"") <0)
     { $form=$form.CreateForm("res", $EWB_res, "hidden");
     } 
$form=$form.CreateForm("EWjump", 11+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.492173573458309\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab12;
lab12:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_b=get_par("b"); 
$EWB_lg=get_par("lg"); 
$EWB_qs=get_par("qs"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
$EWB_res=get_par("res"); 
retlab12:;

areaend153:;
	goto areaend152;
	
area152:;
	;

areaend152:;
	goto areaend151;
	
area151:;
	;

areaend151:;
	$ax=$EWB_b;
	push @as,$ax;
	$ax="Cancella";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area154; };
	
my $EWB_da;
	$ax="";
	$EWB_da=$ax;$ax="tipi_loc:tipol";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area155:;
  if ($g > $#f) { goto area157; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area156;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_da;
	push @as,$ax;
	$ax=$EWB_tipol;
	push @as,$ax;
	$ax=";";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_da=$ax;$ax="Seleziona il valore da cancellare";
	$EWB_inf=$ax;$ax="Cancella;Annulla";
	$EWB_b=$ax;my $form="";
	push @as,"inf";
	push @as,$EWB_inf;
	push @as,"info";
	push @as,"inf";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"da";
	push @as,$EWB_da;
	push @as,"option";
	push @as,"da";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"prezzoa\"") <0)
     { $form=$form.CreateForm("prezzoa", $EWB_prezzoa, "hidden");
     } 
    if (index($form, "name=\"prezzob\"") <0)
     { $form=$form.CreateForm("prezzob", $EWB_prezzob, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"tipol\"") <0)
     { $form=$form.CreateForm("tipol", $EWB_tipol, "hidden");
     } 
    if (index($form, "name=\"tipoimm\"") <0)
     { $form=$form.CreateForm("tipoimm", $EWB_tipoimm, "hidden");
     } 
    if (index($form, "name=\"prezzo\"") <0)
     { $form=$form.CreateForm("prezzo", $EWB_prezzo, "hidden");
     } 
    if (index($form, "name=\"tipocasa\"") <0)
     { $form=$form.CreateForm("tipocasa", $EWB_tipocasa, "hidden");
     } 
    if (index($form, "name=\"descrizione\"") <0)
     { $form=$form.CreateForm("descrizione", $EWB_descrizione, "hidden");
     } 
    if (index($form, "name=\"imgcode\"") <0)
     { $form=$form.CreateForm("imgcode", $EWB_imgcode, "hidden");
     } 
    if (index($form, "name=\"imgfile\"") <0)
     { $form=$form.CreateForm("imgfile", $EWB_imgfile, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"lg\"") <0)
     { $form=$form.CreateForm("lg", $EWB_lg, "hidden");
     } 
    if (index($form, "name=\"qs\"") <0)
     { $form=$form.CreateForm("qs", $EWB_qs, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"res\"") <0)
     { $form=$form.CreateForm("res", $EWB_res, "hidden");
     } 
    if (index($form, "name=\"da\"") <0)
     { $form=$form.CreateForm("da", $EWB_da, "hidden");
     } 
$form=$form.CreateForm("EWjump", 12+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.237814862543917\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab13;
lab13:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipo=get_par("tipo"); 
$EWB_prezzoa=get_par("prezzoa"); 
$EWB_prezzob=get_par("prezzob"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_tipol=get_par("tipol"); 
$EWB_tipoimm=get_par("tipoimm"); 
$EWB_prezzo=get_par("prezzo"); 
$EWB_tipocasa=get_par("tipocasa"); 
$EWB_descrizione=get_par("descrizione"); 
$EWB_imgcode=get_par("imgcode"); 
$EWB_imgfile=get_par("imgfile"); 
$EWB_b=get_par("b"); 
$EWB_lg=get_par("lg"); 
$EWB_qs=get_par("qs"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
$EWB_res=get_par("res"); 
$EWB_da=get_par("da"); 
retlab13:;

area156:;
  $g=$g+1;
  goto area155;
area157:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
goto areaend154;
	
area154:;
	;

areaend154:;
	goto areaend147;
	
area147:;
	;

areaend147:;
	goto area115;
	
area116:;
	exit(0); 

sub jumper($)
{ my $lab=$_[0];
if ($lab==1) { goto lab1; }
if ($lab==2) { goto lab2; }
if ($lab==3) { goto lab3; }
if ($lab==4) { goto lab4; }
if ($lab==5) { goto lab5; }
if ($lab==6) { goto lab6; }
if ($lab==7) { goto lab7; }
if ($lab==8) { goto lab8; }
if ($lab==9) { goto lab9; }
if ($lab==10) { goto lab10; }
if ($lab==11) { goto lab11; }
if ($lab==12) { goto lab12; }
if ($lab==13) { goto lab13; }
};

#Amethist easyweb v. 5.23 - easy 
#Enrico Betti e Paride Dominici



sub ewb_exist($)
{  $cond="\$res=join(\"\",((";
   $tab=$_[0];
   my $count=0;
   my @tot=split(":",$tab);
   foreach $field(@tot)
   { if ($count>0)
     { $cond=$cond."\$EWB_".$field;
       if ($count<$#tot) {$cond=$cond.","; };
     }
     $count++;
  }
  $cond=$cond.")=tab_exist(\"$tot[0]\",\$EWB_";
  $cond=$cond.$tot[1].")));";
  eval($cond);
  return ($res ne "");
}

sub ewb_login($)
{  $cond="\$res=join(\"\",((";
   $tab=$_[0];
   my $count=0;
   my @tot=split(":",$tab);
   foreach $field(@tot)
   { if ($count>0)
     { $cond=$cond."\$EWB_".$field;
       if ($count<$#tot) {$cond=$cond.","; };
     }
     $count++;
  }
  $cond=$cond.")=tab_login(\"$tot[0]\",\$EWB_";
  $cond=$cond.$tot[1].", \$EWB_".$tot[2].")));";
  eval($cond);
  return ($res ne "");
}

sub ewb_add($)
{  my $cond="my \$line=";
   my $tab=$_[0];
   my $count=0;
   my @tot=split(":",$tab);
   tab_wlock($tab);
   foreach $field(@tot)
   { if ($count>0)
     { $cond=$cond."delchar(\$EWB_".$field.")";
       if ($count<$#tot) {$cond=$cond.".\"#\"."; };
     }
     $count++;
  }
  $cond.=";
if (!(open oof,\">> ".checkpath().".TB$tot[0].tab\"))
{ print \"\\nAttenzione: non posso creare files\\n\";
  exit(0);
};
print oof \$line.\"\\n\";
close oof;
";
  eval($cond);
  tab_unlock($tab);
  return ($res ne "");
};

sub EWconv($)
{ my $a=$_[0];
  $a=join("%3C", split("%253C", $a));
#  $a=~ tr/+/ /;
  $a=~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C",hex($1))/eg;
  $a=join("
", split("%0A", $a));
  $a=join("	", split("%09", $a));
  $a=join("\"", split("%22", $a));
  $a=join("<", split("%3C", $a));
  return $a;
}

sub tab_islock($)
{ my $name=$_[0];
  my $l; my $r=0;
  foreach $l(@EWlocked)
  { if ($l eq $name) {$r=1;}
  } return $r;
}

sub tab_exist($$)
{ my ($n,$k)=@_;
  tab_wlock($n);
  open III,"< ".checkpath().".TB$n.tab";
  my $l; my @r;
  foreach $l(<III>)
  { #tolgo da $l il caporiga, o non funziona la exist.
    if (substr($l,length($l)-1,1) eq "\n")
    {  $l=substr($l, 0, length($l)-1);
    }
    if ( ((split("#",$l))[0]) eq delchar($k))
    { my $a;
      @r=();
      foreach $a(split("#",$l))
      { push @r, addchar($a);
  } } }
  close III; tab_unlock($n); return @r;
}

sub tab_login($$$)
{ my ($n,$k,$p)=@_;
  my @r; my @a=tab_exist($n,$k);
  if ($a[1] eq $p) { @r=@a; }
  return @r;
}

sub delchar($)
{ my $a=join("<EWB_ASTErISCO>",split "#", $_[0]);
  $a=join("<EWB_LineFEEd>", split(chr(0x0D), $a));
  return join("<EWB_CARRIaGErETURN>", split("\n", $a));
}

sub toasc($)
{ my $a=$_[0];
  my $r; my $i;
  for($i=0; $i<length($a); $i++)
  { my $k=ord(substr($a,$i,1));
    if ($k<16) {$r=$r."0";};
    $r=$r.sprintf("%x",$k);
  } return $r;
}

sub fromasc($)
{ my $a=$_[0];
  my $r; my $i;
  for($i=0; $i<length($a); $i=$i+2)
  { $r=$r.chr(hex(substr($a,$i,2)));
  } return $r;
}
