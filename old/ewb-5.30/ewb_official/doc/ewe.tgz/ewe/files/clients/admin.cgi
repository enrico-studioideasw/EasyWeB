#!/usr/bin/perl
print "Content-type: text/html\n\n"; 
#!/usr/bin/perl
my @EWlocked;
use IO::Socket;
my @fltype;
my $EWB_tabpath="./";
my $EWB_template="<html><body bgcolor=lightyellow><div align=center><></body></html>";
my $EWB_format="12:5:h";
my $EWB_sqldbase="";
my $EWB_sqlserver="";
srand(time());
my $PROGRAM_NAME;
{ my @a=split('/', $0);
  $PROGRAM_NAME=$a[$#a];
}
my $rlist="";

#gestione di forms multipart encoded
sub read_form_buffer()
{ my $b=$ENV{"CONTENT_LENGTH"};
  my $all=""; my $i;
  for ($i=0; $i<$b;)
  { $all=$all.<>;
    $i=length($all);
  };
  #pesco il boundary e ricostruisco, per quanto possibile, la query string.
  my $boundary=((split("\n", $all))[0]);
  my @all=split($boundary, $all);
  #se la prima riga termina con "name=", lo metto in query string
  $i=0;
  foreach $p(@all)
  {
    my ($a, $first)=(split("\n", $p));
    ($a, $b)=split(" name=\"", $first);
    if ($b ne "")
    { my $name;
      ($name, $b)=split("\"", $b);
      $parname[$i]=$name;
      #il value e' nella quarta riga.
      if (index($first, " filename=\"")<0)
      { my $rest;
          $rest="";
          for($k=4; $k<=(split("\n", $p)); $k++)
          { $rest=$rest.( (split("\n", $p))[$k]);
          };
        if ( ($rest) eq "")
        {
          $parvalue[$i]=((split("\n", $p))[3]);
	  $parvalue[$i]=substr($parvalue[$i], 0, length($parvalue[$i])-1);
	  $fltype[$i]="text";
          if (substr($parvalue[$i],0, length("HidDenFieldDaTa")) eq
                  ("HidDenFieldDaTa"))
          { $parvalue[$i]=fromasc(substr($parvalue[$i],length("HidDenFieldDaTa")));
          };
        }
        else
        { my $k;
          $parvalue[$i]="";
          for($k=3; $k<=(split("\n", $p)); $k++)
          { $parvalue[$i]=$parvalue[$i].( (split("\n", $p))[$k])."\n";
          };
	  $parvalue[$i]=substr($parvalue[$i], 0, length($parvalue[$i])-2);
        };
        $i++;

      } else
      { #cerco il content_type
        $fltype[$i]="file";
        my $ctype=((split("\n", $p))[2]);
	$ctype=substr($ctype, 0, length($ctype)-1);
	#print "Ctype: [$ctype]\n";
        $parvalue[$i] = "";
	if (substr(uc($ctype), 0, length("Content-type: "))  eq "CONTENT-TYPE: ")
	{ #trasferimento file di testo.
	  my @p=split("\n", $p);
	  $p[0]=""; $p[1]=""; $p[2]=""; $p[3]="";
	  $partype[$i]=substr($ctype, length("Content-type: "));
	  #printf("partype: $partype[$i]\n");
	  $parvalue[$i]=join("\n", @p);
	  $parvalue[$i]=substr($parvalue[$i], 4);
          $parvalue[$i]=substr($parvalue[$i], 0, (length($parvalue[$i])-1));
	}
        $i++;
      }
    }
  }

  #se ci sono parametri con nome  replicato, diventano un'unico parametro con
  #valori separati da ;
  my  $p, $r, $fn; my $cnp=0;
  my @pnm; my  @pvl;
  foreach $p(@parname)
  { $fn=0;
    my $cni=0;
    foreach $r(@pnm)
    { if  ($p eq $r)
       { $pvl[$cni]=$pvl[$cni].";".$parvalue[$cnp];
	 $fn=1;
       };
       $cni++;
    };
    if ( $fn==0 )
    { $pnm[$#pnm+1]=$p;
      $pvl[$#pvl+1]=$parvalue[$cnp];
    };
    $cnp++;
  };
  @parname=@pnm;
  @parvalue=@pvl;

  #qui mostro tutti i parametri. Rielaboro quelli corrispondenti a multicheck
  # e piu'avanti anche a multilist.
  my $p; my $cnt=0;
  my  @pv; my @tohide; my  @hideval;
  foreach $p(@parname)
  { if (substr($p, 0, length("EWcHECK_")) eq  "EWcHECK_")
    { $p=substr($p, length("EWcHECK_"));
      my $n=int($p);
      $p=substr($p, length($n));
#      print "Par ".$p." vale ".$parvalue[$cnt]."<br>";

      my $fnd=0;
      for ($n=0; $n<=$#tohide; $n++)
      { if ($p eq $tohide[$n])
        { $fnd=1;
          $hideval[$n]=$hideval[$n].";".$parvalue[$cnt];
        };
      };
      if ($fnd!=1)
      { $n=$#tohide+1;
        $tohide[$n]=$p;
        $hideval[$n]=$parvalue[$cnt];
      };
    };
    $cnt++;
  };
  $cnt=0;
  foreach $p(@tohide)
  { my $a;
    my $ctb=0;
    foreach $a(@parname)
    { if ($a eq $p) { $parvalue[$ctb]=$hideval[$cnt]; }
      $ctb++;
    }
    $cnt++;
  };
}

sub checkpath()
{ my $a=$EWB_tabpath;
  if (substr($a,length($a)-1,1) ne "/")
  { $a=$a."/";
  }; return $a;
};

sub get_par($)
{ my ($name)=@_;
  my $res="";
  my $n; my $i=0;
  foreach $n(@parname)
  { if ($name eq EWconv($n))
    { if ($fltype[$i] ne "file") { $res=EWconv($parvalue[$i]); }
      else { $res=$parvalue[$i]; };
    };
    $i++;
  };
  return $res;
};

#funzioni predefinite
sub EWgetenvvar($)
{
  my $r;
  $r= $ENV{$_[0]};
  return $r;
}

#2.10 fine
sub tab_wlock($)
{ my $name=$_[0];
  $name=((split(":", $name))[0]);
  my $i; my $d=0;
  if (!tab_islock($name))
  { while (($i<10)&&($d==0))
    { if (!(open (III, "< ".checkpath()."TB".$name.".lck")))
      { if (!(open (OOO, "> ".checkpath()."TB".$name.".lck")))
        { print  "Attenzione: non posso creare files.\n";
          exit(0);
        };
        close OOO;$d=1;
      }
      else
      { close III; sleep (1); $i++;
      }
    }
  }
  push @EWlocked, $name;
}

sub tab_unlock($)
{ my $name=$_[0];
  $name=((split(":", $name))[0]);
  my @a; my $l;
  my $count=0;
  foreach $l(@EWlocked)
  { if (($l ne $name) || ($count>0)) { push @a,$l; }
    if ($l eq $name) {++$count; };
  }
  @EWlocked=@a;
  if ($count=1) { unlink(checkpath()."TB".$name.".lck"); };
}

sub tab_read($)
{ #esegue la lettura di una tabella gia bloccata.
  my @t=split(":", $_[0]);
  open III,"< ".checkpath().".TB$t[0].tab";
    my $k=join("",<III>);
    my @r=split("\n",$k);
  close III;
  return @r;
};
sub addchar($)
{ my $a=join("#",split "<EWB_ASTErISCO>", $_[0]);
  $a=join(chr(0x0D),split("<EWB_LineFEEd>", $a));
  return join("\n", split("<EWB_CARRIaGErETURN>", $a));
}

sub CreateForm
{ #nomecampo, valore, tipo campo, nome a video
  my ($n,$v,$t,$vidname)=@_;
  if ($t eq "hidden")
  { #conversione di un campo hidden, analoga a push
    $v="HidDenFieldDaTa".toasc($v);
  }
  else
  { if (($t ne "textarea")&&($t ne "info"))
    { $v=join("%22", (split "\"", $v));
      $v=join("%09", (split "\t", $v));
      $v=join("%0A", (split "\n", $v));
      $v=join("%3C", (split "<", $v));
    };
  };
  my @f=split(":", $EWB_format);
  if ($f[0]<1) {$f[0]=12; };
  if ($f[1]<1) {$f[1]=5; };

  my $res;
  my $vn=$vidname;
  if (length($vidname) <2) { $vidname=$n; };
  $res="<table border=0><tr><td>$vidname</td><td>";

  if (($t eq "submit") && (length($vn)<2)) { $res="<table border=0><tr><td></td><td>"; };
  if ($t eq "file")
  { $res=$res."<input name=\"$n\" value=\"\" type=file>"; }
  if ($t eq "text")
  { $res=$res."<input name=\"$n\" value=\"$v\" size=".$f[0].">"; }
  if ($t eq "password")
  { $res=$res."<input name=\"$n\" type=password value=\"$v\" size=".$f[0].">"; }
  if ($t eq "hidden")
  { $res="<input name=\"$n\" type=hidden value=\"$v\">"; }
  if ($t eq "checkbox")
  { $res=$res."<input name=\"$n\" type=checkbox value=\"1\">"; }
  if ($t eq "info")
  { $res="<table border=0><tr><td><b> $v </b>"; }
  if ($t eq "textarea")
  { $res=$res."<textarea name=\"$n\" cols=".$f[0]." rows=".$f[1].">$v</textarea>"; }
  #tipi composti
  if ($t eq "option") { $res=$res."\n<select name=\"$n\">"; }
  if ($t eq "options") { $res=$res."\n<select name=\"$n\" multiple>"; }
  my @v=split(/;/,$v); my $p;

  if ($t eq "checks")
  { $res=$res."<input name=\"$n\" type=hidden value=\"\">\n";
  }

  my $sep; if ($f[2] eq "v") { $sep="<br>"; } else{ $sep=" &nbsp; "; };
  my $counter=0;
  foreach $p(@v)
  {
    if ($t eq "checks")
    { my $CV="";
      if (substr($p, 0, 1) eq  "*")
      { $p=substr($p, 1);
        $CV="checked";
      };
      $res=$res."<input name=\"EWcHECK_".$counter.$n."\" type=checkbox $CV value=\"$p\">$p $sep\n";
      $counter++;
    }
    if ($t eq "links")
    {  my ($vid,$dest)=split("->", $p);
       if ($dest eq "") { $dest=$vid; };
       $res=$res."<a href=\"$dest\">$vid</a>$sep"; }
    if ($t eq "radio")
    { if ( substr($p,0,1) eq "*")
      { $p=substr($p,1);
        $res=$res."<input type=radio name=\"$n\" value=\"$p\" checked>$p$sep";
      }
      else
      { $res=$res."<input type=radio name=\"$n\" value=\"$p\">$p$sep";
      };
    }
    if (($t eq "option") || ($t eq "options"))
    { if ( substr($p,0,1) eq "*")
      { $p=substr($p,1);
        $res=$res."<option value=\"$p\" selected>$p";
      }
      else
      { $res=$res."<option value=\"$p\">$p";
      };
     }
    if ($t eq "submit")
    { $res=$res."<input name=\"$n\" type=submit value=\"$p\">$sep"; }
  }
  if (($t eq "option")||($t eq "options")) { $res=$res."</select>"; }
  if ($t ne "hidden") { $res=$res."</td></tr></table>"; }
  return $res."\n";
}

#liste - conversione da e a ascii
sub EWdate()
{ my @ti=localtime(time);
  return $ti[3]." ".($ti[4]+1)." ".($ti[5]+1900);
}

sub EWlessdate($$)
{ my ($d1,$d2)=@_;
  my ($day1,$mon1,$yea1)=split(" ",$d1);
  my ($day2,$mon2,$yea2)=split(" ",$d2);
  my $num1=$day1+($mon1*31)+($yea1*31*12);
  my $num2=$day2+($mon2*31)+($yea2*31*12);
  return ($num1<$num2);
}

#funzioni di tempo

my @parname;
my @parvalue;
srand(time());
read_form_buffer();
#jumper area
if (get_par("EWjump")>0)
{ jumper(get_par("EWjump"));
};
my $ax,$bx,$cx,$dx,@as;
	my $TB_utenti="utenti:user:pass:tipo:nome:datains:datascad:telefono:mail:cell:indirizzo";
	my $EWB_user=""; 
	my $EWB_pass=""; 
	my $EWB_tipo=""; 
	my $EWB_nome=""; 
	my $EWB_datains=""; 
	my $EWB_datascad=""; 
	my $EWB_telefono=""; 
	my $EWB_mail=""; 
	my $EWB_cell=""; 
	my $EWB_indirizzo=""; 
		my $TB_clienti="clienti:user:nome:tipo:zona:datains:datascad:telefono:mail:cell:indirizzo";
	my $EWB_user=""; 
	my $EWB_nome=""; 
	my $EWB_tipo=""; 
	my $EWB_zona=""; 
	my $EWB_datains=""; 
	my $EWB_datascad=""; 
	my $EWB_telefono=""; 
	my $EWB_mail=""; 
	my $EWB_cell=""; 
	my $EWB_indirizzo=""; 
		my $TB_agenda="agenda:user:data:ora:durata:visibile:privato";
	my $EWB_user=""; 
	my $EWB_data=""; 
	my $EWB_ora=""; 
	my $EWB_durata=""; 
	my $EWB_visibile=""; 
	my $EWB_privato=""; 
		my $TB_plan="plan:user:data:ora:azione";
	my $EWB_user=""; 
	my $EWB_data=""; 
	my $EWB_ora=""; 
	my $EWB_azione=""; 
	
my $EWB_jmp;
	
my $EWB_b;
	
my $EWB_inf;
	$ax="";
	$EWB_jmp=$ax;
my $EWB_a;
	$ax=(EWgetenvvar("QUERY_STRING"));
	$EWB_a=$ax;$ax=$EWB_a;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=3;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	push @as,$ax;
	$ax="del";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area100; };
	
my $EWB_u;
	$ax=$EWB_a;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=3;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_a;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$EWB_u=$ax;$ax="utenti:user:pass:tipo:nome:datains:datascad:telefono:mail:cell:indirizzo";
$tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);
  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine
  open rof,"> ".checkpath().".TB$n.bkp";
  #modifica 030424 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  push @as, $k;
  #modifica 030424 fine
area101:;
  if ($g > $#f) { goto area103; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #push @as, $k;
  $k=0;
  #modifica 030424 fine
  $i++;
  
  #my @aa=split("#", $l);
  @aa=split("#", $l);
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_user;
	push @as,$ax;
	$ax=$EWB_u;
	$bx=pop @as;
	$ax=($bx eq $ax);
	if ($ax) { goto area102;};
	print rof $l."\n";

area102:;
  $g=$g+1;
  goto area101;
area103: ;
	
  close rof;  
  #copia di un file sull altro
  open rif,checkpath().".TB$n.bkp";
  open rof, ">".checkpath().".TB$n.tab";
  my @fl=<rif>;
  my $rw;
  foreach $rw(@fl)
  { print rof $rw; };  
  close rif;
  close rof;
  tab_unlock($n);
  $k=pop @as;
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  $ax=pop @as;
  @p=split("\n", $ax);
  $ax="jump";
	$EWB_jmp=$ax;goto areaend100;
	
area100:;
	;

areaend100:;
	$ax=$EWB_a;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=3;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_a;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=3;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	push @as,$ax;
	$ax="mod";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area104; };
	$ax=$EWB_a;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=3;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_a;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=0;
	push @as,$ax;
	$ax=3;
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$ax=$EWB_a;
	push @as,$ax;
	$ax=4;
	push @as,$ax;
	$ax=$EWB_a;
	$ax=length($ax);
	$bx=pop @as;
	$cx=pop@as;
	$ax=substr($cx,$bx,$ax);
	$EWB_user=$ax;$ax="utenti:user:pass:tipo:nome:datains:datascad:telefono:mail:cell:indirizzo";
$ax=ewb_exist($ax);
	$ax="add";
	$EWB_a=$ax;goto areaend104;
	
area104:;
	;

areaend104:;
	$ax=$EWB_a;
	push @as,$ax;
	$ax="add";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area105; };
	$ax="Gestione dati utente<br>
  Inserisci i dati e conferma o annulla per continuare";
	$EWB_inf=$ax;$ax="jump";
	$EWB_jmp=$ax;$ax=$EWB_tipo;
	push @as,$ax;
	$ax=";simple;registered;admin";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_tipo=$ax;$ax=(EWdate ());
	$EWB_datains=$ax;$ax="Inserisci;Annulla";
	$EWB_b=$ax;my $form="";
	push @as,"user";
	push @as,$EWB_user;
	push @as,"text";
	push @as,"user";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"pass";
	push @as,$EWB_pass;
	push @as,"password";
	push @as,"pass";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"tipo";
	push @as,$EWB_tipo;
	push @as,"option";
	push @as,"tipo";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"nome";
	push @as,$EWB_nome;
	push @as,"text";
	push @as,"nome";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"datains";
	push @as,$EWB_datains;
	push @as,"text";
	push @as,"datains";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"datascad";
	push @as,$EWB_datascad;
	push @as,"text";
	push @as,"datascad";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"telefono";
	push @as,$EWB_telefono;
	push @as,"text";
	push @as,"telefono";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"mail";
	push @as,$EWB_mail;
	push @as,"text";
	push @as,"mail";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"cell";
	push @as,$EWB_cell;
	push @as,"text";
	push @as,"cell";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"indirizzo";
	push @as,$EWB_indirizzo;
	push @as,"text";
	push @as,"indirizzo";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"nome\"") <0)
     { $form=$form.CreateForm("nome", $EWB_nome, "hidden");
     } 
    if (index($form, "name=\"datains\"") <0)
     { $form=$form.CreateForm("datains", $EWB_datains, "hidden");
     } 
    if (index($form, "name=\"datascad\"") <0)
     { $form=$form.CreateForm("datascad", $EWB_datascad, "hidden");
     } 
    if (index($form, "name=\"telefono\"") <0)
     { $form=$form.CreateForm("telefono", $EWB_telefono, "hidden");
     } 
    if (index($form, "name=\"mail\"") <0)
     { $form=$form.CreateForm("mail", $EWB_mail, "hidden");
     } 
    if (index($form, "name=\"cell\"") <0)
     { $form=$form.CreateForm("cell", $EWB_cell, "hidden");
     } 
    if (index($form, "name=\"indirizzo\"") <0)
     { $form=$form.CreateForm("indirizzo", $EWB_indirizzo, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"nome\"") <0)
     { $form=$form.CreateForm("nome", $EWB_nome, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"zona\"") <0)
     { $form=$form.CreateForm("zona", $EWB_zona, "hidden");
     } 
    if (index($form, "name=\"datains\"") <0)
     { $form=$form.CreateForm("datains", $EWB_datains, "hidden");
     } 
    if (index($form, "name=\"datascad\"") <0)
     { $form=$form.CreateForm("datascad", $EWB_datascad, "hidden");
     } 
    if (index($form, "name=\"telefono\"") <0)
     { $form=$form.CreateForm("telefono", $EWB_telefono, "hidden");
     } 
    if (index($form, "name=\"mail\"") <0)
     { $form=$form.CreateForm("mail", $EWB_mail, "hidden");
     } 
    if (index($form, "name=\"cell\"") <0)
     { $form=$form.CreateForm("cell", $EWB_cell, "hidden");
     } 
    if (index($form, "name=\"indirizzo\"") <0)
     { $form=$form.CreateForm("indirizzo", $EWB_indirizzo, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"data\"") <0)
     { $form=$form.CreateForm("data", $EWB_data, "hidden");
     } 
    if (index($form, "name=\"ora\"") <0)
     { $form=$form.CreateForm("ora", $EWB_ora, "hidden");
     } 
    if (index($form, "name=\"durata\"") <0)
     { $form=$form.CreateForm("durata", $EWB_durata, "hidden");
     } 
    if (index($form, "name=\"visibile\"") <0)
     { $form=$form.CreateForm("visibile", $EWB_visibile, "hidden");
     } 
    if (index($form, "name=\"privato\"") <0)
     { $form=$form.CreateForm("privato", $EWB_privato, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"data\"") <0)
     { $form=$form.CreateForm("data", $EWB_data, "hidden");
     } 
    if (index($form, "name=\"ora\"") <0)
     { $form=$form.CreateForm("ora", $EWB_ora, "hidden");
     } 
    if (index($form, "name=\"azione\"") <0)
     { $form=$form.CreateForm("azione", $EWB_azione, "hidden");
     } 
    if (index($form, "name=\"jmp\"") <0)
     { $form=$form.CreateForm("jmp", $EWB_jmp, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
$form=$form.CreateForm("EWjump", 0+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.395989421130256\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab1;
lab1:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipo=get_par("tipo"); 
$EWB_nome=get_par("nome"); 
$EWB_datains=get_par("datains"); 
$EWB_datascad=get_par("datascad"); 
$EWB_telefono=get_par("telefono"); 
$EWB_mail=get_par("mail"); 
$EWB_cell=get_par("cell"); 
$EWB_indirizzo=get_par("indirizzo"); 
$EWB_user=get_par("user"); 
$EWB_nome=get_par("nome"); 
$EWB_tipo=get_par("tipo"); 
$EWB_zona=get_par("zona"); 
$EWB_datains=get_par("datains"); 
$EWB_datascad=get_par("datascad"); 
$EWB_telefono=get_par("telefono"); 
$EWB_mail=get_par("mail"); 
$EWB_cell=get_par("cell"); 
$EWB_indirizzo=get_par("indirizzo"); 
$EWB_user=get_par("user"); 
$EWB_data=get_par("data"); 
$EWB_ora=get_par("ora"); 
$EWB_durata=get_par("durata"); 
$EWB_visibile=get_par("visibile"); 
$EWB_privato=get_par("privato"); 
$EWB_user=get_par("user"); 
$EWB_data=get_par("data"); 
$EWB_ora=get_par("ora"); 
$EWB_azione=get_par("azione"); 
$EWB_jmp=get_par("jmp"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
$EWB_a=get_par("a"); 
retlab1:;
$ax=$EWB_b;
	push @as,$ax;
	$ax="Inserisci";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area106; };
	$ax="utenti:user:pass:tipo:nome:datains:datascad:telefono:mail:cell:indirizzo";
$ax=ewb_add($ax);
	$ax="Dati inseriti\n";
	print $ax;
	goto areaend106;
	
area106:;
	$ax="Operazione annullata\n";
	print $ax;
	
areaend106:;
	goto areaend105;
	
area105:;
	;

areaend105:;
	$ax="Area di amministrazione.  <br>
E' necessario accedere con la password di superutente";
	$EWB_inf=$ax;
my $EWB_b;
	$ax="Ok";
	$EWB_b=$ax;$ax="";
	$EWB_user=$ax;$ax="";
	$EWB_pass=$ax;$ax=$EWB_jmp;
	push @as,$ax;
	$ax="";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area107; };
	my $form="";
	push @as,"user";
	push @as,$EWB_user;
	push @as,"text";
	push @as,"user";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"pass";
	push @as,$EWB_pass;
	push @as,"password";
	push @as,"pass";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	push @as,"b";
	push @as,$EWB_b;
	push @as,"submit";
	push @as,"";
	$dx=pop @as;
	$cx=pop @as;
	$bx=pop @as;
	$ax=pop @as;
	$form.=CreateForm($ax,$bx,$cx,$dx);
	
    if (index($form, "name=\"template\"") <0)
     { $form=$form.CreateForm("template", $EWB_template, "hidden");
     } 
    if (index($form, "name=\"format\"") <0)
     { $form=$form.CreateForm("format", $EWB_format, "hidden");
     } 
    if (index($form, "name=\"tabpath\"") <0)
     { $form=$form.CreateForm("tabpath", $EWB_tabpath, "hidden");
     } 
    if (index($form, "name=\"sqldbase\"") <0)
     { $form=$form.CreateForm("sqldbase", $EWB_sqldbase, "hidden");
     } 
    if (index($form, "name=\"sqlserver\"") <0)
     { $form=$form.CreateForm("sqlserver", $EWB_sqlserver, "hidden");
     } 
    if (index($form, "name=\"sqluser\"") <0)
     { $form=$form.CreateForm("sqluser", $EWB_sqluser, "hidden");
     } 
    if (index($form, "name=\"sqlpassword\"") <0)
     { $form=$form.CreateForm("sqlpassword", $EWB_sqlpassword, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"pass\"") <0)
     { $form=$form.CreateForm("pass", $EWB_pass, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"nome\"") <0)
     { $form=$form.CreateForm("nome", $EWB_nome, "hidden");
     } 
    if (index($form, "name=\"datains\"") <0)
     { $form=$form.CreateForm("datains", $EWB_datains, "hidden");
     } 
    if (index($form, "name=\"datascad\"") <0)
     { $form=$form.CreateForm("datascad", $EWB_datascad, "hidden");
     } 
    if (index($form, "name=\"telefono\"") <0)
     { $form=$form.CreateForm("telefono", $EWB_telefono, "hidden");
     } 
    if (index($form, "name=\"mail\"") <0)
     { $form=$form.CreateForm("mail", $EWB_mail, "hidden");
     } 
    if (index($form, "name=\"cell\"") <0)
     { $form=$form.CreateForm("cell", $EWB_cell, "hidden");
     } 
    if (index($form, "name=\"indirizzo\"") <0)
     { $form=$form.CreateForm("indirizzo", $EWB_indirizzo, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"nome\"") <0)
     { $form=$form.CreateForm("nome", $EWB_nome, "hidden");
     } 
    if (index($form, "name=\"tipo\"") <0)
     { $form=$form.CreateForm("tipo", $EWB_tipo, "hidden");
     } 
    if (index($form, "name=\"zona\"") <0)
     { $form=$form.CreateForm("zona", $EWB_zona, "hidden");
     } 
    if (index($form, "name=\"datains\"") <0)
     { $form=$form.CreateForm("datains", $EWB_datains, "hidden");
     } 
    if (index($form, "name=\"datascad\"") <0)
     { $form=$form.CreateForm("datascad", $EWB_datascad, "hidden");
     } 
    if (index($form, "name=\"telefono\"") <0)
     { $form=$form.CreateForm("telefono", $EWB_telefono, "hidden");
     } 
    if (index($form, "name=\"mail\"") <0)
     { $form=$form.CreateForm("mail", $EWB_mail, "hidden");
     } 
    if (index($form, "name=\"cell\"") <0)
     { $form=$form.CreateForm("cell", $EWB_cell, "hidden");
     } 
    if (index($form, "name=\"indirizzo\"") <0)
     { $form=$form.CreateForm("indirizzo", $EWB_indirizzo, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"data\"") <0)
     { $form=$form.CreateForm("data", $EWB_data, "hidden");
     } 
    if (index($form, "name=\"ora\"") <0)
     { $form=$form.CreateForm("ora", $EWB_ora, "hidden");
     } 
    if (index($form, "name=\"durata\"") <0)
     { $form=$form.CreateForm("durata", $EWB_durata, "hidden");
     } 
    if (index($form, "name=\"visibile\"") <0)
     { $form=$form.CreateForm("visibile", $EWB_visibile, "hidden");
     } 
    if (index($form, "name=\"privato\"") <0)
     { $form=$form.CreateForm("privato", $EWB_privato, "hidden");
     } 
    if (index($form, "name=\"user\"") <0)
     { $form=$form.CreateForm("user", $EWB_user, "hidden");
     } 
    if (index($form, "name=\"data\"") <0)
     { $form=$form.CreateForm("data", $EWB_data, "hidden");
     } 
    if (index($form, "name=\"ora\"") <0)
     { $form=$form.CreateForm("ora", $EWB_ora, "hidden");
     } 
    if (index($form, "name=\"azione\"") <0)
     { $form=$form.CreateForm("azione", $EWB_azione, "hidden");
     } 
    if (index($form, "name=\"jmp\"") <0)
     { $form=$form.CreateForm("jmp", $EWB_jmp, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
    if (index($form, "name=\"inf\"") <0)
     { $form=$form.CreateForm("inf", $EWB_inf, "hidden");
     } 
    if (index($form, "name=\"a\"") <0)
     { $form=$form.CreateForm("a", $EWB_a, "hidden");
     } 
    if (index($form, "name=\"b\"") <0)
     { $form=$form.CreateForm("b", $EWB_b, "hidden");
     } 
$form=$form.CreateForm("EWjump", 1+1, "hidden"); 

$form=$form."<input type=hidden name=\"EWB_Hid_FIELD\" value=\"0.947858295959549\">\
";
$form="<form action=".$PROGRAM_NAME." method=post enctype=\"multipart/form-data\">".$form."</form>";
print join($form,split("<>", $EWB_template)); exit(0);
	
goto retlab2;
lab2:;
$EWB_template=get_par("template"); 
$EWB_format=get_par("format"); 
$EWB_tabpath=get_par("tabpath"); 
$EWB_sqldbase=get_par("sqldbase"); 
$EWB_sqlserver=get_par("sqlserver"); 
$EWB_sqluser=get_par("sqluser"); 
$EWB_sqlpassword=get_par("sqlpassword"); 
$EWB_user=get_par("user"); 
$EWB_pass=get_par("pass"); 
$EWB_tipo=get_par("tipo"); 
$EWB_nome=get_par("nome"); 
$EWB_datains=get_par("datains"); 
$EWB_datascad=get_par("datascad"); 
$EWB_telefono=get_par("telefono"); 
$EWB_mail=get_par("mail"); 
$EWB_cell=get_par("cell"); 
$EWB_indirizzo=get_par("indirizzo"); 
$EWB_user=get_par("user"); 
$EWB_nome=get_par("nome"); 
$EWB_tipo=get_par("tipo"); 
$EWB_zona=get_par("zona"); 
$EWB_datains=get_par("datains"); 
$EWB_datascad=get_par("datascad"); 
$EWB_telefono=get_par("telefono"); 
$EWB_mail=get_par("mail"); 
$EWB_cell=get_par("cell"); 
$EWB_indirizzo=get_par("indirizzo"); 
$EWB_user=get_par("user"); 
$EWB_data=get_par("data"); 
$EWB_ora=get_par("ora"); 
$EWB_durata=get_par("durata"); 
$EWB_visibile=get_par("visibile"); 
$EWB_privato=get_par("privato"); 
$EWB_user=get_par("user"); 
$EWB_data=get_par("data"); 
$EWB_ora=get_par("ora"); 
$EWB_azione=get_par("azione"); 
$EWB_jmp=get_par("jmp"); 
$EWB_b=get_par("b"); 
$EWB_inf=get_par("inf"); 
$EWB_a=get_par("a"); 
$EWB_b=get_par("b"); 
retlab2:;
$ax="utenti:user:pass:tipo:nome:datains:datascad:telefono:mail:cell:indirizzo";
$ax=ewb_login($ax);
	push @as,$ax;
	$ax=$EWB_tipo;
	push @as,$ax;
	$ax="admin";
	$bx=pop @as;
	$ax=($bx eq $ax);
	$bx=pop @as;
	$ax=$bx && $ax;
	$ax=!$ax;
	if (!($ax)) { goto area108; };
	$ax="Accesso errato.<br>Si prega di riprovare";
	$ax=print join(($ax), split("<>",$EWB_template));
	exit (0);
	goto areaend108;
	
area108:;
	;

areaend108:;
	goto areaend107;
	
area107:;
	;

areaend107:;
	
my $EWB_res;
	$ax="
<b>Gestione utenti servizio contatti/agenda </b><br>

<table border=0><tr><td valign=top>

<table border=1>
<tr><td>Col</td><td>legenda</td></tr>
<tr><td bgcolor=lightgray > </td><td>amministratore</td></tr>
<tr><td bgcolor=green > </td><td>non registrato</td></tr>
<tr><td bgcolor=yellow> </td><td>registrato</td></tr>
<tr><td bgcolor=red   > </td><td>scaduto</td></tr>
</table>

</td><td valign=top>
<a href=admin.cgi?add>
<img src=add.gif border=0 width=16 height=16 title=\"Aggiungi\">
</a>Aggiungi utente<br>

<table border=0>";
	$EWB_res=$ax;$ax="utenti:user:pass:tipo:nome:datains:datascad:telefono:mail:cell:indirizzo";
  $tot=$ax;
  $n=((split(":",$tot))[0]);
  #modifica 030425P inizio
  $ax=join("\n",@p);
  push @as, $ax;
  #modifica 030425P fine
  @p=split(":",substr($tot,length($n)+1));
  tab_wlock($n);

  #modifica 030423 inizio
  #my @f=tab_read($tot);
  $ax=join("\n",@f);
  push @as, $ax;
  @f=tab_read($tot);
  #modifica 030423 fine

  tab_unlock($n);
  #modifica 030423 inizio
  #my $l; my $i=0;
  #my $g=0;
  $ax=join("\n",@aa);
  push @as, $ax;
  push @as, $ct;
  push @as, $i;
  push @as, $l; 
  push @as, $g;
  $i=0;
  $g=0;
  #modifica 030423 fine
  #modifica 030424 inizio
  push @as, $k;
  push @as, $found;
  #modifica 030424 fine
area109:;
  if ($g > $#f) { goto area111; };
  $l=$f[$g]; $l=substr($l,0,length($l));
  #modifica 030424 inizio
  #my $k;
  #my $found=0;
  $k=0;
  $found=0;
  #modifica 030424 fine
  $i++;
  for ($k=$i; $k<=$#f; $k++)
  { if ( ((split( "#",$l))[0]) eq ((split("#",$f[$k]))[0]) )
    { $found=1; };
  }
  if ($found) { goto area110;};
  @aa=split("#", $l);
  #my $ct=0;
  $ct=0;
  $code="";
  foreach $p(@p)
  { $code=$code."\$EWB_".$p."=addchar(\$aa[$ct]);
";
    $ct++;
  };
  eval($code);
	$ax=$EWB_tipo;
	push @as,$ax;
	$ax="simple";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area112; };
	$ax=$EWB_res;
	push @as,$ax;
	$ax="<tr bgcolor=green>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;goto areaend112;
	
area112:;
	$ax=$EWB_tipo;
	push @as,$ax;
	$ax="admin";
	$bx=pop @as;
	$ax=($bx eq $ax);
	if (!($ax)) { goto area113; };
	$ax=$EWB_res;
	push @as,$ax;
	$ax="<tr bgcolor=lightgray>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;goto areaend113;
	
area113:;
	$ax=$EWB_datascad;
	push @as,$ax;
	$ax=(EWdate ());
	$bx=pop @as;
	$ax=EWlessdate($bx,$ax);
	if (!($ax)) { goto area114; };
	$ax=$EWB_res;
	push @as,$ax;
	$ax="<tr bgcolor=red>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;goto areaend114;
	
area114:;
	$ax=$EWB_res;
	push @as,$ax;
	$ax="<tr bgcolor=yellow>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;
areaend114:;
	
areaend113:;
	
areaend112:;
	$ax=$EWB_res;
	push @as,$ax;
	$ax="<td>
<a href=\"admin.cgi?del&";
	push @as,$ax;
	$ax=$EWB_user;
	push @as,$ax;
	$ax="\"><img src=del.gif border=0 width=16 height=16 title=\"Cancella\"></a>

<a href=\"admin.cgi?mod&";
	push @as,$ax;
	$ax=$EWB_user;
	push @as,$ax;
	$ax="\"><img src=mod.gif border=0 width=16 height=16 title=\"Modifica\"></a>

  ";
	push @as,$ax;
	$ax=$EWB_user;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax=$EWB_nome;
	push @as,$ax;
	$ax="</td><td>";
	push @as,$ax;
	$ax=$EWB_tipo;
	push @as,$ax;
	$ax="</td></tr>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;
area110:;
  $g=$g+1;
  goto area109;
area111:;
	
  $found=pop @as;
  $k=pop @as;
  
  $g=pop @as;
  $l=pop @as; 
  $i=pop @as;
  $ct=pop @as;
  $ax=pop @as;
  @aa=split("\n", $ax);
  $ax=pop @as;
  @f=split("\n", $ax);
  #modifica 030425P inizio
  $ax=pop @as;
  @p=split("\n", $ax);
$ax=$EWB_res;
	push @as,$ax;
	$ax="</table></td></tr></table>";
	$bx=pop @as;
	$ax=$bx.$ax;
	$EWB_res=$ax;$ax=$EWB_res;
	$ax=print join(($ax), split("<>",$EWB_template));
	exit(0); 

sub jumper($)
{ my $lab=$_[0];
if ($lab==1) { goto lab1; }
if ($lab==2) { goto lab2; }
};

#Amethist easyweb v. 5.23 - easy 
#Enrico Betti e Paride Dominici



sub ewb_exist($)
{  $cond="\$res=join(\"\",((";
   $tab=$_[0];
   my $count=0;
   my @tot=split(":",$tab);
   foreach $field(@tot)
   { if ($count>0)
     { $cond=$cond."\$EWB_".$field;
       if ($count<$#tot) {$cond=$cond.","; };
     }
     $count++;
  }
  $cond=$cond.")=tab_exist(\"$tot[0]\",\$EWB_";
  $cond=$cond.$tot[1].")));";
  eval($cond);
  return ($res ne "");
}

sub ewb_login($)
{  $cond="\$res=join(\"\",((";
   $tab=$_[0];
   my $count=0;
   my @tot=split(":",$tab);
   foreach $field(@tot)
   { if ($count>0)
     { $cond=$cond."\$EWB_".$field;
       if ($count<$#tot) {$cond=$cond.","; };
     }
     $count++;
  }
  $cond=$cond.")=tab_login(\"$tot[0]\",\$EWB_";
  $cond=$cond.$tot[1].", \$EWB_".$tot[2].")));";
  eval($cond);
  return ($res ne "");
}

sub ewb_add($)
{  my $cond="my \$line=";
   my $tab=$_[0];
   my $count=0;
   my @tot=split(":",$tab);
   tab_wlock($tab);
   foreach $field(@tot)
   { if ($count>0)
     { $cond=$cond."delchar(\$EWB_".$field.")";
       if ($count<$#tot) {$cond=$cond.".\"#\"."; };
     }
     $count++;
  }
  $cond.=";
if (!(open oof,\">> ".checkpath().".TB$tot[0].tab\"))
{ print \"\\nAttenzione: non posso creare files\\n\";
  exit(0);
};
print oof \$line.\"\\n\";
close oof;
";
  eval($cond);
  tab_unlock($tab);
  return ($res ne "");
};

sub EWconv($)
{ my $a=$_[0];
  $a=join("%3C", split("%253C", $a));
#  $a=~ tr/+/ /;
  $a=~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C",hex($1))/eg;
  $a=join("
", split("%0A", $a));
  $a=join("	", split("%09", $a));
  $a=join("\"", split("%22", $a));
  $a=join("<", split("%3C", $a));
  return $a;
}

sub tab_islock($)
{ my $name=$_[0];
  my $l; my $r=0;
  foreach $l(@EWlocked)
  { if ($l eq $name) {$r=1;}
  } return $r;
}

sub tab_exist($$)
{ my ($n,$k)=@_;
  tab_wlock($n);
  open III,"< ".checkpath().".TB$n.tab";
  my $l; my @r;
  foreach $l(<III>)
  { #tolgo da $l il caporiga, o non funziona la exist.
    if (substr($l,length($l)-1,1) eq "\n")
    {  $l=substr($l, 0, length($l)-1);
    }
    if ( ((split("#",$l))[0]) eq delchar($k))
    { my $a;
      @r=();
      foreach $a(split("#",$l))
      { push @r, addchar($a);
  } } }
  close III; tab_unlock($n); return @r;
}

sub tab_login($$$)
{ my ($n,$k,$p)=@_;
  my @r; my @a=tab_exist($n,$k);
  if ($a[1] eq $p) { @r=@a; }
  return @r;
}

sub delchar($)
{ my $a=join("<EWB_ASTErISCO>",split "#", $_[0]);
  $a=join("<EWB_LineFEEd>", split(chr(0x0D), $a));
  return join("<EWB_CARRIaGErETURN>", split("\n", $a));
}

sub toasc($)
{ my $a=$_[0];
  my $r; my $i;
  for($i=0; $i<length($a); $i++)
  { my $k=ord(substr($a,$i,1));
    if ($k<16) {$r=$r."0";};
    $r=$r.sprintf("%x",$k);
  } return $r;
}

sub fromasc($)
{ my $a=$_[0];
  my $r; my $i;
  for($i=0; $i<length($a); $i=$i+2)
  { $r=$r.chr(hex(substr($a,$i,2)));
  } return $r;
}
