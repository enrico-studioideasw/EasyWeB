#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include "vm.h"
#include "opcodes.h"
#include "ewb_predef.h"
int cpos;
#define MAXOBJ 2500
#define  MAXLINE 10000
#define MAXVARLEN 80
#define MAXDATASET 100
#define MAXOUTPUTSIZE 1000000

void err(const char *message);
void setLabel(int label);
/*
Il contratto delle espressioni: il risultato finisce in A, chi vuole conservarlo fa PUSH.
I costrutti di controllo (if, while, for, do...while): tutti riconducibili a LABEL, JMP, JZ e JNZ.
L'assembler integrato: sintassi minimale, con un controllo decente basato sulla tabella delle istruzioni.
L'ISA della VM come sorgente unica di verità: la stessa tabella servirà alla VM, all'assembler, al disassembler e, un domani, anche alla documentazione.
La separazione dei formati: testo per lo sviluppo, .ewm binario con magic non ASCII e versione quando tutto sarà stabile.

DA FARE: 
- aggiungi la regola JNCONTEXT con destinazione  come parametro e nomecontest in stack: salta se il nome non è una var del contesto corrente di in.
    come negli altri casi lo spazio dei nomi rimane locale alla VM. 
- Su assegnamento a orderby ci vuole una regola apposta.
- Iniziare a inserire le predefinite. 
- Forms web - sono costrutti del linguaggio
  - manca ask
  - manca form
  - manca showform
  - estendertli fino a supportare tuttii tipi amethist e oltre. 
EWBD - loggare le richieste (localmente alla singola macchina). Possibilmente a fine e socket chiusa.
EWBD - Supportare campi a dimensione dinamica
*/

char variables[MAXOBJ][MAXVARLEN]; int nvars=0;    //1 mega complessivo.
typedef struct 
{ char name[MAXVARLEN];
  int arity;
  int position;
} ptr;
ptr functions[MAXOBJ]; int nfuncs=0; 
ptr tasks[MAXOBJ];     int ntasks=0; 
ptr targets[MAXOBJ];   int ntargets=0; 
int infunction=0;    //Sono o meno dentro una funzione o dentro un task/target.. Stesso comportamento. 
int labelcount=0;    //Non sono in grado di assegnare subito l'indirizzo a alcune variabili.
int PC=0; 
int sql_mode=0;   //Non c'e' annidamento quindi posso mettere un flag qui.

char code[MAXOUTPUTSIZE];
char res[MAXOUTPUTSIZE];
int respos=0;

void out(const char* dt)
{ int length=(int)strlen(dt);
  if (respos+length+2>=MAXOUTPUTSIZE) err("Output overflow");
  strcpy(&res[respos],dt);
  respos=respos+strlen(dt);
  res[respos]='\n';
  respos++;
  res[respos]=0;
  PC++; //Program counter conta le righe di assembler. 
}; 

char currline[MAXLINE]; 
int nline=1; int nlpos=0;  //Linea attuale e posizione di inizio della linea attuale.
delperc() //Contiene gestione commenti e conteggio righe.
{ while ((code[cpos]==' ') || (code[cpos]=='\t') || (code[cpos]=='\n')
       ||(code[cpos]=='\r') || (code[cpos]=='\''))
  { if (code[cpos]=='\'') 
    { while ((code[cpos]!='\n') && (code[cpos]!=0)) cpos++; 
    }
    else
    { if (code[cpos]=='\n') 
      { int r; 
        nline++; nlpos=cpos+1; 
        for (r=0; (code[cpos+r+1]!='\n') && (code[cpos+r+1]!=0); r++)
        { currline[r]=code[cpos+r+1]; currline[r+1]=0; 
        };
        printf("' %s\n",currline);  
      };
      cpos++; 
    };
  };
};

int isatoken()
{ char r=code[cpos]; 
  return ( ((r>='a') && (r<='z')) || ((r>='A') && (r<='Z')) || ((r>='0') && (r<='9')) || (r=='_') );
};

int istoken(char * v)
{ int res=0; 
  if (!strncmp(&code[cpos], v, strlen(v)))
  { char r=code[cpos+strlen(v)]; 
    res= (!( ((r>='a') && (r<='z')) || ((r>='A') && (r<='Z')) || ((r>='0') && (r<='9')) || (r=='_') ));
  }; 
  return res;
};

char currtok[MAXVARLEN]; 
int token()
{ int len=0; currtok[0]=0;  
  delperc(); 
  if (isatoken())
  { char r=code[cpos]; 
    while ( isatoken() )
    { currtok[len]=r; len++; currtok[len]=0; 
      cpos++; r=code[cpos]; 
    };
  };
  return len; 
}; 
int token_var()
{ int len=0; currtok[0]=0;  
  delperc(); 
  if (isatoken())
  { char r=code[cpos]; 
    while ( isatoken() ||  r=='.')
    { currtok[len]=r; len++; currtok[len]=0; 
      cpos++; r=code[cpos]; 
    };
  };
  return len; 
}; 


int is_assign()      //assign=variabile[calcexp] | variabile =
{ int pos=cpos;
  int level=0;
  if (!((code[pos]>='a' && code[pos]<='z') ||
        (code[pos]>='A' && code[pos]<='Z') || code[pos]=='_')) return 0;
  while ((code[pos]>='a' && code[pos]<='z') ||
         (code[pos]>='A' && code[pos]<='Z') ||
         (code[pos]>='0' && code[pos]<='9') ||
         code[pos]=='_' || code[pos]=='.') pos++;
  while (1)
  { while (code[pos]==' ' || code[pos]=='\t' ||
           code[pos]=='\n' || code[pos]=='\r') pos++;
    if (code[pos]!='[') break;
    level=1;
    pos++;
    while (code[pos] && level>0)
    { if (code[pos]=='"')
      { pos++;
        while (code[pos] && code[pos]!='"')
        { if (code[pos]=='\\' && code[pos+1]) pos++;
          pos++;
        }
        if (code[pos]=='"') pos++;
      } else
      { if (code[pos]=='[') level++;
        if (code[pos]==']') level--;
        pos++;
      }
    }
    if (level!=0) return 0;
  }
  while (code[pos]==' ' || code[pos]=='\t' ||
         code[pos]=='\n' || code[pos]=='\r') pos++;
  return code[pos]=='=' && code[pos+1]!='=';
};

int asmline()
{ if (sql_mode) { err("Unsupported in SQL"); return; };
  char op[64];
  char arg[5000];
  char buf[5200];
  int hasarg = 0;
  cpos++;
  while(code[cpos]==' ' || code[cpos]=='\t') cpos++;  
  token();                    // legge IDENT
  strcpy(op, currtok);
  if (!op[0]) err("Missing asm instruction");
  int instr = find_vm_instr(op);
  if (instr < 0) err("Unknown asm instruction");
  while(code[cpos]==' ' || code[cpos]=='\t') cpos++;  
  if (code[cpos] != '\n' && code[cpos] != '\'' && code[cpos] != 0)
  { hasarg = 1;
    if (code[cpos] == '"')
    { if (argtype!=ARG_STRING && argtype!=ARG_INT_OR_STRING) err("Opcode doesn't accept strings"); 
      cpos++; 
      int p=0; arg[0]=0;
      while(code[cpos] && code[cpos]!='"')
      { if (code[cpos]=='\\') //tengo gli escape.
        { arg[p]='\\'; cpos++; p++; 
        }
        arg[p]=code[cpos]; p++; cpos++;
      };
      if (code[cpos]!='"') err("Missing quote");
      arg[p]=0;
      cpos++; 
      sprintf(buf, "%s \"%s\"\n", op, arg);
    } else if (code[cpos] >= '0' && code[cpos] <= '9')
    { if (argtype!=ARG_INT && argtype!=ARG_INT_OR_STRING) err("Opcode doesn't accept ints"); 
      int i=code[cpos] - '0'; 
      cpos++;
      while (code[cpos] >= '0' && code[cpos] <= '9')
      { i=i*10 + code[cpos] - '0'; 
        cpos++; 
      };
      sprintf(buf, "%s %i\n", op, i);
    } else sprintf(buf, "%s\n", op);        
    while(code[cpos]==' ' || code[cpos]=='\t') cpos++;  
  }
  if (code[cpos] == '\'')
  { while (code[cpos] && code[cpos] != '\n') cpos++;
  }
  if (code[cpos] != '\n') err("Bad asm line");
  cpos++;
  out(buf);   
}


datasetbody(); //Doppia ricorsione: Mi serve ma è sotto.

campidataset(char campi[][MAXDATASET])
{ int ncampi=5; //Ci sono sempre i predefiniti.  
  delperc();
  if (code[cpos]!='{') err("Missing {");
  cpos++; delperc();
  while (code[cpos]!='}')
  { token(); delperc();
    if (code[cpos]=='=') //Sto definendo un altro dataset in ricorsione
    { datasetbody();
      sprintf(campi[ncampi],"id_%s",currtok); 
      ncampi++; 
    } else if (code[cpos]==',' || code[cpos]=='}') 
    { cpos++; delperc; 
    } else err("dataset sn error"); 
  };
  //Se sono arrivato in fondo devo inserire il dataset.. 
  //QUI EMITDATASET 
  int i;
  char buf[200];
  for (i=1; i<ncampi; i++)
  { sprintf(buf, "ADDSYMTABLE \"%s.%s\"", campi[0], campi[i]);
    out(buf);
    if (i==1) out("PUSH \"mysql://ewb\"");
    else if (i==2) out("PUSH \"ewb\"");
    else if (i==3) out("PUSH \"ewb\"");
    else if (i==4) out("PUSH \"stopped\"");
    else out("PUSH \"\"");
  }; 
};

datasetbody()
{ char campi[MAXVARLEN][MAXDATASET]; 
  char buf[200];
  sprintf(buf,"ADDSYMTABLE \"%s\"", currtok);
  out(buf); 
  sprintf(campi[0],"%s", currtok);
  sprintf(buf,"PUSH \"%s\"", currtok);
  out(buf); 
  out("PUSH \"_dataset\"");
  out("SETPATH 0"); 
  if (code[cpos]!='=') err("Missing ="); 
  cpos++; 
  sprintf(campi[1],"_url");
  sprintf(campi[2],"_user");
  sprintf(campi[3],"_password");
  sprintf(campi[4],"_status");
  sprintf(campi[5],"_orderby");
  campidataset(campi);  
};

datasetdecl()
{ char campi[200][MAXDATASET]; 
  char buf[200];
  cpos=cpos + 7;
  delperc();
  token();
  datasetbody();
};

cron()
{ if (sql_mode) { err("Unsupported in SQL"); return; };
  char buf[100];
  delperc();
  token();
  sprintf(buf,"PUSH \"%s\"",currtok);
  out(buf);
  if (code[cpos]!='(') err("Missing ("); 
  cpos++; 
  int arity=0; 
  while (code[cpos]!=')') 
  { if (code[cpos]==')') err("Missing parameter"); 
    delperc();
    inexp();
    out("PUSHA");
    delperc();
    if (code[cpos]!=',' && code[cpos]!=')') err("Missing )"); 
    if (code[cpos]==',') cpos++;  
    arity++; 
  };
  cpos++;
  sprintf(buf,"CRONTASK %i",arity);
  delperc();
  inexp();
  out("PUSHA");
  out(buf); 
};

refresh()
{ if (sql_mode) { err("Unsupported in SQL"); return; };



};

int startparallel()
{ if (!strcmp(currtoken,"cron")) { cron(); return 1; };
  if (!strcmp(currtoken,"refresh")) { refresh(); return 1; };
  if (!strcmp(currtoken,"run")) { tok_run(); return 1; };
  return 0;
};



static int identifier_start()
{ char c=code[cpos];
  if (c>='a' && c<='z') return 1;
  if (c>='A' && c<='Z') return 1;
  return c=='_';
}

static int variable_index(const char *name)
{ int i;
  for (i=0; i<nvars; i++)
  { if (!strcmp(variables[i],name)) return i;
  }
  for (i=0; i<nvars; i++)
  { char *dot=strrchr(variables[i],'.');
    if (dot && !strcmp(dot+1,name)) return i;
  }
  return -1;
}

static void emit_variable_value(const char *name)
{ char buf[2*MAXVARLEN+40];
  int levels=0;
  sprintf(buf,"PUSH \"%s\"",name);
  out(buf);
  delperc();
  while (code[cpos]=='[')
  { int old_sql_mode=sql_mode;
    cpos++;
    sql_mode=0;
    calcexp();
    sql_mode=old_sql_mode;
    out("PUSHA");
    levels++;
    delperc();
    if (code[cpos]!=']') err("Missing ]");
    cpos++;
    delperc();
  }
  sprintf(buf,"PUSH %i",levels);
  out(buf);
  out("GETPATH");
}

static void emit_sql_binary(const char *separator)
{ out("PUSH \"(\"");
  out("PUSHA");
  {
    char buf[80];
    sprintf(buf,"PUSH \"%s\"",separator);
    out(buf);
  }
}

static void finish_sql_binary()
{ out("PUSHA");
  out("CONCAT");
  out("PUSHA");
  out("CONCAT");
  out("PUSHA");
  out("PUSH \")\"");
  out("CONCAT");
  out("PUSHA");
  out("CONCAT");
}

numvalue()
{ int start=cpos;
  int base=10;
  int digits=0;
  char buf[2*MAXVARLEN+40];
  if (code[cpos]=='+' || code[cpos]=='-') cpos++;
  if (code[cpos]=='0' && code[cpos+1]=='b') { base=2; cpos+=2; }
  else if (code[cpos]=='0' && code[cpos+1]=='o') { base=8; cpos+=2; }
  else if (code[cpos]=='0' && code[cpos+1]=='x') { base=16; cpos+=2; }
  while (1)
  { int value=-1;
    char c=code[cpos];
    if (c>='0' && c<='9') value=c-'0';
    else if (c>='a' && c<='f') value=c-'a'+10;
    else if (c>='A' && c<='F') value=c-'A'+10;
    if (value<0 || value>=base) break;
    digits++;
    cpos++;
  }
  if (digits==0) err("Bad number");
  if (code[cpos]=='.')
  { cpos++;
    while (1)
    { int value=-1;
      char c=code[cpos];
      if (c>='0' && c<='9') value=c-'0';
      else if (c>='a' && c<='f') value=c-'a'+10;
      else if (c>='A' && c<='F') value=c-'A'+10;
      if (value<0 || value>=base) break;
      cpos++;
    }
  }
  {
    int length=cpos-start;
    if (length>=MAXVARLEN) err("Number too long");
    sprintf(buf,"MOVA \"%.*s\"",length,&code[start]);
  }
  out(buf);
  if (sql_mode)
  { out("PUSHA");
    out("SQLNUMBER");
  }
}

strvalue()
{ char buf[MAXLINE];
  int pos=0;
  if (code[cpos]!='"') err("Missing string");
  buf[pos++]='M'; buf[pos++]='O'; buf[pos++]='V'; buf[pos++]='A';
  buf[pos++]=' '; buf[pos++]='"';
  cpos++;
  while (code[cpos] && code[cpos]!='"')
  { if (pos>=MAXLINE-3) err("String too long");
    if (code[cpos]=='\\')
    { buf[pos++]=code[cpos++];
      if (!code[cpos]) err("Bad string escape");
    }
    buf[pos++]=code[cpos++];
  }
  if (code[cpos]!='"') err("Missing quote");
  cpos++;
  buf[pos++]='"';
  buf[pos]=0;
  out(buf);
  if (sql_mode)
  { out("PUSHA");
    out("SQLQUOTE");
  }
}

tok_var()
{ char name[MAXVARLEN];
  char buf[2*MAXVARLEN+80];
  int variable;
  int function=-1;
  int i;
  strcpy(name,currtok);
  variable=variable_index(name);
  for (i=0; i<nfuncs; i++)
  { if (!strcmp(functions[i].name,name)) function=i;
  }

  if (code[cpos]=='(')
  { int count=0;
    if (function<0) err("Unknown function");
    cpos++;
    out("PUSHA");
    delperc();
    if (code[cpos]!=')')
    { while (1)
      { inexp();
        out("PUSHA");
        count++;
        delperc();
        if (code[cpos]!=',') break;
        cpos++;
      }
    }
    if (code[cpos]!=')') err("Missing )");
    cpos++;
    if (count!=functions[function].arity) err("Wrong arity");
    sprintf(buf,"PUSH %i",count);
    out(buf);
    sprintf(buf,"CALL %i",functions[function].position);
    out(buf);
    if (sql_mode)
    { out("PUSHA");
      out("SQLQUOTE");
    }
    return;
  }

  if (variable<0 && !sql_mode) err("Unknown variable");
  if (sql_mode)
  { int external=labelcount++;
    int end=labelcount++;
    sprintf(buf,"PUSH \"%s\"",name);
    out(buf);
    sprintf(buf,"JNCONTEXT *LABEL%i*",external);
    out(buf);
    sprintf(buf,"JMP *LABEL%i*",end);
    out(buf);
    setLabel(external);
    if (variable>=0) emit_variable_value(variables[variable]);
    else emit_variable_value(name);
    out("PUSHA");
    out("SQLQUOTE");
    setLabel(end);
    return;
  }
  emit_variable_value(variables[variable]);
}

tok_k()
{ const char *op;
  delperc();
  if (identifier_start())
  { token();
    tok_var();
    return;
  }
  if (code[cpos]=='!')
  { cpos++;
    op="NOT";
    if (code[cpos]=='!')
    { cpos++;
      op="NOTB";
    }
    if (sql_mode)
    { if (!strcmp(op,"NOT")) out("PUSH \"NOT(\"");
      else out("PUSH \"~(\"");
      inexp();
      out("PUSHA");
      out("PUSH \")\"");
      out("CONCAT");
      out("PUSHA");
      out("CONCAT");
    } else
    { inexp();
      out("PUSHA");
      out(op);
    }
    return;
  }
  if (code[cpos]=='-' || code[cpos]=='+' ||
      (code[cpos]>='0' && code[cpos]<='9'))
  { numvalue();
    return;
  }
  if (code[cpos]=='"')
  { strvalue();
    return;
  }
  if (code[cpos]=='(')
  { cpos++;
    calcexp();
    delperc();
    if (code[cpos]!=')') err("Missing )");
    cpos++;
    return;
  }
  err("Missing expression");
}

tok_b()
{ const char *op;
  const char *sqlop;
  delperc();
  tok_k();
  delperc();
  if (code[cpos]!='&') return;
  if (code[cpos+1]=='&')
  { op="AND";
    sqlop=" AND ";
    cpos+=2;
  } else
  { op="ANDB";
    sqlop=" & ";
    cpos++;
  }
  if (sql_mode)
  { emit_sql_binary(sqlop);
    tok_b();
    finish_sql_binary();
  } else
  { out("PUSHA");
    tok_b();
    out("PUSHA");
    out(op);
  }
}

tok_f()
{ const char *op;
  const char *sqlop;
  delperc();
  tok_b();
  delperc();
  if (code[cpos]!='|') return;
  if (code[cpos+1]=='|')
  { op="OR";
    sqlop=" OR ";
    cpos+=2;
  } else
  { op="ORB";
    sqlop=" | ";
    cpos++;
  }
  if (sql_mode)
  { emit_sql_binary(sqlop);
    tok_f();
    finish_sql_binary();
  } else
  { out("PUSHA");
    tok_f();
    out("PUSHA");
    out(op);
  }
}

tok_t()
{ const char *op;
  char symbol;
  delperc();
  tok_f();
  delperc();
  symbol=code[cpos];
  if (symbol=='*') op="MUL";
  else if (symbol=='/') op="DIV";
  else if (symbol=='%') op="MOD";
  else return;
  cpos++;
  if (sql_mode)
  { if (symbol=='%')
    { out("PUSH \"MOD(\"");
      out("PUSHA");
      out("PUSH \",\"");
      tok_t();
      out("PUSHA");
      out("CONCAT");
      out("PUSHA");
      out("CONCAT");
      out("PUSHA");
      out("PUSH \")\"");
      out("CONCAT");
      out("PUSHA");
      out("CONCAT");
    } else
    { char sqlop[4];
      sqlop[0]=' ';
      sqlop[1]=symbol;
      sqlop[2]=' ';
      sqlop[3]=0;
      emit_sql_binary(sqlop);
      tok_t();
      finish_sql_binary();
    }
  } else
  { out("PUSHA");
    tok_t();
    out("PUSHA");
    out(op);
  }
}

tok_e()
{ const char *op;
  const char *sqlop;
  delperc();
  tok_t();
  delperc();
  if (code[cpos]=='+')
  { op="SUM";
    sqlop=" + ";
  } else if (code[cpos]=='-')
  { op="SUB";
    sqlop=" - ";
  } else return;
  cpos++;
  if (sql_mode)
  { emit_sql_binary(sqlop);
    tok_e();
    finish_sql_binary();
  } else
  { out("PUSHA");
    tok_e();
    out("PUSHA");
    out(op);
  }
}

tok_exp()
{ delperc();
  tok_e();
  delperc();
  if (code[cpos]!='.') return;
  cpos++;
  if (sql_mode)
  { out("PUSH \"CONCAT(\"");
    out("PUSHA");
    out("PUSH \",\"");
    tok_exp();
    out("PUSHA");
    out("CONCAT");
    out("PUSHA");
    out("CONCAT");
    out("PUSHA");
    out("PUSH \")\"");
    out("CONCAT");
    out("PUSHA");
    out("CONCAT");
  } else
  { out("PUSHA");
    tok_exp();
    out("PUSHA");
    out("CONCAT");
  }
}

const char* is_cfr()
{ char a,b; a=code[cpos]; b=code[cpos+1];
  if ((a=='=') && (b=='=')) { cpos=cpos+2; return  "EQ"; }; 
  if ((a=='>') && (b=='=')) { cpos=cpos+2; return  "GE"; }; 
  if ((a=='<') && (b=='=')) { cpos=cpos+2; return  "LE"; };
  if (a=='>') { cpos++; return  "GT"; }; 
  if (a=='<') { cpos++; return  "LT"; };
  if ((a=='!') && (b=='=')) { cpos=cpos+2; return  "NEQ"; };
  if ((a=='e') && (b=='q')) { cpos=cpos+2; return  "SEQ"; }; 
  if ((a=='g') && (b=='t')) { cpos=cpos+2; return  "SGT"; }; 
  if ((a=='g') && (b=='e')) { cpos=cpos+2; return  "SGE"; }; 
  if ((a=='l') && (b=='t')) { cpos=cpos+2; return  "SLT"; }; 
  if ((a=='l') && (b=='e')) { cpos=cpos+2; return  "SLE"; };  
  if ((a=='n') && (b=='e')) { cpos=cpos+2; return  "SNEQ"; };
  return ""; 
};
inexp()
{ delperc();
  tok_exp();
  delperc();
  const char *op=is_cfr();
  if (op[0]==0) return;
  if (sql_mode)
  { const char *sqlop="";
    const char *plain=op;
    if (plain[0]=='S') plain++;
    if (!strcmp(plain,"EQ")) sqlop=" = ";
    else if (!strcmp(plain,"NEQ")) sqlop=" != ";
    else if (!strcmp(plain,"GT")) sqlop=" > ";
    else if (!strcmp(plain,"GE")) sqlop=" >= ";
    else if (!strcmp(plain,"LT")) sqlop=" < ";
    else if (!strcmp(plain,"LE")) sqlop=" <= ";
    else err("Bad comparison");
    emit_sql_binary(sqlop);
    tok_exp();
    finish_sql_binary();
  } else
  { out("PUSHA");
    tok_exp(); //Un solo confronto: a > b <= c e' errore sintattico.
    out("PUSHA");
    out(op);
  }
}

fundecl(unsigned char type)
{ char buf[200]; 
  size=3;
  if (type==1) size=4; //TASK 
  if (type==2) size=6; //TARGET 
  cpos=cpos+size; delperc(); 
  int lend = labelcount++; //Salto a fine funzione. 
  infunction=1; 
  int endglobal=nvars;
  int basevars=nvars; //Questo mi serve per contare anche eventuali variabili locali. 
  variables[nvars][0] = 0; nvars++; //la posizione del return
//printf("Nvars: %i, vars (%s)(%s)(%s)(%s)(%s)(%s)(%s)\n", nvars, 
//variables[0], variables[1], variables[2], variables[3], variables[4], variables[5], variables[6]); 
  
  if (!token()) err("Syntax error in function"); 
  strcpy(functions[nfuncs], currtok); 
  funtypes[npos]=type;
  sprintf(buf, "ADDSYMTABLE \"%s\"", currtok);
  out(buf); 
  sprintf(buf, "PUSH %s", currtok); //Nome
  out(buf);
  sprintf(buf, "PUSH %i", PC+1); //Valore 
  out(buf);
  out("setpath 0"); 
  sprintf(buf, "JMP *LABEL%i*", lnext);
  out(buf);
  //Se è un task o un target serve il punto di lancio.
  if (type==1) out("TASK");
  if (type==2) out("TARGET"); 
  delperc(); 
  if (code[cpos]!='(') err("Missing ("); 
  cpos++; delperc();  
  int *art=&(arity[nfuncs]); (*art)=0; 
  funcpos[nfuncs]=respos;  
  nfuncs++; 
  int k=nvars; 
  if (code[cpos]!=')') 
  { if (!token()) err("Fun.par syntax error");  //Dichiaro la variabile e uso pop per pescare i parametri.
    strcpy(variables[k], currtok); 
    (*art)++;  
    k++; 
    delperc();
  };
  while (code[cpos]==',')
  { cpos++;
    if (!token()) err("Fun.par syntax error");  //Dichiaro la variabile e uso pop per pescare i parametri.
    strcpy(variables[k], currtok); 
    (*art)++; 
    k++; 
    delperc();
  };
  nvars=k+1; //Aggiungo le locali
  sprintf(buf, "DECSP %i", (*art));
  out(buf);
  int i; 
  for (i=; i<nvars; i++)
  { sprintf(buf, "ADDSYMTABLE \"%s\"", variables[i]);
    out(buf); 
  };
  if (code[cpos]!=')') err("Missing )");   
  cpos++; delperc(); 
  block();  
  setLabel(lend); 
  sprintf(buf, "DELSYMTABLE", nvars-basevars);
  out(buf);
  //Se è un task o un target serve il punto di termine.
  if (type==1) out("ENDTASK");
  if (type==2) out("ENDTARGET"); 
  out("RET"); 
  nvars=basevars; 
  infunction=0;  
};


downwhileblock()
{ int lstart;
  char buf[100];
  cpos += 2;          // "do"
  delperc();
  lstart = labelcount++;
  setLabel(lstart);
  block();
  if (!istoken("while")) err("Missing while");
  cpos += 5;
  delperc();
  calcexp();
  sprintf(buf, "JNZ *LABEL%i*\n", lstart);
  out(buf);
}

whileblock()
{ int lstart, lend;
  char buf[100];
  cpos += 5;        // "while"
  delperc();
  lstart = labelcount++;
  lend   = labelcount++;
  setLabel(lstart);
  calcexp();
  sprintf(buf, "JZ *LABEL%i*\n", lend);
  out(buf);
  block();
  sprintf(buf, "JMP *LABEL%i*\n", lstart);
  out(buf);
  setLabel(lend);
}

forblock()
{ int lcond, lstep, lbody, lend;
  char buf[100];
  cpos += 3;
  delperc();
  if (code[cpos] != '(') err("Missing (");
  cpos++;
  calcexp();              // exp0
  if (code[cpos] != ';') err("Missing ;");
  cpos++;
  delperc();
  lcond = labelcount++;
  lstep = labelcount++;
  lbody = labelcount++;
  lend  = labelcount++;
  setLabel(lcond);
  calcexp();              // exp1
  sprintf(buf, "JZ *LABEL%i*\n", lend);
  out(buf);
  sprintf(buf, "JMP *LABEL%i*\n", lbody);
  out(buf);
  setLabel(lstep);
  if (code[cpos] != ';') err("Missing ;");
  cpos++;
  delperc();
  calcexp();              // exp2
  if (code[cpos] != ')') err("Missing )");
  cpos++;
  delperc();
  sprintf(buf, "JMP *LABEL%i*\n", lcond);
  out(buf);
  setLabel(lbody);
  block();
  sprintf(buf, "JMP *LABEL%i*\n", lstep);
  out(buf);
  setLabel(lend);
}

ifblock()
{ int lend, lnext;
  char buf[100];
  cpos += 2;
  delperc();
  lend = labelcount++;
  calcexp();
  lnext = labelcount++;
  sprintf(buf, "JZ *LABEL%i*", lnext);
  out(buf);
  block();
  sprintf(buf, "JMP *LABEL%i*", lend);
  out(buf);
  setLabel(lnext);
  while (istoken("elseif"))
  { cpos += 6;   // controlla: "elseif" sono 6 caratteri
    delperc();
    calcexp();
    lnext = labelcount++;
    sprintf(buf, "JZ *LABEL%i*", lnext);
    out(buf);
    block();
    sprintf(buf, "JMP *LABEL%i*", lend);
    out(buf);
    setLabel(lnext);
  };
  if (istoken("else"))
  { cpos += 4;   // controlla: "else" sono 4 caratteri
    delperc();
    block();
  };
  setLabel(lend);
};

calcexp()
{ delperc();
  if (is_assign())
  { char target[MAXVARLEN];
    char buf[2*MAXVARLEN+80];
    int variable;
    int levels=0;
    int orderby=0;
    if (!token_var()) err("Missing assignment target");
    strcpy(target,currtok);
    variable=variable_index(target);
    if (variable<0) err("Unknown symbol");
    {
      char *field=strrchr(target,'.');
      if (field) field++;
      else field=target;
      if (!strcmp(field,"_orderby")) orderby=1;
    }
    delperc();
    sprintf(buf,"PUSH \"%s\"",variables[variable]);
    out(buf);
    while (code[cpos]=='[')
    { cpos++;
      calcexp();
      out("PUSHA");
      levels++;
      delperc();
      if (code[cpos]!=']') err("Missing ]");
      cpos++;
      delperc();
    }
    if (code[cpos] != '=') err("Missing =");
    cpos++;
    delperc();
    if (orderby)
    { int empty_orderby=0;
      int after_empty=cpos;
      char context[MAXVARLEN];
      char *field=strrchr(target,'.');
      if (!field) err("_orderby requires a dataset");
      if (code[cpos]=='"' && code[cpos+1]=='"')
      { after_empty=cpos+2;
        while (code[after_empty]==' ' || code[after_empty]=='\t' ||
               code[after_empty]=='\n' || code[after_empty]=='\r')
          after_empty++;
        if (code[after_empty]==';' || code[after_empty]=='}' ||
            code[after_empty]==')' || code[after_empty]==0)
          empty_orderby=1;
      }
      if (empty_orderby)
      { cpos+=2;
        out("MOVA \"\"");
      } else
      {
        {
          int length=(int)(field-target);
          memcpy(context,target,length);
          context[length]=0;
        }
        sprintf(buf,"PUSH \"%s\"",context);
        out(buf);
        sql_mode=1;
        inexp();
        delperc();
        while (code[cpos]==',')
        { cpos++;
          out("PUSHA");
          out("PUSH \", \"");
          inexp();
          out("PUSHA");
          out("CONCAT");
          out("PUSHA");
          out("CONCAT");
          delperc();
        }
        sql_mode=0;
        out("DECSP 1");
      };
    } else inexp();
    out("PUSHA");
    sprintf(buf,"SETPATH %i",levels);
    out(buf);
  } else inexp();
}

inblock()
{ cpos=cpos+2; 
  //in ( variabile[.variabile] [, condizione] ) blocco
  if (code[cpos] != '(') err("Missing (");
  cpos++;
  inexp(); //Qui A contiene il come della tabella.                                STACK
  out("PUSH \"dummy\""); //                                                     [dummy]
  out("PUSHA");  //PUSH CONTEXT                                         [CONTEXT,dummy]
  out("PUSHA");  //PUSH CONTEXT                                 [CONTEXT,CONTEXT,dummy]
  delperc();
  if (code[cpos]==',')
  { cpos++; 
    sql_mode=1;
    calcexp(); //Qui viene eseguito codice e A contiene la query normalizzata.
    sql_mode=0;
    out("PUSHA");  //PUSH CONDICTION                       [COND,CONTEXT,CONTEXT,dummy]
    delperc();
  } else //La inall è una in senza condizione. 
  { out("PUSH \"true\""); 
  };
  if (code[cpos] != ')') err("Missing )");
  cpos++; 
  //Qui devo inserire l'ordinamento. E' context.orderby ma non ho il dato qui.
  //Ci pensa la QLIST..  
  out("QLIST");  //                                                     [context,dummy]  
  out ("PUSH 0");//                                                   [0,CONTEXT,dummy]
  out("DECSP 4");                                      
  out ("PUSHA");                                                                                 
  out("INCSP 4");//                                                 [0,IDS,CONTEXT,IDS]
  int loop=PC; 
//LOOP:
  //Ho A e IDS gia pronti per una getpath.. ma poi devo rimetterli in stack. La getpatch deve avere i TRE parametri in stack
  out("GETPATH"); //A=IDS[ID]                                             [CONTEXT,IDS]
  out("JZ *LABEL%i*\n", labelcount); //Finiti gli id, Salta al termine
  int endin=labelcount; 
  labelcount++; 
  out ("PUSH A");//                                                    [ID,CONTEXT,IDS]   
  out("QBYID");  //Variabili contesto valorizzate da qbyid                        [IDS]
  out("JNZ *LABEL%i*\n", labelcount); //Evita il codice sotto se il dato c'e'
  int co=labelcount; 
  labelcount++; 
  //Riporta a posto lo stack e salta a LOOP  
  out("INCSP 2");
  out("PUSH 1");
  out("SUM");
  out("push \"dummy\"");
  out("push A");
  out("DECSP 4");
  out("POP A");
  out("INCSP 3");
  out("PUSH A");
  out("INCSP 1");
  sprintf(buf,"JMP %i", loop); out(buf);  
//CONT:
  setLabel(co); 
  out("INCSP 2");
  out("PUSH 1");
  out("SUM");
  out("push \"dummy\"");
  out("push A");
  out("DECSP 4");
  out("POP A");
  out("INCSP 3");
  out("PUSH A");
  out("INCSP 1");
  delperc();
  blocco();  
  sprintf(buf,"JMP %i", loop); out(buf);  
  setLabel(endin);
};

/* ========================================================================
   FORMS: DA VERIFICARE
   Ogni primitiva produce un frammento in A. I frammenti vengono accodati
   esplicitamente con PUSHA e CONCAT.
   ======================================================================== */

int formvar(char *name) /* FORMS: DA VERIFICARE */
{ int i;
  for (i=0; i<nvars; i++)
  { char *p=variables[i];
    while (p)
    { if (!strcmp(p,name)) return i;
      p=strchr(p,'.');
      if (p) p++;
    };
  };
  return -1;
};

formfield() /* FORMS: DA VERIFICARE */
{ char name[MAXVARLEN];
  char style[MAXVARLEN];
  char buf[3*MAXVARLEN];
  int var;

  if (!token_var()) err("Missing form field");
  strcpy(name,currtok);
  var=formvar(name);
  if (var<0) err("Unknown form field");

  strcpy(style,"text");
  delperc();
  if (code[cpos]==':')
  { cpos++;
    if (!token()) err("Missing form field type");
    strcpy(style,currtok);
  };

  out("PUSHA");
  sprintf(buf,"PUSH \"%s\"",name); out(buf);
  sprintf(buf,"PUSH \"%s\"",style); out(buf);
  sprintf(buf,"PUSH \"%s\"",variables[var]); out(buf);
  out("PUSH 0");
  out("GETPATH");
  out("PUSHA");
  out("ADDFORM");
  out("PUSHA");
  out("CONCAT");
};

formfields() /* FORMS: DA VERIFICARE */
{ formfield();
  delperc();
  while (code[cpos]==',')
  { cpos++;
    formfield();
    delperc();
  };
};

formblock() /* FORMS: DA VERIFICARE */
{ cpos+=4;
  delperc();
  out("MOVA \"\"");
  formfields();
};

askblock() /* FORMS: DA VERIFICARE */
{ cpos+=3;
  delperc();
  out("STARTFORM");
  formfields();
  out("PUSHA");
  out("ENDFORM");
  out("PUSHA");
  out("CONCAT");
  out("PUSHA");
  out("SHOW");
  out("STOP");
};

showformblock() /* FORMS: DA VERIFICARE */
{ cpos+=8;
  delperc();
  out("STARTFORM");
  out("PUSHA");
  inexp();
  out("PUSHA");
  out("CONCAT");
  out("PUSHA");
  out("ENDFORM");
  out("PUSHA");
  out("CONCAT");
  out("PUSHA");
  out("SHOW");
  out("STOP");
};

/* ======================== FINE FORMS: DA VERIFICARE ===================== */

codice()
{ delperc(); 
  int p=cpos; 
//Tipi strutturati
  if (istoken("dataset")) datasetdecl(); 
  if (istoken("task"))    taskdecl(); 
  if (istoken("target"))  targetdecl(); 
//Database
  if (istoken("in"))      inblock();
  if (istoken("delete"))  deleteblock();
  if (istoken("add"))     addblock();
//Web: DA VERIFICARE
  if (istoken("ask"))      askblock();
  if (istoken("form"))     formblock();
  if (istoken("showform")) showformblock();
//Cicli
  if (istoken("if"))      ifblock();
  if (istoken("while"))   whileblock();
  if (istoken("do"))      downwhile();
  if (istoken("foreach")) foreachblock();
  if (istoken("for"))     forblock();
//Vaiabili e funzioni
  if (istoken("var"))     vardecl();
  if (istoken("sub"))     fundecl(0);
  if (code[cpos]=='.')    asmline(); 
  if (p==cpos) { calcexp(); }; 
  if (p==cpos) { err("syntax error"); };
  delperc(); 
  if (code[cpos]!=';') err("missing ;");
  cpos++;  
};
blocco()
{ delperc(); 
  if (code[cpos]=='{') 
  { cpos++; 
    codice(); 
    delperc(); 
    if (code[cpos]!='}') err("missing }"); 
    cpos++;
    delperc();
  } else codice();  
}
programma()
{ while (code[cpos]!=0) 
  { blocco(); 
    delperc(); 
    if (code[cpos]!=';') err("missing ;");
    cpos++;  
  };
};

main(int argc, char** argv)
{ if ((argc != 3) && (argc != 4)) //per ora rigido: inputfile, outputfile
  { printf ("Uso %s [-d] inputfile.ewb outputfile.evm\n", argv[0]); 
    exit(-1); 
  };
  int dpos=0; 
  if (!strcmp(argv[1], "-d")) { dpos++; add_debug=1; };
  int f=open(argv[1+dpos], O_RDONLY); 
  if (f>0) 
  { code = (char*)malloc(100000);
    res = (unsigned char*)malloc(50000);
    add_predefs(); 
    int i=read(f, code, 100000); 
    close(f); printf("Read %i bytes\n", i);
    code[i]=0; 
    respos=0; 
    cpos=0; 
    programma();
    printf("\nOutput %i lines\n", PC);  
    f=open(argv[2+dpos], O_WRONLY | O_CREAT | O_TRUNC, 0777); 
    write(f, res, respos); 
    close(f);   
  } else printf("Errore di lettura file origine\n");  
};
