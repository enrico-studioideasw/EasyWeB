struct EWBHeader
{ uint8_t magic[4];   // 0x7F 'E' 'W' 'B'
  uint8_t version;    // 1
};

typedef enum {
    ARG_NONE,
    ARG_INT,
    ARG_STRING,
    ARG_INT_OR_STRING
} ArgType;

typedef struct {
    const char *name;
    int opcode;
    ArgType argtype;
} VmInstr;

VmInstr vm_instr[] = {
    {"NOP",     OP_NOP,     ARG_NONE},
    {"PUSH",    OP_PUSH,    ARG_INT_OR_STRING},
    {"POP",     OP_POP,     ARG_NONE},
    {"JMP",     OP_JMP,     ARG_INT},
    {"JZ",      OP_JZ,      ARG_INT},
    {"JNZ",     OP_JNZ,     ARG_INT},
    {"SETPATH", OP_SETPATH, ARG_INT},
    {"GETPATH", OP_GETPATH, ARG_INT},
    {"CALL",    OP_CALL,    ARG_INT},
    {"RET",     OP_RET,     ARG_NONE},
    {NULL,      0,          ARG_NONE}
};
